# Absen CV Hikmah Tani — V17 AUDIT/FIX ALL

## Firebase
- Project: `absensi-cv-hikmah-tani`
- Android package: `com.hikmahtani.absen`
- Realtime Database: `https://absensi-cv-hikmah-tani-default-rtdb.firebaseio.com`
- Data path: `cv_hikmah_tani/state`
- Database region: `us-central1`

## Fitur
- Login Google / logout
- 16 hari, Pagi/Sore
- 37 laki-laki dan 26 perempuan
- Firebase Realtime Database
- Backup/Pulihkan JSON
- PDF dan CSV
- Pengaturan nama
- Reset
- Logo HT dan desain elegan

## Audit V17
- Klik Pagi/Sore tidak membangun ulang daftar, sehingga posisi scroll tidak dilompati.
- Hari yang sedang dipilih dipertahankan saat UI perlu dibangun ulang.
- Callback Firebase hanya meneruskan snapshot ke main thread; pemrosesan data dilakukan di thread UI agar exception aplikasi tidak dilempar dari Database runloop.
- Absensi biasa menggunakan `updateChildren()` pada child yang berubah, sehingga perubahan HP lain pada child berbeda tidak ikut tertimpa.
- Restore dan Reset menggunakan satu full-state write yang sengaja menjadi operasi authoritative.
- Pending restore/reset disimpan di SharedPreferences, sehingga jika aplikasi ditutup sebelum cloud selesai, operasi tetap dilanjutkan saat aplikasi dibuka kembali.
- Perubahan lokal yang terjadi selama full-state upload akan dikirim ulang setelah upload pertama selesai.
- Reset menghapus seluruh key absensi lama/custom, bukan hanya nama yang sedang tampil.
- Backup/Pulihkan mendukung format lama dan baru.
- Total, CSV, PDF, backup, restore, dan reset sudah memakai 16 hari.
- `runTransaction()` tidak digunakan pada sinkronisasi absensi.

## Keamanan
Rules Firebase di `database.rules.json` masih mengizinkan akun Google terverifikasi. Jika aplikasi hanya boleh dipakai satu akun, rules sebaiknya dikunci ke UID/email akun yang memang digunakan.


## Update Periode & Status Absensi
- Periode dapat dipilih per bulan/tahun dan Sesi 1 (tanggal 1-15) atau Sesi 2 (tanggal 16-hari terakhir bulan).
- Ditambahkan status Tidak Hadir, Tidak Masuk Pagi, dan Tidak Masuk Sore.
- Status tersimpan di perangkat, backup/restore, dan Firebase bersama data lainnya.
- Perhitungan tetap: dua sesi hadir = 1, satu sesi = 0,5, tidak hadir = 0.
- PDF menggunakan tanda '-' untuk 0 dan pewarnaan 0 merah, 0,5 kuning, 1 hijau serta rekap jumlah laki-laki/perempuan/total.
- Baseline tetap V17; login Google, Firebase, sinkronisasi, nama, backup/restore, reset, dan desain utama dipertahankan.
