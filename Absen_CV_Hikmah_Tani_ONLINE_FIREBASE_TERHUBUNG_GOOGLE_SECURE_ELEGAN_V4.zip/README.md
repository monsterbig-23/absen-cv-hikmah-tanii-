# Absen CV Hikmah Tani

Aplikasi absensi 15 hari untuk CV Hikmah Tani.

## Fitur
- Login dan logout dengan Google melalui Firebase Authentication.
- Halaman absensi hanya dapat dibuka setelah login.
- 15 hari, masing-masing Pagi dan Sore.
- Pagi + Sore = 1 hari; satu sesi = 0,5 hari.
- Kelompok laki-laki dan perempuan terpisah.
- Penyimpanan lokal dan sinkronisasi Firebase Realtime Database.
- Rekap CSV, PDF, backup dan pemulihan JSON.
- Pengaturan nama dan nama aplikasi.
- Reset absensi.
- Ikon aplikasi HT merah 3D.
- Tampilan elegan dengan aksen navy, burgundy, emerald, plum, royal blue, dan champagne.

## Keamanan
- Google Credential Manager digunakan untuk login.
- Nonce acak SHA-256 digunakan pada alur Google Sign-In.
- Tidak memakai anonymous authentication.
- Manifest hanya meminta permission INTERNET.
