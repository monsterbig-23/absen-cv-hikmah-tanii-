package com.hikmahtani.absen;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.CancellationSignal;
import android.util.Log;
import androidx.core.content.FileProvider;
import androidx.core.content.ContextCompat;
import androidx.credentials.ClearCredentialStateRequest;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.NoCredentialException;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.*;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import android.view.*;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;

public class MainActivity extends Activity {
    static final String PREF="absen_data_v2";
    static final String KEY_MALE="names_male";
    static final String KEY_FEMALE="names_female";
    static final String KEY_APP="app_title";
    // Realtime Database dibuat di lokasi us-central1. Pakai URL eksplisit agar
    // kedua perangkat selalu terhubung ke instance database yang sama.
    static final String FIREBASE_DB_URL="https://absensi-cv-hikmah-tani-default-rtdb.firebaseio.com";

    final String[] DEFAULT_MALE = {"SLAMET","BIRIN","KURNIA","JOHAN","NENDI","KABUL","PIYAN","UDIN","JUNAEDI","ASEP C","ADE T","ANGGI","ANTO","AGUNG","RIJAL","DIKA","EKO","AANG","AGUNG GT","CICI","GIMIN","ALI","BENI","ASEP M","DEDI","BUYUNG","JALI","ADE CUMARNO","JONI H","ROJAK","USUP","AMANG","AHMAD","P. USTAD","IRMAN","TOMI","D. MARJI"};
    final String[] DEFAULT_FEMALE = {"DEDEH","TINI","ENTUN","ONEH","TITI","IIS","NURUL","YUYUN","SUTIAH","EPON","NENG AGUS","AMBU","YANI","NURSIAH","TITIN","TUSIAH","SOLEHAH","GIYEM","SANTI","TETEH","M. IBAH","MARINAH","KHOTIMAH","MBA SUM","IPAT","IKA"};

    SharedPreferences prefs;
    LinearLayout list;
    ScrollView sv;
    Spinner daySpinner;
    int currentDay=1;

    FirebaseAuth firebaseAuth;
    DatabaseReference cloudState;
    ValueEventListener cloudListener;
    CredentialManager credentialManager;
    boolean cloudReady=false;
    boolean cloudConnected=false;
    boolean remoteApplying=false;
    boolean restoringBackup=false;
    boolean localCloudWrite=false;
    boolean restoreUploadInProgress=false;
    DatabaseReference cloudConnection;
    ValueEventListener cloudConnectionListener;
    TextView cloudStatus;
    boolean signInInProgress=false;
    GoogleSignInClient legacyGoogleClient;
    static final int REQ_GOOGLE_LEGACY=9001;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences(PREF,MODE_PRIVATE);
        connectCloud();
    }

    void connectCloud(){
        try{
            firebaseAuth=FirebaseAuth.getInstance();
            credentialManager=CredentialManager.create(this);
            GoogleSignInOptions gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(getString(R.string.default_web_client_id))
                    .requestEmail()
                    .build();
            legacyGoogleClient=GoogleSignIn.getClient(this,gso);

            FirebaseUser current=firebaseAuth.getCurrentUser();
            if(current!=null){
                build();
                startCloudSync();
            }else{
                buildLogin();
            }
        }catch(Exception e){
            buildLogin();
            toast("Firebase belum terhubung");
        }
    }

    void requestGoogleSignIn(){
        if(signInInProgress)return;
        signInInProgress=true;
        // V5: karena pengguna menekan tombol login secara eksplisit,
        // gunakan Button Flow resmi GetSignInWithGoogleOption terlebih dahulu.
        // Ini juga merupakan alur yang direkomendasikan Android untuk kondisi
        // akun belum pernah dipakai, perlu re-authentication, atau sheet biasa
        // tidak menemukan credential.
        requestGoogleSignInExplicit();
    }

    void requestGoogleSignInExplicit(){
        if(credentialManager==null){
            signInInProgress=false;
            showLoginError("Credential Manager tidak tersedia di perangkat");
            return;
        }
        try{
            GetSignInWithGoogleOption option=new GetSignInWithGoogleOption.Builder(
                    getString(R.string.default_web_client_id))
                    .setNonce(generateSecureNonce())
                    .build();

            GetCredentialRequest request=new GetCredentialRequest.Builder()
                    .addCredentialOption(option)
                    .build();

            credentialManager.getCredentialAsync(
                    this,
                    request,
                    new CancellationSignal(),
                    ContextCompat.getMainExecutor(this),
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override public void onResult(GetCredentialResponse result){
                            signInInProgress=false;
                            handleGoogleCredential(result);
                        }

                        @Override public void onError(GetCredentialException e){
                            Log.e("AbsenGoogle", "Google Sign-In error: "+e.getClass().getName()+" / "+String.valueOf(e.getMessage()), e);
                            if(isUserCancel(e)){
                                // Beberapa perangkat/versi Google Play services dapat menutup
                                // Button Flow Credential Manager tanpa menampilkan picker.
                                // Gunakan compatibility fallback agar pengguna tetap mendapat
                                // pemilih akun Google yang nyata.
                                requestLegacyGoogleSignIn();
                            }else if(isNoCredential(e)){
                                // Coba bottom-sheet dengan semua akun sebagai fallback.
                                requestGoogleAccountSheet();
                            }else{
                                signInInProgress=false;
                                showLoginError(credentialErrorMessage(e));
                            }
                        }
                    });
        }catch(Exception e){
            Log.e("AbsenGoogle", "Unable to start Google Sign-In", e);
            signInInProgress=false;
            showLoginError("Tidak dapat memulai Login Google");
        }
    }

    void requestLegacyGoogleSignIn(){
        if(legacyGoogleClient==null){
            signInInProgress=false;
            showLoginError("Layanan Login Google tidak tersedia di perangkat ini");
            return;
        }
        try{
            legacyGoogleClient.signOut().addOnCompleteListener(task -> {
                try{
                    Intent intent=legacyGoogleClient.getSignInIntent();
                    startActivityForResult(intent,REQ_GOOGLE_LEGACY);
                }catch(Exception e){
                    signInInProgress=false;
                    Log.e("AbsenGoogle","Legacy Google Sign-In could not start",e);
                    showLoginError("Pemilih akun Google tidak dapat dibuka");
                }
            });
        }catch(Exception e){
            signInInProgress=false;
            Log.e("AbsenGoogle","Legacy Google Sign-In failed to start",e);
            showLoginError("Pemilih akun Google tidak dapat dibuka");
        }
    }

    void requestGoogleAccountSheet(){
        try{
            GetGoogleIdOption googleIdOption=new GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(getString(R.string.default_web_client_id))
                    .setNonce(generateSecureNonce())
                    .build();

            GetCredentialRequest request=new GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build();

            credentialManager.getCredentialAsync(
                    this,
                    request,
                    new CancellationSignal(),
                    ContextCompat.getMainExecutor(this),
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override public void onResult(GetCredentialResponse result){
                            signInInProgress=false;
                            handleGoogleCredential(result);
                        }

                        @Override public void onError(GetCredentialException e){
                            Log.e("AbsenGoogle", "Google account sheet error: "+e.getClass().getName()+" / "+String.valueOf(e.getMessage()), e);
                            if(isUserCancel(e)){
                                requestLegacyGoogleSignIn();
                            }else{
                                signInInProgress=false;
                                if(isNoCredential(e)) showLoginError("Tidak ada akun Google yang bisa digunakan di perangkat ini");
                                else showLoginError(credentialErrorMessage(e));
                            }
                        }
                    });
        }catch(Exception e){
            Log.e("AbsenGoogle", "Unable to open Google account sheet", e);
            signInInProgress=false;
            showLoginError("Tidak dapat membuka pilihan akun Google");
        }
    }

    boolean isNoCredential(Exception e){
        return e instanceof NoCredentialException || e.getClass().getSimpleName().contains("NoCredential");
    }

    boolean isUserCancel(Exception e){
        String n=e.getClass().getSimpleName();
        return n.contains("Cancellation") || n.contains("UserCanceled") || n.contains("UserCancel");
    }

    String credentialErrorMessage(Exception e){
        String n=e==null?"":e.getClass().getSimpleName();
        String m=e==null?null:e.getMessage();
        if(n.contains("ProviderConfiguration")) return "Konfigurasi Google di perangkat bermasalah";
        if(n.contains("ProviderUnavailable")) return "Layanan Google untuk Login tidak tersedia";
        if(n.contains("GetCredentialUnsupported")) return "Perangkat tidak mendukung Login Google ini";
        if(m!=null && !m.trim().isEmpty()) return "Login Google gagal ("+n+")";
        return "Login Google gagal ("+n+")";
    }

    void showLoginError(String message){
        new AlertDialog.Builder(this)
                .setTitle("Login Google tidak berhasil")
                .setMessage(message+"\n\nPastikan akun Google ada di perangkat dan Google Play services sudah aktif/terbarui.")
                .setNegativeButton("Tutup",null)
                .setPositiveButton("Coba lagi",(d,w)->requestGoogleSignIn())
                .show();
    }

    void handleGoogleCredential(GetCredentialResponse result){
        Credential credential=result.getCredential();

        if(!(credential instanceof CustomCredential)){
            toast("Kredensial Google tidak valid");
            return;
        }

        CustomCredential custom=(CustomCredential)credential;
        if(!GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(custom.getType())){
            toast("Jenis akun Google tidak didukung");
            return;
        }

        try{
            GoogleIdTokenCredential google=GoogleIdTokenCredential.createFrom(custom.getData());
            String idToken=google.getIdToken();
            AuthCredential firebaseCredential=GoogleAuthProvider.getCredential(idToken,null);

            firebaseAuth.signInWithCredential(firebaseCredential)
                    .addOnSuccessListener(resultAuth->{
                        toast("Login Google berhasil ✓");
                        build();
                        startCloudSync();
                    })
                    .addOnFailureListener(e->{
                        Log.e("AbsenGoogle", "Firebase sign-in failed", e);
                        String msg=firebaseErrorMessage(e);
                        showLoginError(msg);
                    });
        }catch(Exception e){
            Log.e("AbsenGoogle", "Google ID token parsing/handling failed", e);
            showLoginError("Credential Google tidak valid ("+e.getClass().getSimpleName()+")");
        }
    }

    String firebaseErrorMessage(Exception e){
        if(e instanceof FirebaseAuthException){
            String code=((FirebaseAuthException)e).getErrorCode();
            if("ERROR_INVALID_CREDENTIAL".equals(code)) return "Credential Google ditolak Firebase (ERROR_INVALID_CREDENTIAL)";
            if("ERROR_IDP_RESPONSE_DENIED".equals(code)) return "Google menolak proses Login (ERROR_IDP_RESPONSE_DENIED)";
            if("ERROR_OPERATION_NOT_ALLOWED".equals(code)) return "Login Google belum diizinkan di Firebase (ERROR_OPERATION_NOT_ALLOWED)";
            if("ERROR_INVALID_API_KEY".equals(code)) return "Konfigurasi Firebase API key tidak valid (ERROR_INVALID_API_KEY)";
            if("ERROR_APP_NOT_AUTHORIZED".equals(code)) return "Aplikasi Android belum diotorisasi di Firebase/Google (ERROR_APP_NOT_AUTHORIZED)";
            return "Login Firebase gagal ("+code+")";
        }
        return "Login Firebase gagal ("+safeError(e)+")";
    }

    String safeError(Exception e){
        String m=e==null?null:e.getMessage();
        if(m==null||m.trim().isEmpty())return "silakan coba lagi";
        return m.length()>90?m.substring(0,90):m;
    }

    String generateSecureNonce(){
        try{
            byte[] bytes=new byte[32];
            new SecureRandom().nextBytes(bytes);
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            byte[] hash=digest.digest(bytes);
            StringBuilder out=new StringBuilder(hash.length*2);
            for(byte b:hash)out.append(String.format(Locale.US,"%02x",b));
            return out.toString();
        }catch(Exception e){
            return Long.toHexString(System.nanoTime())+Long.toHexString(new SecureRandom().nextLong());
        }
    }

    void startCloudSync(){
        if(cloudState!=null && cloudListener!=null){
            cloudState.removeEventListener(cloudListener);
        }
        if(cloudConnection!=null && cloudConnectionListener!=null){
            cloudConnection.removeEventListener(cloudConnectionListener);
        }

        FirebaseDatabase db=FirebaseDatabase.getInstance(FIREBASE_DB_URL);
        cloudState=db.getReference("cv_hikmah_tani").child("state");
        cloudConnection=db.getReference(".info/connected");
        cloudReady=true;
        setCloudStatus("☁ Menghubungkan ke Firebase…");

        cloudConnectionListener=new ValueEventListener(){
            @Override public void onDataChange(DataSnapshot snapshot){
                Boolean connected=snapshot.getValue(Boolean.class);
                cloudConnected=Boolean.TRUE.equals(connected);
                if(cloudConnected){
                    if(restoringBackup){
                        setCloudStatus("☁ Online • menyimpan backup…");
                        syncRestoredLocalToCloud(0);
                        return;
                    }
                    setCloudStatus("☁ Online • memeriksa data…");
                    // Saat aplikasi pertama kali dibuka, listener state bisa menerima
                    // snapshot null sebelum koneksi benar-benar online. Pada kondisi itu
                    // callback state tidak selalu terpanggil lagi hanya karena koneksi
                    // berubah. Periksa ulang state sekali setiap kali koneksi online agar
                    // data lokal dapat mengisi database yang masih kosong, atau sebaliknya
                    // data cloud dapat langsung diterapkan ke perangkat ini.
                    cloudState.addListenerForSingleValueEvent(new ValueEventListener(){
                        @Override public void onDataChange(DataSnapshot stateSnapshot){
                            if(!stateSnapshot.exists()){
                                syncAllLocalToCloud();
                            }else{
                                applyRemoteSnapshot(stateSnapshot);
                            }
                        }
                        @Override public void onCancelled(DatabaseError error){
                            setCloudStatus("☁ Ditolak: "+error.getCode()+" - "+error.getMessage());
                        }
                    });
                }else{
                    setCloudStatus("☁ Offline • menunggu koneksi");
                }
            }
            @Override public void onCancelled(DatabaseError error){
                cloudConnected=false;
                setCloudStatus("☁ Error koneksi: "+error.getCode()+" - "+error.getMessage());
            }
        };
        cloudConnection.addValueEventListener(cloudConnectionListener);

        cloudListener=new ValueEventListener(){
            @Override public void onDataChange(DataSnapshot snapshot){
                if(!snapshot.exists()){
                    // Hanya isi database yang benar-benar kosong setelah koneksi online.
                    // Jangan pernah menimpa database yang sudah memiliki data remote.
                    if(cloudConnected) syncAllLocalToCloud();
                    return;
                }
                applyRemoteSnapshot(snapshot);
            }
            @Override public void onCancelled(DatabaseError error){
                remoteApplying=false;
                cloudConnected=false;
                setCloudStatus("☁ Ditolak: "+error.getCode()+" - "+error.getMessage());
                toast("Sinkronisasi Firebase ditolak: "+error.getMessage());
            }
        };
        cloudState.addValueEventListener(cloudListener);
    }

    boolean cloudSnapshotMatchesLocal(DataSnapshot snapshot){
        HashMap<String,Object> local=new HashMap<>();
        for(Map.Entry<String,?> entry:prefs.getAll().entrySet()){
            Object v=entry.getValue();
            if(v instanceof Boolean || v instanceof String) local.put(entry.getKey(),v);
        }
        int count=0;
        for(DataSnapshot child:snapshot.getChildren()){
            count++;
            Object remote=child.getValue();
            Object mine=local.get(child.getKey());
            if(mine==null || !String.valueOf(mine).equals(String.valueOf(remote))) return false;
        }
        return count==local.size();
    }

    void applyRemoteSnapshot(DataSnapshot snapshot){
        if(restoringBackup || localCloudWrite) return;
        if(cloudSnapshotMatchesLocal(snapshot)){
            setCloudStatus("☁ Online • tersinkron ✓");
            return;
        }
        remoteApplying=true;
        try{
            SharedPreferences.Editor e=prefs.edit();
            e.clear();
            for(DataSnapshot child:snapshot.getChildren()){
                String keyName=child.getKey();
                if(keyName==null || keyName.startsWith("__")) continue;
                Object v=child.getValue();
                if(v instanceof Boolean) e.putBoolean(keyName,(Boolean)v);
                else if(v instanceof String) e.putString(keyName,(String)v);
                else if(v!=null) e.putString(keyName,String.valueOf(v));
            }
            e.commit();
        }finally{
            remoteApplying=false;
        }
        setCloudStatus("☁ Online • data HP lain diterima ✓");
        runOnUiThread(()->{
            try{ build(); }
            catch(Exception ex){ Log.e("AbsenUI","Gagal memperbarui tampilan dari Firebase",ex); }
        });
    }

    void setCloudStatus(String text){
        if(cloudStatus!=null) runOnUiThread(()->cloudStatus.setText(text));
    }

    void syncAllLocalToCloud(){
        if(!cloudReady || cloudState==null || remoteApplying || !cloudConnected)return;
        HashMap<String,Object> values=new HashMap<>();
        for(Map.Entry<String,?> entry:prefs.getAll().entrySet()){
            Object v=entry.getValue();
            if(v instanceof Boolean || v instanceof String) values.put(entry.getKey(),v);
        }
        cloudState.setValue(values).addOnCompleteListener(task->{
            if(task.isSuccessful()){
                setCloudStatus("☁ Online • tersimpan di cloud ✓");
            }else{
                String msg=task.getException()==null?"gagal menulis data":safeError(task.getException());
                setCloudStatus("☁ Gagal sinkron: "+msg);
                toast("Firebase gagal menyimpan: "+msg);
            }
        });
    }

    void cloudPut(String key,Object value){
        if(!cloudReady || cloudState==null || !cloudConnected || remoteApplying || restoringBackup) {
            if(!cloudConnected) setCloudStatus("☁ Offline • perubahan lokal tersimpan");
            return;
        }
        localCloudWrite=true;
        cloudState.runTransaction(new Transaction.Handler(){
            @Override public Transaction.Result doTransaction(MutableData currentData){
                Object raw=currentData.getValue();
                Map<String,Object> map=new HashMap<>();
                if(raw instanceof Map){
                    for(Map.Entry<?,?> en:((Map<?,?>)raw).entrySet()){
                        if(en.getKey()!=null) map.put(String.valueOf(en.getKey()),en.getValue());
                    }
                }
                map.put(key,value);
                currentData.setValue(map);
                return Transaction.success(currentData);
            }
            @Override public void onComplete(DatabaseError error,boolean committed,DataSnapshot snapshot){
                localCloudWrite=false;
                if(error==null && committed) setCloudStatus("☁ Online • tersinkron ✓");
                else if(error!=null){
                    String msg=error.getCode()+" - "+error.getMessage();
                    setCloudStatus("☁ Gagal sinkron: "+msg);
                    toast("Firebase gagal menyimpan: "+msg);
                }
            }
        });
    }

    void cloudRemove(String key){
        if(!cloudReady || cloudState==null || !cloudConnected || remoteApplying || restoringBackup) return;
        localCloudWrite=true;
        cloudState.runTransaction(new Transaction.Handler(){
            @Override public Transaction.Result doTransaction(MutableData currentData){
                Object raw=currentData.getValue();
                Map<String,Object> map=new HashMap<>();
                if(raw instanceof Map){
                    for(Map.Entry<?,?> en:((Map<?,?>)raw).entrySet()){
                        if(en.getKey()!=null) map.put(String.valueOf(en.getKey()),en.getValue());
                    }
                }
                map.remove(key);
                currentData.setValue(map);
                return Transaction.success(currentData);
            }
            @Override public void onComplete(DatabaseError error,boolean committed,DataSnapshot snapshot){
                localCloudWrite=false;
                if(error==null && committed) setCloudStatus("☁ Online • tersinkron ✓");
                else if(error!=null) setCloudStatus("☁ Gagal sinkron: "+error.getCode()+" - "+error.getMessage());
            }
        });
    }

    String appTitle(){ return prefs.getString(KEY_APP,"ABSEN CV HIKMAH TANI"); }

    private void toast(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    String[] getNames(String key, String[] defaults){
        String raw=prefs.getString(key,null);
        if(raw==null || raw.trim().isEmpty()) return defaults.clone();
        String[] a=raw.split("\\n",-1);
        ArrayList<String> out=new ArrayList<>();
        for(String s:a){ s=s.trim(); if(!s.isEmpty()) out.add(s); }
        return out.isEmpty()?defaults.clone():out.toArray(new String[0]);
    }
    String[] maleNames(){ return getNames(KEY_MALE,DEFAULT_MALE); }
    String[] femaleNames(){ return getNames(KEY_FEMALE,DEFAULT_FEMALE); }

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    GradientDrawable bg(int color,float radius){
        GradientDrawable g=new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        return g;
    }

    GradientDrawable gradientBg(int start,int end,float radius){
        GradientDrawable g=new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{start,end});
        g.setCornerRadius(dp(radius));
        return g;
    }

    Button btn(String text) {
        Button b=new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextSize(13);
        b.setTextColor(Color.rgb(43,47,54));
        b.setMinHeight(0); b.setMinWidth(0);
        b.setPadding(dp(5),0,dp(5),0); b.setGravity(Gravity.CENTER);
        b.setBackground(bg(Color.WHITE,10)); b.setElevation(dp(1));
        // Tombol absensi tidak boleh mengambil fokus keyboard/navigasi yang dapat
        // membuat ScrollView otomatis menggeser posisi saat ditekan.
        b.setFocusable(false);
        b.setFocusableInTouchMode(false);
        return b;
    }

    void styleAction(Button b,int color,boolean white){
        b.setTextColor(white?Color.WHITE:Color.rgb(43,47,54));
        b.setBackground(bg(color,12)); b.setElevation(dp(2));
    }


    void buildLogin(){
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22),dp(24),dp(22),dp(24));
        root.setBackground(gradientBg(Color.rgb(10,24,38),Color.rgb(94,25,47),0));

        Space top=new Space(this);
        root.addView(top,new LinearLayout.LayoutParams(1,0,1));

        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(22),dp(24),dp(22),dp(24));
        card.setBackground(bg(Color.rgb(250,247,242),24));
        card.setElevation(dp(8));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(430));
        root.addView(card,cp);

        ImageView icon=new ImageView(this);
        icon.setImageResource(com.hikmahtani.absen.R.drawable.app_icon);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        card.addView(icon,new LinearLayout.LayoutParams(dp(105),dp(105)));

        TextView brand=new TextView(this);
        brand.setText("ABSEN CV HIKMAH TANI");
        brand.setTextSize(22); brand.setTypeface(null,Typeface.BOLD);
        brand.setTextColor(Color.rgb(20,38,54)); brand.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(46));
        bp.setMargins(0,dp(8),0,0); card.addView(brand,bp);

        TextView welcome=new TextView(this);
        welcome.setText("Selamat datang\nSilakan masuk untuk melanjutkan");
        welcome.setTextSize(14); welcome.setTextColor(Color.rgb(92,90,91));
        welcome.setGravity(Gravity.CENTER); welcome.setLineSpacing(2,1.0f);
        LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-1,dp(58));
        wp.setMargins(0,dp(2),0,dp(18)); card.addView(welcome,wp);

        Button login=btn("Masuk dengan Google");
        login.setTextSize(15); login.setTypeface(null,Typeface.BOLD);
        login.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_myplaces,0,0,0);
        login.setCompoundDrawablePadding(dp(8));
        styleAction(login,Color.rgb(156,35,53),true);
        card.addView(login,new LinearLayout.LayoutParams(-1,dp(58)));

        Button diag=btn("Periksa konfigurasi Login Google");
        diag.setTextSize(11);
        diag.setTypeface(null,Typeface.BOLD);
        styleAction(diag,Color.rgb(34,71,99),false);
        LinearLayout.LayoutParams dpms=new LinearLayout.LayoutParams(-1,dp(42));
        dpms.setMargins(0,dp(8),0,0);
        card.addView(diag,dpms);

        TextView secure=new TextView(this);
        secure.setText("🔒 Login aman dengan Google & Firebase");
        secure.setTextSize(12); secure.setTextColor(Color.rgb(92,90,91));
        secure.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(40));
        sp.setMargins(0,dp(12),0,0); card.addView(secure,sp);

        TextView footer=new TextView(this);
        footer.setText("Akses absensi hanya setelah akun berhasil masuk.");
        footer.setTextSize(11); footer.setTextColor(Color.argb(210,255,255,255));
        footer.setGravity(Gravity.CENTER);
        root.addView(footer,new LinearLayout.LayoutParams(-1,dp(54)));

        Space bottom=new Space(this);
        root.addView(bottom,new LinearLayout.LayoutParams(1,0,1));
        setContentView(root);

        login.setOnClickListener(v->requestGoogleSignIn());
        diag.setOnClickListener(v->showGoogleDiagnostics());
    }

    void showGoogleDiagnostics(){
        String sha1=getSigningSha1();
        String sha256=getSigningSha256();
        String webClient="(tidak tersedia)";
        try{ webClient=getString(R.string.default_web_client_id); }catch(Exception ignored){}
        String msg="Package aplikasi:\n"+getPackageName()+
                "\n\nSHA-1 APK saat ini:\n"+sha1+
                "\n\nSHA-256 APK saat ini:\n"+sha256+
                "\n\nWeb Client ID:\n"+webClient+
                "\n\nUntuk Google Sign-In, SHA-1 APK ini harus terdaftar pada Firebase Android App yang sama.\n\nJika SHA-1 berbeda dengan yang ada di Firebase, tambahkan SHA-1 ini ke Firebase lalu download google-services.json terbaru.";
        new AlertDialog.Builder(this).setTitle("Diagnostik Login Google V7").setMessage(msg)
                .setPositiveButton("Tutup",null).show();
    }

    String getSigningSha1(){ return getSigningFingerprint("SHA-1"); }
    String getSigningSha256(){ return getSigningFingerprint("SHA-256"); }
    String getSigningFingerprint(String algorithm){
        try{
            PackageManager pm=getPackageManager();
            PackageInfo pi;
            if(Build.VERSION.SDK_INT>=28) pi=pm.getPackageInfo(getPackageName(),PackageManager.GET_SIGNING_CERTIFICATES);
            else pi=pm.getPackageInfo(getPackageName(),PackageManager.GET_SIGNATURES);
            byte[] cert;
            if(Build.VERSION.SDK_INT>=28){
                Signature[] sigs=pi.signingInfo.hasMultipleSigners()?pi.signingInfo.getApkContentsSigners():pi.signingInfo.getSigningCertificateHistory();
                cert=sigs[0].toByteArray();
            }else cert=pi.signatures[0].toByteArray();
            MessageDigest md=MessageDigest.getInstance(algorithm);
            byte[] digest=md.digest(cert);
            StringBuilder out=new StringBuilder();
            for(int i=0;i<digest.length;i++){if(i>0)out.append(":");out.append(String.format(Locale.US,"%02X",digest[i]));}
            return out.toString();
        }catch(Exception e){ return "Tidak dapat membaca sertifikat ("+e.getClass().getSimpleName()+")"; }
    }

    void build() {
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10),dp(8),dp(10),dp(8));
        root.setBackgroundColor(Color.rgb(247,244,239));

        TextView title=new TextView(this);
        title.setText(appTitle()); title.setTextSize(21);
        title.setTextColor(Color.WHITE); title.setTypeface(null,Typeface.BOLD);
        title.setGravity(Gravity.CENTER); title.setPadding(dp(14),0,dp(14),0);
        title.setBackground(gradientBg(Color.rgb(12,35,55),Color.rgb(122,28,54),16)); title.setElevation(dp(3));
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(62)));

        TextView sub=new TextView(this);
        sub.setText("ABSENSI 15 HARI  •  Pagi + Sore = 1 hari");
        sub.setTextSize(12); sub.setTextColor(Color.rgb(96,99,103));
        sub.setGravity(Gravity.CENTER); sub.setPadding(0,dp(5),0,dp(2));
        root.addView(sub,new LinearLayout.LayoutParams(-1,dp(30)));

        FirebaseUser activeUser=firebaseAuth==null?null:firebaseAuth.getCurrentUser();
        TextView accountLine=new TextView(this);
        accountLine.setText(activeUser!=null && activeUser.getEmail()!=null ? "👤 "+activeUser.getEmail() : "👤 Akun Google");
        accountLine.setTextSize(11); accountLine.setTextColor(Color.rgb(107,80,87));
        accountLine.setGravity(Gravity.CENTER);
        root.addView(accountLine,new LinearLayout.LayoutParams(-1,dp(24)));

        cloudStatus=new TextView(this);
        cloudStatus.setText(cloudConnected ? "☁ Online • tersinkron" : "☁ Menghubungkan ke Firebase…");
        cloudStatus.setTextSize(11); cloudStatus.setTypeface(null,Typeface.BOLD);
        cloudStatus.setTextColor(Color.rgb(19,116,105)); cloudStatus.setGravity(Gravity.CENTER);
        cloudStatus.setPadding(dp(4),0,dp(4),0);
        root.addView(cloudStatus,new LinearLayout.LayoutParams(-1,dp(24)));

        LinearLayout top=new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL); top.setPadding(dp(4),0,dp(4),dp(4));
        daySpinner=new Spinner(this);
        String[] days=new String[15];
        for(int i=0;i<15;i++) days[i]="Hari "+(i+1);
        daySpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,days));
        top.addView(daySpinner,new LinearLayout.LayoutParams(-1,dp(52)));
        daySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){currentDay=pos+1;render();}
        });
        root.addView(top);

        LinearLayout actions2=new LinearLayout(this); actions2.setPadding(dp(2),0,dp(2),dp(3));
        Button csv=btn("⬇  Rekap CSV"), pdf=btn("▣  PDF"), backup=btn("▣  Backup"), restore=btn("↥  Pulihkan");
        styleAction(csv,Color.rgb(218,239,231),false); styleAction(pdf,Color.rgb(220,231,244),false);
        styleAction(backup,Color.rgb(245,231,201),false); styleAction(restore,Color.rgb(235,220,238),false);
        actions2.addView(csv,new LinearLayout.LayoutParams(0,dp(52),1));
        actions2.addView(pdf,new LinearLayout.LayoutParams(0,dp(52),1));
        actions2.addView(backup,new LinearLayout.LayoutParams(0,dp(52),1));
        actions2.addView(restore,new LinearLayout.LayoutParams(0,dp(52),1)); root.addView(actions2);

        LinearLayout actions3=new LinearLayout(this); actions3.setPadding(dp(2),0,dp(2),dp(5));
        Button reset=btn("↻  Reset absensi"), settings=btn("⚙  Pengaturan nama");
        styleAction(reset,Color.rgb(244,214,220),false); styleAction(settings,Color.rgb(218,228,239),false);
        actions3.addView(reset,new LinearLayout.LayoutParams(0,dp(52),1));
        actions3.addView(settings,new LinearLayout.LayoutParams(0,dp(52),1)); root.addView(actions3);

        sv=new ScrollView(this); sv.setFillViewport(true); sv.setFocusable(false); sv.setFocusableInTouchMode(false);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(2),0,dp(2),dp(8)); sv.addView(list);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);

        csv.setOnClickListener(v->exportCsv()); pdf.setOnClickListener(v->makePdf());
        backup.setOnClickListener(v->backup()); restore.setOnClickListener(v->pickBackup());
        reset.setOnClickListener(v->confirmReset()); settings.setOnClickListener(v->showSettings());
        render();
    }


    boolean here(String n,int d,String s){return prefs.getBoolean(key(n,d,s),false);}
    String key(String n,int d,String s){return n+"_"+d+"_"+s;}

    void setHere(View clicked,String n,int d,String s,boolean val){
        String k=key(n,d,s);
        prefs.edit().putBoolean(k,val).apply();
        cloudPut(k,val);

        if(clicked instanceof Button){
            Button b=(Button)clicked;
            int accent="pagi".equals(s)?Color.rgb(18,125,110):Color.rgb(86,73,151);
            styleSession(b,val,accent);
            ViewParent parent=b.getParent();
            if(parent instanceof LinearLayout){
                LinearLayout row=(LinearLayout)parent;
                if(row.getChildCount()>3 && row.getChildAt(3) instanceof TextView){
                    TextView totalView=(TextView)row.getChildAt(3);
                    totalView.setText(String.valueOf(total(n)).replace(".0",""));
                }
            }
            b.clearFocus();
            // Restaure posisi yang sedang dilihat setelah Android menyelesaikan
            // event klik. Tidak ada render ulang daftar.
            if(sv!=null){
                final int y=sv.getScrollY();
                sv.postDelayed(()->sv.scrollTo(0,y),40);
            }
        }
        Toast.makeText(this,"Tersimpan otomatis ✓",Toast.LENGTH_SHORT).show();
    }

    double total(String n){
        double x=0;
        for(int d=1;d<=15;d++){if(here(n,d,"pagi"))x+=.5;if(here(n,d,"sore"))x+=.5;}
        return x;
    }

    TextView label(String s,int size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(47,52,59));
        t.setPadding(dp(8),dp(6),dp(4),dp(6)); return t;
    }


    void render(){
        if(list==null)return;
        final int savedScrollY = sv==null ? 0 : sv.getScrollY();
        list.removeAllViews();
        TextView info=label("HARI "+currentDay+"   •   Pagi + sore = 1 hari   •   1 sesi = 0,5",14);
        info.setGravity(Gravity.CENTER); info.setTypeface(null,Typeface.BOLD);
        info.setTextColor(Color.rgb(18,48,62)); info.setBackground(gradientBg(Color.rgb(226,242,238),Color.rgb(240,230,214),12));
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(46)); ip.setMargins(0,0,0,dp(2));
        list.addView(info,ip);
        section("Laki-laki",maleNames(),Color.rgb(19,116,105));
        section("Perempuan",femaleNames(),Color.rgb(132,61,103));
        // Render ulang daftar absensi tanpa mengubah posisi scroll.
        // Sebelumnya setiap klik Pagi/Sore memanggil render(), sehingga ScrollView
        // kembali ke bagian paling atas dan pengguna kehilangan posisi nama yang sedang dikerjakan.
        if(sv!=null){
            sv.post(() -> sv.scrollTo(0,savedScrollY));
        }
    }


    void section(String gender,String[] names,int accent){
        TextView h=label(gender+"  •  "+names.length+" orang",17);
        h.setTypeface(null,Typeface.BOLD); h.setTextColor(Color.WHITE);
        h.setGravity(Gravity.CENTER_VERTICAL); h.setPadding(dp(12),0,dp(12),0);
        h.setBackground(bg(accent,10)); h.setElevation(dp(2));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(44));
        hp.setMargins(0,dp(7),0,dp(4)); list.addView(h,hp);

        for(int i=0;i<names.length;i++){
            String n=names[i];
            LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(5),dp(3),dp(5),dp(3));
            r.setBackground(bg(i%2==0?Color.WHITE:Color.rgb(244,241,242),10));

            TextView name=label((i+1)+". "+n,14);
            name.setSingleLine(true); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            name.setGravity(Gravity.CENTER_VERTICAL);
            r.addView(name,new LinearLayout.LayoutParams(0,dp(64),1));

            Button p=btn("Pagi"),so=btn("Sore");
            styleSession(p,here(n,currentDay,"pagi"),Color.rgb(18,125,110));
            styleSession(so,here(n,currentDay,"sore"),Color.rgb(86,73,151));

            TextView t=label(String.valueOf(total(n)).replace(".0",""),18);
            t.setGravity(Gravity.CENTER); t.setTypeface(null,Typeface.BOLD);
            t.setTextColor(accent); t.setSingleLine(true);

            r.addView(p,new LinearLayout.LayoutParams(dp(88),dp(58)));
            r.addView(so,new LinearLayout.LayoutParams(dp(88),dp(58)));
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(dp(56),dp(58));
            tp.setMargins(dp(3),0,0,0); r.addView(t,tp);

            p.setOnClickListener(v->setHere(v,n,currentDay,"pagi",!here(n,currentDay,"pagi")));
            so.setOnClickListener(v->setHere(v,n,currentDay,"sore",!here(n,currentDay,"sore")));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(64));
            rp.setMargins(0,dp(2),0,dp(2)); list.addView(r,rp);
        }
    }

    void styleSession(Button b,boolean selected,int accent){
        b.setTypeface(null,Typeface.BOLD); b.setElevation(dp(1));
        if(selected){
            b.setTextColor(Color.WHITE); b.setBackground(bg(accent,10));
        }else{
            b.setTextColor(accent); b.setBackground(bg(Color.rgb(233,236,239),10));
        }
    }

    void markAll(String sess){
        SharedPreferences.Editor e=prefs.edit();
        for(String n:maleNames())e.putBoolean(key(n,currentDay,sess),true);
        for(String n:femaleNames())e.putBoolean(key(n,currentDay,sess),true);
        e.apply();
        for(String n:maleNames()) cloudPut(key(n,currentDay,sess),true);
        for(String n:femaleNames()) cloudPut(key(n,currentDay,sess),true);
        render();Toast.makeText(this,"Semua "+sess+" tersimpan ✓",Toast.LENGTH_SHORT).show();
    }

    double dayVal(String n,int d){
        boolean a=here(n,d,"pagi"),b=here(n,d,"sore");return a&&b?1:((a||b)?0.5:0);
    }

    double dailyGrandTotal(int d){
        double x=0;
        for(String n:maleNames()) x+=dayVal(n,d);
        for(String n:femaleNames()) x+=dayVal(n,d);
        return x;
    }

    String csvCell(String v){
        return "\"" + v.replace("\"","\"\"") + "\"";
    }

    void exportCsv(){
        StringBuilder x=new StringBuilder("\ufeff");
        x.append(csvCell("No")).append(",").append(csvCell("Nama")).append(",").append(csvCell("Jenis Kelamin"));
        for(int d=1;d<=15;d++)x.append(",").append(csvCell("Hari "+d));
        x.append(",").append(csvCell("TOTAL HARI")).append("\n");

        int no=1;
        for(String n:maleNames()){
            x.append(no++).append(",").append(csvCell(n)).append(",").append(csvCell("Laki-laki"));
            for(int d=1;d<=15;d++)x.append(",").append(dayVal(n,d));
            x.append(",").append(total(n)).append("\n");
        }
        for(String n:femaleNames()){
            x.append(no++).append(",").append(csvCell(n)).append(",").append(csvCell("Perempuan"));
            for(int d=1;d<=15;d++)x.append(",").append(dayVal(n,d));
            x.append(",").append(total(n)).append("\n");
        }

        // Rekap total per hari: 1 = dua sesi, 0,5 = satu sesi.
        x.append(",").append(csvCell("TOTAL KEHADIRAN HARIAN")).append(",").append(csvCell("Semua"));
        for(int d=1;d<=15;d++)x.append(",").append(dailyGrandTotal(d));
        x.append(",").append(csvCell("-")).append("\n");

        File f=new File(getExternalFilesDir(null),"Rekap_Total_Absen_CV_Hikmah_Tani.csv");
        try(FileOutputStream o=new FileOutputStream(f)){
            o.write(x.toString().getBytes("UTF-8"));
            share(f,"text/csv");
        }catch(Exception e){toast("Gagal membuat CSV");}
    }

    void share(File f,String type){
        Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
        Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i,"Bagikan / Simpan"));
    }


    void backup(){
        try{
            JSONObject root=new JSONObject();root.put("app","Absen CV Hikmah Tani");root.put("appName",appTitle());
            JSONArray ma=new JSONArray();for(String n:maleNames())ma.put(n);root.put("male",ma);
            JSONArray fe=new JSONArray();for(String n:femaleNames())fe.put(n);root.put("female",fe);
            JSONArray at=new JSONArray();
            for(Map.Entry<String,?> e:prefs.getAll().entrySet())if(e.getValue() instanceof Boolean && Boolean.TRUE.equals(e.getValue()))at.put(e.getKey());
            root.put("attendance",at);
            // also keep a simple data object for compatibility
            JSONObject data=new JSONObject();for(int i=0;i<at.length();i++)data.put(at.getString(i),true);root.put("data",data);
            File f=new File(getExternalFilesDir(null),"BACKUP_Absen_CV_Hikmah_Tani.json");
            try(FileOutputStream o=new FileOutputStream(f)){o.write(root.toString(2).getBytes("UTF-8"));}
            share(f,"application/json");
        }catch(Exception e){toast("Backup gagal: "+e.getMessage());}
    }

    void pickBackup(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/json","text/plain","*/*"});
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,77);
    }

    void clearAttendance(SharedPreferences.Editor e){
        for(String n:allKnownNames())for(int d=1;d<=15;d++){e.remove(key(n,d,"pagi"));e.remove(key(n,d,"sore"));}
    }

    HashSet<String> allKnownNames(){
        HashSet<String> s=new HashSet<>();
        Collections.addAll(s,DEFAULT_MALE);Collections.addAll(s,DEFAULT_FEMALE);
        Collections.addAll(s,maleNames());Collections.addAll(s,femaleNames());
        return s;
    }

    String[] jsonNames(JSONObject o,String key,String[] fallback)throws Exception{
        if(!o.has(key))return fallback.clone();
        JSONArray a=o.getJSONArray(key);ArrayList<String> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){String n=a.getString(i).trim();if(!n.isEmpty())out.add(n);}
        return out.isEmpty()?fallback.clone():out.toArray(new String[0]);
    }

    void migrateNames(String[] oldMale,String[] oldFemale,String[] newMale,String[] newFemale,SharedPreferences.Editor e){
        for(int i=0;i<Math.min(oldMale.length,newMale.length);i++)copyAttendance(oldMale[i],newMale[i],e);
        for(int i=0;i<Math.min(oldFemale.length,newFemale.length);i++)copyAttendance(oldFemale[i],newFemale[i],e);
    }

    void copyAttendance(String oldN,String newN,SharedPreferences.Editor e){
        if(oldN.equals(newN))return;
        for(int d=1;d<=15;d++)for(String s:new String[]{"pagi","sore"})
            if(here(oldN,d,s))e.putBoolean(key(newN,d,s),true);
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==REQ_GOOGLE_LEGACY){
            try{
                com.google.android.gms.auth.api.signin.GoogleSignInAccount legacyAccount =
                        GoogleSignIn.getSignedInAccountFromIntent(d).getResult(ApiException.class);
                if(legacyAccount==null || legacyAccount.getIdToken()==null){
                    signInInProgress=false;
                    toast("Login Google dibatalkan atau akun tidak tersedia");
                    return;
                }
                signInInProgress=false;
                AuthCredential firebaseCredential=GoogleAuthProvider.getCredential(legacyAccount.getIdToken(),null);
                firebaseAuth.signInWithCredential(firebaseCredential)
                        .addOnSuccessListener(resultAuth->{
                            toast("Login Google berhasil ✓");
                            build();
                            startCloudSync();
                        })
                        .addOnFailureListener(e->{
                            Log.e("AbsenGoogle","Firebase legacy sign-in failed",e);
                            showLoginError(firebaseErrorMessage(e));
                        });
            }catch(ApiException e){
                signInInProgress=false;
                Log.e("AbsenGoogle","Legacy Google Sign-In result error: "+e.getStatusCode(),e);
                if(e.getStatusCode()==12501 || e.getStatusCode()==16){
                    toast("Login Google dibatalkan");
                }else if(e.getStatusCode()==10){
                    showLoginError("DEVELOPER_ERROR (kode 10): SHA-1 signing APK tidak cocok dengan konfigurasi Google/Firebase.");
                }else{
                    showLoginError("Login Google gagal (kode "+e.getStatusCode()+")");
                }
            }catch(Exception e){
                signInInProgress=false;
                Log.e("AbsenGoogle","Legacy Google Sign-In unexpected error",e);
                showLoginError("Hasil Login Google tidak dapat diproses");
            }
            return;
        }
        if(r!=77)return;
        if(c!=RESULT_OK || d==null || d.getData()==null){
            toast("Pemulihan dibatalkan");
            return;
        }
        Uri backupUri=d.getData();
        try{
            StringBuilder sb=new StringBuilder();
            try(InputStream in=getContentResolver().openInputStream(backupUri)){
                if(in==null)throw new IOException("File tidak dapat dibuka");
                try(BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"))){
                    char[] buf=new char[4096];
                    int n;
                    while((n=br.read(buf))!=-1)sb.append(buf,0,n);
                }
            }
            String json=sb.toString();
            if(json.length()>0 && json.charAt(0)=='\ufeff')json=json.substring(1);
            json=json.trim();
            if(json.isEmpty())throw new Exception("File backup kosong");

            JSONObject root=new JSONObject(json);
            boolean hasData=root.has("attendance") || root.has("data");
            boolean hasNames=root.has("male") || root.has("female");
            String app=root.optString("app","").trim();
            // Terima backup lama/baru selama strukturnya memang milik aplikasi.
            // Ini menjaga kompatibilitas jika nama aplikasi pernah diubah.
            boolean knownApp=app.isEmpty() ||
                    "Absen CV Hikmah Tani".equalsIgnoreCase(app) ||
                    "ABSEN CV HIKMAH TANI".equalsIgnoreCase(app);
            if(!knownApp || (!hasData && !hasNames))
                throw new Exception("Format backup tidak dikenali");

            String[] oldMale=maleNames(),oldFemale=femaleNames();
            String[] newMale=jsonNames(root,"male",oldMale);
            String[] newFemale=jsonNames(root,"female",oldFemale);
            SharedPreferences.Editor e=prefs.edit();
            clearAttendance(e);

            int restored=0;
            if(root.has("attendance")){
                JSONArray a=root.getJSONArray("attendance");
                for(int i=0;i<a.length();i++){
                    String k=a.optString(i,"").trim();
                    if(!k.isEmpty()){e.putBoolean(k,true);restored++;}
                }
            }else if(root.has("data")){
                JSONObject data=root.getJSONObject("data");
                Iterator<String> it=data.keys();
                while(it.hasNext()){
                    String k=it.next();
                    if(data.optBoolean(k,false)){e.putBoolean(k,true);restored++;}
                }
            }

            e.putString(KEY_MALE,android.text.TextUtils.join("\n",newMale));
            e.putString(KEY_FEMALE,android.text.TextUtils.join("\n",newFemale));
            if(root.has("appName")){
                String restoredTitle=root.optString("appName","").trim();
                if(!restoredTitle.isEmpty())e.putString(KEY_APP,restoredTitle);
            }
            e.apply();

            // Backup adalah perintah eksplisit dari pengguna: jangan biarkan
            // listener Firebase mengembalikan data cloud lama sebelum hasil
            // restore sempat ditulis ke database.
            restoringBackup=true;
            syncRestoredLocalToCloud(restored);
            build();
            toast("Backup berhasil dipulihkan ✓ ("+restored+" absensi)");
        }catch(JSONException e){
            Log.e("AbsenBackup","JSON backup tidak valid",e);
            toast("Backup tidak valid: format JSON rusak");
        }catch(SecurityException e){
            Log.e("AbsenBackup","Tidak punya akses ke file backup",e);
            toast("Backup tidak bisa dibaca: izin file ditolak");
        }catch(Exception e){
            Log.e("AbsenBackup","Gagal memulihkan backup",e);
            String msg=e.getMessage();
            if(msg==null || msg.trim().isEmpty())msg="file tidak bisa dibaca";
            toast("Backup gagal: "+msg);
        }
    }

    void syncRestoredLocalToCloud(int restored){
        if(restoreUploadInProgress) return;
        if(!cloudReady || cloudState==null || !cloudConnected){
            setCloudStatus("☁ Offline • backup tersimpan di perangkat");
            return;
        }
        restoreUploadInProgress=true;
        remoteApplying=true;
        HashMap<String,Object> values=new HashMap<>();
        for(Map.Entry<String,?> entry:prefs.getAll().entrySet()){
            Object v=entry.getValue();
            if(v instanceof Boolean || v instanceof String) values.put(entry.getKey(),v);
        }
        cloudState.setValue(values).addOnCompleteListener(task->{
            restoreUploadInProgress=false;
            remoteApplying=false;
            if(task.isSuccessful()){
                restoringBackup=false;
                setCloudStatus("☁ Online • backup tersimpan di cloud ✓");
            }else{
                setCloudStatus("☁ Gagal sinkron: "+safeError(task.getException()));
                toast("Backup lokal tersimpan, tetapi Firebase gagal: "+safeError(task.getException()));
            }
        });
    }

    void confirmReset(){
        new AlertDialog.Builder(this).setTitle("Reset semua absensi?")
            .setMessage("Semua data Pagi dan Sore selama 15 hari akan dihapus. Nama dan pengaturan tetap.")
            .setNegativeButton("Batal",null).setPositiveButton("Reset",(dialog,which)->resetAll()).show();
    }

    void resetAll(){
        try{
            SharedPreferences.Editor e=prefs.edit();
            clearAttendance(e);
            e.commit();

            if(cloudReady && cloudState!=null && cloudConnected){
                localCloudWrite=true;
                cloudState.runTransaction(new Transaction.Handler(){
                    @Override public Transaction.Result doTransaction(MutableData currentData){
                        Object raw=currentData.getValue();
                        Map<String,Object> map=new HashMap<>();
                        if(raw instanceof Map){
                            for(Map.Entry<?,?> en:((Map<?,?>)raw).entrySet()){
                                if(en.getKey()==null) continue;
                                Object v=en.getValue();
                                // Semua nilai boolean di state adalah absensi.
                                if(!(v instanceof Boolean)) map.put(String.valueOf(en.getKey()),v);
                            }
                        }
                        currentData.setValue(map);
                        return Transaction.success(currentData);
                    }
                    @Override public void onComplete(DatabaseError error,boolean committed,DataSnapshot snapshot){
                        localCloudWrite=false;
                        if(error==null && committed) setCloudStatus("☁ Online • absensi cloud di-reset ✓");
                        else if(error!=null){
                            String msg=error.getCode()+" - "+error.getMessage();
                            setCloudStatus("☁ Gagal reset cloud: "+msg);
                            toast("Reset lokal berhasil, tetapi Firebase gagal: "+msg);
                        }
                    }
                });
            }else{
                setCloudStatus("☁ Offline • reset lokal tersimpan");
            }
            updateVisibleRowsAfterReset();
            toast("Semua absensi sudah di-reset ✓");
        }catch(Exception ex){
            Log.e("AbsenReset","Gagal reset absensi",ex);
            toast("Reset gagal: "+safeError(ex));
        }
    }

    void updateVisibleRowsAfterReset(){
        if(list==null)return;
        for(int i=0;i<list.getChildCount();i++){
            View v=list.getChildAt(i);
            if(v instanceof LinearLayout){
                LinearLayout row=(LinearLayout)v;
                if(row.getChildCount()>3 && row.getChildAt(1) instanceof Button && row.getChildAt(2) instanceof Button && row.getChildAt(3) instanceof TextView){
                    Button p=(Button)row.getChildAt(1), so=(Button)row.getChildAt(2);
                    styleSession(p,false,Color.rgb(18,125,110));
                    styleSession(so,false,Color.rgb(86,73,151));
                    ((TextView)row.getChildAt(3)).setText("0");
                }
            }
        }
    }

    void showSettings(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,8,24,4);
        Button app=btn("Ubah nama aplikasi");Button male=btn("Ubah nama laki-laki");Button female=btn("Ubah nama perempuan");Button reset=btn("Kembalikan nama bawaan");
        Button account=btn(firebaseAuth!=null&&firebaseAuth.getCurrentUser()!=null ? "Keluar dari akun Google" : "Masuk dengan Google");
        box.addView(app,new LinearLayout.LayoutParams(-1,58));box.addView(male,new LinearLayout.LayoutParams(-1,58));box.addView(female,new LinearLayout.LayoutParams(-1,58));box.addView(reset,new LinearLayout.LayoutParams(-1,58));box.addView(account,new LinearLayout.LayoutParams(-1,58));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("⚙ Pengaturan").setView(box).setNegativeButton("Tutup",null).create();
        app.setOnClickListener(v->{dlg.dismiss();editSingle("Nama aplikasi",appTitle(),val->{prefs.edit().putString(KEY_APP,val).apply(); cloudPut(KEY_APP,val); build();});});
        male.setOnClickListener(v->{dlg.dismiss();editList("Nama laki-laki",maleNames(),KEY_MALE);});
        female.setOnClickListener(v->{dlg.dismiss();editList("Nama perempuan",femaleNames(),KEY_FEMALE);});
        reset.setOnClickListener(v->{prefs.edit().remove(KEY_MALE).remove(KEY_FEMALE).remove(KEY_APP).apply();
            cloudRemove(KEY_MALE); cloudRemove(KEY_FEMALE); cloudRemove(KEY_APP);
            build();toast("Nama dikembalikan ke bawaan");});
        account.setOnClickListener(v->{
            dlg.dismiss();
            if(firebaseAuth!=null&&firebaseAuth.getCurrentUser()!=null){
                confirmLogout();
            }else{
                requestGoogleSignIn();
            }
        });
        dlg.show();
    }

    void confirmLogout(){
        new AlertDialog.Builder(this)
                .setTitle("Keluar dari akun?")
                .setMessage("Anda akan kembali ke halaman login. Data absensi di perangkat tidak dihapus.")
                .setNegativeButton("Batal",null)
                .setPositiveButton("Keluar",(dialog,which)->logout())
                .show();
    }

    void logout(){
        if(cloudState!=null && cloudListener!=null){
            cloudState.removeEventListener(cloudListener);
        }
        if(cloudConnection!=null && cloudConnectionListener!=null){
            cloudConnection.removeEventListener(cloudConnectionListener);
        }
        cloudState=null;
        cloudListener=null;
        cloudConnection=null;
        cloudConnectionListener=null;
        cloudReady=false;
        cloudConnected=false;
        if(firebaseAuth!=null) firebaseAuth.signOut();
        if(legacyGoogleClient!=null){
            try{ legacyGoogleClient.signOut(); }catch(Exception ignored){}
        }
        if(credentialManager!=null){
            try{
                credentialManager.clearCredentialStateAsync(
                        new ClearCredentialStateRequest(),
                        new CancellationSignal(),
                        ContextCompat.getMainExecutor(this),
                        new CredentialManagerCallback<Void, androidx.credentials.exceptions.ClearCredentialException>() {
                            @Override public void onResult(Void result){}
                            @Override public void onError(androidx.credentials.exceptions.ClearCredentialException e){}
                        });
            }catch(Exception ignored){}
        }
        buildLogin();
        toast("Anda sudah keluar dari akun");
    }

    interface ValueCallback{void save(String value);}
    void editSingle(String title,String current,ValueCallback cb){
        EditText input=new EditText(this);input.setText(current);input.setSelectAllOnFocus(true);input.setSingleLine(true);input.setPadding(24,0,24,0);
        new AlertDialog.Builder(this).setTitle(title).setView(input).setNegativeButton("Batal",null)
            .setPositiveButton("Simpan",(d,w)->{String v=input.getText().toString().trim();if(!v.isEmpty())cb.save(v);else toast("Nama tidak boleh kosong");}).show();
    }

    void editList(String title,String[] current,String prefKey){
        EditText input=new EditText(this);input.setText(android.text.TextUtils.join("\n",current));input.setGravity(Gravity.TOP);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        input.setMinLines(Math.min(20,current.length));input.setPadding(24,8,24,8);
        new AlertDialog.Builder(this).setTitle(title+" (satu nama per baris)").setView(input).setNegativeButton("Batal",null)
            .setPositiveButton("Simpan",(d,w)->saveNameList(input.getText().toString(),prefKey,current)).show();
    }

    void saveNameList(String raw,String prefKey,String[] oldNames){
        ArrayList<String> a=new ArrayList<>();for(String s:raw.split("\\r?\\n")){s=s.trim();if(!s.isEmpty())a.add(s);}
        if(a.isEmpty()){toast("Daftar nama tidak boleh kosong");return;}
        String[] nn=a.toArray(new String[0]);
        SharedPreferences.Editor e=prefs.edit();
        migrateNames(oldNames, new String[0], prefKey.equals(KEY_MALE)?nn:new String[0], prefKey.equals(KEY_FEMALE)?nn:new String[0], e);
        e.putString(prefKey,android.text.TextUtils.join("\n",nn));e.apply();
        cloudPut(prefKey,android.text.TextUtils.join("\n",nn));
        build();toast("Daftar nama tersimpan ✓");
    }

    void drawPdfTableHeader(Canvas c, Paint p, float[] col, float y, float rowH){
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(7);
        p.setColor(Color.rgb(240,232,213));
        c.drawRect(col[0],y,col[18],y+rowH,p);

        p.setColor(Color.DKGRAY);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1);
        for(float xx:col)c.drawLine(xx,y,xx,y+rowH,p);
        c.drawLine(col[0],y,col[18],y,p);
        c.drawLine(col[0],y+rowH,col[18],y+rowH,p);

        p.setStyle(Paint.Style.FILL);
        String[] h=new String[18];
        h[0]="No";
        h[1]="Nama";
        for(int i=0;i<15;i++)h[i+2]="H"+(i+1);
        h[17]="Total";

        for(int i=0;i<18;i++){
            float cx=(col[i]+col[i+1])/2f;
            float tw=p.measureText(h[i]);
            c.drawText(h[i],cx-tw/2,y+13,p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    boolean drawPdfRows(Canvas c, Paint p, float[] col, float y, float rowH,
                        String gender, String[] names, int[] noHolder, boolean headerAlready){
        if(!headerAlready){
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(9);p.setColor(Color.rgb(156,35,53));
            c.drawText(gender,20,y+12,p);y+=18;
        }
        drawPdfTableHeader(c,p,col,y,rowH);y+=rowH;

        p.setTypeface(Typeface.DEFAULT);p.setTextSize(7);
        for(String n:names){
            if(y+rowH>575) return false;
            p.setColor(Color.DKGRAY);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(.7f);
            c.drawRect(col[0],y,col[col.length-1],y+rowH,p);
            for(float xx:col)c.drawLine(xx,y,xx,y+rowH,p);
            p.setStyle(Paint.Style.FILL);
            c.drawText(String.valueOf(noHolder[0]++),col[0]+5,y+12,p);
            String name=n;
            if(name.length()>22)name=name.substring(0,22);
            c.drawText(name,col[1]+4,y+12,p);
            for(int d=1;d<=15;d++){
                String v=String.valueOf(dayVal(n,d)).replace(".0","");
                float cx=(col[d+1]+col[d+2])/2f;
                float tw=p.measureText(v);
                c.drawText(v,cx-tw/2,y+12,p);
            }
            String tv=String.valueOf(total(n)).replace(".0","")+"";
            float cx=(col[17]+col[18])/2f,tw=p.measureText(tv);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(tv,cx-tw/2,y+12,p);
            p.setTypeface(Typeface.DEFAULT);
            y+=rowH;
        }
        return true;
    }

    void makePdf(){
        PdfDocument doc=new PdfDocument();
        final int W=842,H=595;
        // Kolom PDF diperbaiki agar 15 kolom Hari memiliki lebar sama
        // dan H15 tidak bertumpuk dengan kolom Total.
        final float[] col=new float[19];
        col[0]=20;                 // kiri
        col[1]=50;                 // No
        col[2]=220;                // awal H1 (Nama = 170)
        for(int i=3;i<=17;i++)col[i]=220+(i-2)*36; // H1-H15, 36pt/kolom
        col[18]=822;               // akhir Total

        int pageNo=1;
        PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(W,H,pageNo).create();
        PdfDocument.Page page=doc.startPage(pi);
        Canvas c=page.getCanvas();
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.DKGRAY);

        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(16);
        c.drawText(appTitle()+" - REKAP ABSENSI 15 HARI",20,24,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(8);
        c.drawText("Keterangan: 1 = Pagi+sore hadir penuh, 0,5 = satu sesi, 0 = tidak hadir",20,38,p);

        int[] noHolder={1};
        float y=48;
        // Draw male section, handling page breaks
        String[] groups={ "LAKI-LAKI", "PEREMPUAN" };
        String[][] lists={ maleNames(), femaleNames() };
        for(int g=0;g<2;g++){
            if(y+36>H-20){
                doc.finishPage(page);pageNo++;
                page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,pageNo).create());
                c=page.getCanvas();y=24;
                p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(14);
                c.drawText(appTitle()+" - REKAP ABSENSI",20,y,p);y+=20;
            }
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(9);p.setColor(Color.rgb(156,35,53));
            c.drawText(groups[g],20,y+10,p);y+=16;

            // Header + rows, manually so we can page-break safely
            drawPdfTableHeader(c,p,col,y,20);y+=20;
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(7);
            for(String n:lists[g]){
                if(y+20>H-20){
                    doc.finishPage(page);pageNo++;
                    page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,pageNo).create());
                    c=page.getCanvas();y=24;
                    p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(12);
                    c.drawText(appTitle()+" - REKAP ABSENSI (lanjutan)",20,y,p);y+=18;
                    drawPdfTableHeader(c,p,col,y,20);y+=20;
                    p.setTypeface(Typeface.DEFAULT);p.setTextSize(7);
                }
                p.setColor(Color.DKGRAY);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(.7f);
                c.drawRect(col[0],y,col[18],y+20,p);
                for(float xx:col)c.drawLine(xx,y,xx,y+20,p);
                p.setStyle(Paint.Style.FILL);
                c.drawText(String.valueOf(noHolder[0]++),col[0]+5,y+13,p);
                String name=n.length()>22?n.substring(0,22):n;
                c.drawText(name,col[1]+4,y+13,p);
                for(int d=1;d<=15;d++){
                    String v=String.valueOf(dayVal(n,d)).replace(".0","");
                    float cx=(col[d+1]+col[d+2])/2f,tw=p.measureText(v);
                    c.drawText(v,cx-tw/2,y+13,p);
                }
                String tv=String.valueOf(total(n)).replace(".0","");
                float cx=(col[17]+col[18])/2f,tw=p.measureText(tv);
                p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText(tv,cx-tw/2,y+13,p);p.setTypeface(Typeface.DEFAULT);
                y+=20;
            }
            y+=8;
        }

        // Baris total seluruh peserta untuk masing-masing Hari 1-15.
        if(y+20>H-20){
            doc.finishPage(page);pageNo++;
            page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,pageNo).create());
            c=page.getCanvas();y=24;
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(12);p.setColor(Color.DKGRAY);
            c.drawText(appTitle()+" - REKAP TOTAL HARIAN",20,y,p);y+=18;
        }
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(7);p.setColor(Color.rgb(240,232,213));
        c.drawRect(col[0],y,col[18],y+20,p);
        p.setStyle(Paint.Style.STROKE);p.setColor(Color.DKGRAY);p.setStrokeWidth(.7f);
        c.drawRect(col[0],y,col[18],y+20,p);
        for(float xx:col)c.drawLine(xx,y,xx,y+20,p);
        p.setStyle(Paint.Style.FILL);p.setColor(Color.DKGRAY);
        c.drawText("TOTAL HARIAN",col[0]+3,y+13,p);
        for(int d=1;d<=15;d++){
            String v=String.valueOf(dailyGrandTotal(d)).replace(".0","");
            float cx=(col[d+1]+col[d+2])/2f,tw=p.measureText(v);
            c.drawText(v,cx-tw/2,y+13,p);
        }
        p.setTypeface(Typeface.DEFAULT);
        c.drawText("-",(col[17]+col[18])/2f-2,y+13,p);
        doc.finishPage(page);

        File f=new File(getExternalFilesDir(null),"Rekap_Absen_CV_Hikmah_Tani.pdf");
        try(FileOutputStream o=new FileOutputStream(f)){
            doc.writeTo(o);doc.close();share(f,"application/pdf");
        }catch(Exception e){
            try{doc.close();}catch(Exception ignored){}
            toast("PDF gagal dibuat");
        }
    }

}
