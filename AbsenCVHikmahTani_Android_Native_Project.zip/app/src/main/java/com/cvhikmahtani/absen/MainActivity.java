package com.cvhikmahtani.absen;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import androidx.core.content.FileProvider;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final String[] male = {"SLAMET","BIRIN","KURNIA","JOHAN","NENDI","KABUL","PIYAN","UDIN","JUNAEDI","ASEP C","ADE T","ANGGI","ANTO","AGUNG","RIJAL","DIKA","EKO","AANG","AGUNG GT","CICI","GIMIN","ALI","BENI","ASEP M","DEDI","BUYUNG","JALI","ADE CUMARNO","JONI H","ROJAK","USUP","AMANG","AHMAD","P. USTAD","IRMAN","TOMI","D. MARJI","IPAT"};
    final String[] female = {"DEDEH","TINI","ENTUN","ONEH","TITI","IIS","NURUL","YUYUN","SUTIAH","EPON","NENG AGUS","AMBU","YANI","NURSIAH","TITIN","TUSIAH","SOLEHAH","GIYEM","SANTI","TETEH","M. IBAH","MARINAH","KHOTIMAH","MBA SUM"};
    ArrayList<String> names = new ArrayList<>();
    SharedPreferences prefs; LinearLayout list; int day=1;
    final String PREF="absen_cv_hikmah_tani_v1";

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        prefs=getSharedPreferences(PREF,MODE_PRIVATE); list=findViewById(R.id.list);
        for(String n:male) names.add(n); for(String n:female) names.add(n);
        findViewById(R.id.dayButton).setOnClickListener(v->chooseDay());
        findViewById(R.id.summaryButton).setOnClickListener(v->showSummary());
        findViewById(R.id.allMorning).setOnClickListener(v->markAll("P"));
        findViewById(R.id.allEvening).setOnClickListener(v->markAll("S"));
        findViewById(R.id.backup).setOnClickListener(v->backup());
        findViewById(R.id.restore).setOnClickListener(v->restore());
        render();
    }

    boolean present(String n,int d,String s){return prefs.getBoolean(key(n,d,s),false);}
    String key(String n,int d,String s){return "d"+d+"_"+s+"_"+n;}
    void set(String n,int d,String s,boolean v){prefs.edit().putBoolean(key(n,d,s),v).apply();}
    double total(String n){double x=0;for(int d=1;d<=15;d++){if(present(n,d,"P"))x+=.5;if(present(n,d,"S"))x+=.5;}return x;}

    Button attendanceButton(String n,String s){
        Button b=new Button(this); b.setText(s.equals("P")?"Pagi":"Sore");
        b.setTextSize(12); b.setAllCaps(false); b.setMinHeight(0); b.setMinWidth(0);
        b.setPadding(2,0,2,0); updateButton(b,present(n,day,s));
        b.setOnClickListener(v->{boolean nv=!present(n,day,s);set(n,day,s,nv);updateButton(b,nv);toast("Tersimpan otomatis ✓"); updateTotals();});
        return b;
    }
    void updateButton(Button b,boolean active){b.setTextColor(active?Color.WHITE:Color.DKGRAY);b.setBackgroundColor(active?Color.rgb(47,111,62):Color.rgb(245,245,245));}

    void render(){
        ((TextView)findViewById(R.id.dateText)).setText("Hari "+day+"  •  "+dateFor(day));
        ((Button)findViewById(R.id.dayButton)).setText("Hari "+day+" ▼");
        list.removeAllViews(); addGroup("LAKI-LAKI",male); addGroup("PEREMPUAN",female);
    }
    void addGroup(String title,String[] arr){
        TextView h=new TextView(this);h.setText(title);h.setTextSize(18);h.setTextStyle(android.graphics.Typeface.BOLD);
        h.setTextColor(Color.rgb(30,70,35));h.setBackgroundColor(Color.rgb(232,241,233));h.setPadding(12,14,12,14);list.addView(h);
        for(int i=0;i<arr.length;i++){
            String n=arr[i]; LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(4,3,4,3);row.setBackgroundColor(Color.WHITE);
            TextView no=new TextView(this);no.setText((i+1)+"");no.setGravity(Gravity.CENTER);row.addView(no,new LinearLayout.LayoutParams(dp(34),dp(52)));
            TextView nm=new TextView(this);nm.setText(n);nm.setTextSize(15);nm.setTypeface(null,1);row.addView(nm,new LinearLayout.LayoutParams(0,dp(52),1));
            Button p=attendanceButton(n,"P"),s=attendanceButton(n,"S");row.addView(p,new LinearLayout.LayoutParams(dp(62),dp(48)));
            row.addView(s,new LinearLayout.LayoutParams(dp(62),dp(48)));
            TextView t=new TextView(this);t.setText(fmt(total(n)));t.setGravity(Gravity.CENTER);t.setTextSize(14);t.setTypeface(null,1);row.addView(t,new LinearLayout.LayoutParams(dp(52),dp(52)));
            list.addView(row); View line=new View(this);line.setBackgroundColor(Color.LTGRAY);list.addView(line,new LinearLayout.LayoutParams(-1,1));
        }
    }
    void updateTotals(){render();}

    String fmt(double x){return x==Math.rint(x)?String.valueOf((int)x):String.format(Locale.US,"%.1f",x);}
    String dateFor(int d){Calendar c=Calendar.getInstance();c.add(Calendar.DATE,d-1);return new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(c.getTime());}
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void chooseDay(){
        String[] a=new String[15];for(int i=0;i<15;i++)a[i]="Hari "+(i+1)+" — "+dateFor(i+1);
        new AlertDialog.Builder(this).setTitle("Pilih hari").setItems(a,(d,w)->{day=w+1;render();}).show();
    }
    void markAll(String s){
        for(String n:names)set(n,day,s,true);render();toast("Semua hadir "+(s.equals("P")?"pagi":"sore")+" ✓");
    }
    void showSummary(){
        StringBuilder b=new StringBuilder("REKAP ABSEN CV HIKMAH TANI\n\n");
        int i=1;for(String n:names)b.append(i++).append(". ").append(n).append(" — ").append(fmt(total(n))).append(" hari\n");
        b.append("\nPagi+sore = 1 hari; satu sesi = 0,5 hari.");
        new AlertDialog.Builder(this).setTitle("Total 15 Hari").setMessage(b.toString()).setPositiveButton("Tutup",null)
            .setNeutralButton("Simpan PDF",(d,w)->createPdf()).show();
    }
    void createPdf(){
        PdfDocument doc=new PdfDocument();Paint p=new Paint();p.setTextSize(11);
        PdfDocument.Page page=null;Canvas c=null;int y=0,pageNo=0;
        for(int i=0;i<names.size();i++){
            if(i%38==0){if(page!=null)doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());c=page.getCanvas();y=35;p.setTextSize(16);c.drawText("ABSEN CV HIKMAH TANI — REKAP 15 HARI",30,y,p);y+=25;p.setTextSize(11);}
            c.drawText((i+1)+". "+names.get(i),30,y,p);c.drawText(fmt(total(names.get(i)))+" hari",430,y,p);y+=19;
        }
        if(page!=null)doc.finishPage(page);
        try{
            File dir=getExternalFilesDir(null);File f=new File(dir,"Rekap_Absen_CV_Hikmah_Tani.pdf");
            FileOutputStream out=new FileOutputStream(f);doc.writeTo(out);out.close();doc.close();
            Intent in=new Intent(Intent.ACTION_SEND);in.setType("application/pdf");in.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f));
            in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(in,"Kirim / simpan PDF"));
        }catch(Exception e){toast("Gagal membuat PDF: "+e.getMessage());}
    }
    void backup(){
        try{
            JSONObjectLite o=new JSONObjectLite();for(String n:names)for(int d=1;d<=15;d++)for(String s:new String[]{"P","S"})if(present(n,d,s))o.put(key(n,d,s),"1");
            File f=new File(getExternalFilesDir(null),"Backup_Absen_CV_Hikmah_Tani.txt");FileOutputStream out=new FileOutputStream(f);out.write(o.toString().getBytes("UTF-8"));out.close();
            Intent in=new Intent(Intent.ACTION_SEND);in.setType("text/plain");in.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f));in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(in,"Simpan backup"));
        }catch(Exception e){toast("Backup gagal");}
    }
    void restore(){toast("Untuk versi ini, backup disimpan sebagai file. Pemulihan otomatis menggunakan data aplikasi.");}

    static class JSONObjectLite{
        StringBuilder b=new StringBuilder("{");boolean first=true;
        void put(String k,String v){if(!first)b.append(",");first=false;b.append("\"").append(k.replace("\"","")).append("\":\"").append(v).append("\"");}
        public String toString(){return b.append("}").toString();}
    }
}
