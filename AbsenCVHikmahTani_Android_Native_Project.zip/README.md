# Absen CV Hikmah Tani — Android Native

Project Android native (Java) untuk absensi 15 hari.

## Isi
- Pagi / Sore per nama
- Pagi + Sore = 1 hari
- Satu sesi = 0,5 hari
- Data otomatis tersimpan di SharedPreferences
- Rekap total 15 hari
- Export PDF
- Backup file
- CICI di kelompok laki-laki
- IPAT di kelompok perempuan
- EKO di kelompok laki-laki

## Cara build menjadi APK
Buka project ini di Android Studio terbaru, tunggu Gradle Sync, lalu:
Build > Build APK(s).

APK debug biasanya berada di:
app/build/outputs/apk/debug/app-debug.apk

Catatan: project membutuhkan koneksi internet pertama kali untuk mengunduh Android Gradle Plugin dan dependency AndroidX.
