V9 BACKUP RESTORE FIX
- Restore uses Android ACTION_OPEN_DOCUMENT with JSON MIME filters.
- Accepts legacy/current backup app labels case-insensitively.
- Accepts backup containing attendance and/or names.
- Handles UTF-8 BOM and content:// URIs robustly.
- Shows detailed restore error instead of generic message.
- Keeps Firebase URL and V8 real-time sync unchanged.
