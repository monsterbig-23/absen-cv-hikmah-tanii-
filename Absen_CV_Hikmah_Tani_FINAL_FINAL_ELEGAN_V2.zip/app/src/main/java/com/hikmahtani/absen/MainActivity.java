package com.hikmahtani.absen;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import androidx.core.content.FileProvider;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String PREF="absen_data_v2";
    static final String KEY_MALE="names_male";
    static final String KEY_FEMALE="names_female";
    static final String KEY_APP="app_title";

    final String[] DEFAULT_MALE = {"SLAMET","BIRIN","KURNIA","JOHAN","NENDI","KABUL","PIYAN","UDIN","JUNAEDI","ASEP C","ADE T","ANGGI","ANTO","AGUNG","RIJAL","DIKA","EKO","AANG","AGUNG GT","CICI","GIMIN","ALI","BENI","ASEP M","DEDI","BUYUNG","JALI","ADE CUMARNO","JONI H","ROJAK","USUP","AMANG","AHMAD","P. USTAD","IRMAN","TOMI","D. MARJI"};
    final String[] DEFAULT_FEMALE = {"DEDEH","TINI","ENTUN","ONEH","TITI","IIS","NURUL","YUYUN","SUTIAH","EPON","NENG AGUS","AMBU","YANI","NURSIAH","TITIN","TUSIAH","SOLEHAH","GIYEM","SANTI","TETEH","M. IBAH","MARINAH","KHOTIMAH","MBA SUM","IPAT","IKA"};

    SharedPreferences prefs;
    LinearLayout list;
    Spinner daySpinner;
    int currentDay=1;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences(PREF,MODE_PRIVATE);
        build();
    }

    String appTitle(){ return prefs.getString(KEY_APP,"ABSEN CV HIKMAH TANI"); }

    private void toast(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    String[] getNames(String key, String[] defaults){
        String raw=prefs.getString(key,null);
        if(raw==null || raw.trim().isEmpty()) return defaults.clone();
        String[] a=raw.split("\\n",-1);
        ArrayList<String> out=new ArrayList<>();
        for(String s:a){ s=s.trim(); if(!s.isEmpty()) out.add(s); }
        return out.isEmpty()?defaults.clone():out.toArray(new String[0]);
    }
    String[] maleNames(){ return getNames(KEY_MALE,DEFAULT_MALE); }
    String[] femaleNames(){ return getNames(KEY_FEMALE,DEFAULT_FEMALE); }

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    GradientDrawable bg(int color,float radius){
        GradientDrawable g=new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        return g;
    }

    Button btn(String text) {
        Button b=new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextSize(13);
        b.setTextColor(Color.rgb(45,52,60));
        b.setMinHeight(0); b.setMinWidth(0);
        b.setPadding(dp(5),0,dp(5),0); b.setGravity(Gravity.CENTER);
        b.setBackground(bg(Color.WHITE,10)); b.setElevation(dp(1));
        return b;
    }

    void styleAction(Button b,int color,boolean white){
        b.setTextColor(white?Color.WHITE:Color.rgb(45,52,60));
        b.setBackground(bg(color,12)); b.setElevation(dp(2));
    }


    void build() {
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8),dp(7),dp(8),dp(7));
        root.setBackgroundColor(Color.rgb(246,248,250));

        TextView title=new TextView(this);
        title.setText(appTitle()); title.setTextSize(21);
        title.setTextColor(Color.WHITE); title.setTypeface(null,Typeface.BOLD);
        title.setGravity(Gravity.CENTER); title.setPadding(dp(14),0,dp(14),0);
        title.setBackground(bg(Color.rgb(30,55,74),14)); title.setElevation(dp(3));
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(62)));

        TextView sub=new TextView(this);
        sub.setText("ABSENSI 15 HARI  •  Pagi + Sore = 1 hari");
        sub.setTextSize(12); sub.setTextColor(Color.rgb(73,88,101));
        sub.setGravity(Gravity.CENTER); sub.setPadding(0,dp(5),0,dp(2));
        root.addView(sub,new LinearLayout.LayoutParams(-1,dp(30)));

        LinearLayout top=new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL); top.setPadding(dp(4),0,dp(4),dp(4));
        daySpinner=new Spinner(this);
        String[] days=new String[15];
        for(int i=0;i<15;i++) days[i]="Hari "+(i+1);
        daySpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,days));
        top.addView(daySpinner,new LinearLayout.LayoutParams(-1,dp(52)));
        daySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){currentDay=pos+1;render();}
        });
        root.addView(top);

        LinearLayout actions=new LinearLayout(this); actions.setPadding(dp(2),0,dp(2),dp(3));
        Button allP=btn("✓  Semua hadir pagi"), allS=btn("✓  Semua hadir sore");
        styleAction(allP,Color.rgb(31,118,103),true); styleAction(allS,Color.rgb(48,91,130),true);
        actions.addView(allP,new LinearLayout.LayoutParams(0,dp(58),1));
        actions.addView(allS,new LinearLayout.LayoutParams(0,dp(58),1)); root.addView(actions);

        LinearLayout actions2=new LinearLayout(this); actions2.setPadding(dp(2),0,dp(2),dp(3));
        Button csv=btn("⬇  Rekap CSV"), pdf=btn("▣  PDF"), backup=btn("▣  Backup"), restore=btn("↥  Pulihkan");
        styleAction(csv,Color.rgb(224,236,232),false); styleAction(pdf,Color.rgb(232,237,245),false);
        styleAction(backup,Color.rgb(242,235,217),false); styleAction(restore,Color.rgb(237,231,244),false);
        actions2.addView(csv,new LinearLayout.LayoutParams(0,dp(52),1));
        actions2.addView(pdf,new LinearLayout.LayoutParams(0,dp(52),1));
        actions2.addView(backup,new LinearLayout.LayoutParams(0,dp(52),1));
        actions2.addView(restore,new LinearLayout.LayoutParams(0,dp(52),1)); root.addView(actions2);

        LinearLayout actions3=new LinearLayout(this); actions3.setPadding(dp(2),0,dp(2),dp(5));
        Button reset=btn("↻  Reset absensi"), settings=btn("⚙  Pengaturan nama");
        styleAction(reset,Color.rgb(248,226,226),false); styleAction(settings,Color.rgb(224,231,239),false);
        actions3.addView(reset,new LinearLayout.LayoutParams(0,dp(52),1));
        actions3.addView(settings,new LinearLayout.LayoutParams(0,dp(52),1)); root.addView(actions3);

        ScrollView sv=new ScrollView(this); sv.setFillViewport(true);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(2),0,dp(2),dp(8)); sv.addView(list);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);

        allP.setOnClickListener(v->markAll("pagi")); allS.setOnClickListener(v->markAll("sore"));
        csv.setOnClickListener(v->exportCsv()); pdf.setOnClickListener(v->makePdf());
        backup.setOnClickListener(v->backup()); restore.setOnClickListener(v->pickBackup());
        reset.setOnClickListener(v->confirmReset()); settings.setOnClickListener(v->showSettings());
        render();
    }


    boolean here(String n,int d,String s){return prefs.getBoolean(key(n,d,s),false);}
    String key(String n,int d,String s){return n+"_"+d+"_"+s;}

    void setHere(String n,int d,String s,boolean val){
        prefs.edit().putBoolean(key(n,d,s),val).apply();
        render();
        Toast.makeText(this,"Tersimpan otomatis ✓",Toast.LENGTH_SHORT).show();
    }

    double total(String n){
        double x=0;
        for(int d=1;d<=15;d++){if(here(n,d,"pagi"))x+=.5;if(here(n,d,"sore"))x+=.5;}
        return x;
    }

    TextView label(String s,int size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(48,58,68));
        t.setPadding(dp(8),dp(6),dp(4),dp(6)); return t;
    }


    void render(){
        if(list==null)return;
        list.removeAllViews();
        TextView info=label("HARI "+currentDay+"   •   Pagi + sore = 1 hari   •   1 sesi = 0,5",14);
        info.setGravity(Gravity.CENTER); info.setTypeface(null,Typeface.BOLD);
        info.setTextColor(Color.rgb(30,55,74)); info.setBackground(bg(Color.rgb(224,235,239),12));
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(46)); ip.setMargins(0,0,0,dp(2));
        list.addView(info,ip);
        section("Laki-laki",maleNames(),Color.rgb(31,118,103));
        section("Perempuan",femaleNames(),Color.rgb(104,77,125));
    }


    void section(String gender,String[] names,int accent){
        TextView h=label(gender+"  •  "+names.length+" orang",17);
        h.setTypeface(null,Typeface.BOLD); h.setTextColor(Color.WHITE);
        h.setGravity(Gravity.CENTER_VERTICAL); h.setPadding(dp(12),0,dp(12),0);
        h.setBackground(bg(accent,10)); h.setElevation(dp(2));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(44));
        hp.setMargins(0,dp(7),0,dp(4)); list.addView(h,hp);

        for(int i=0;i<names.length;i++){
            String n=names[i];
            LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(5),dp(3),dp(5),dp(3));
            r.setBackground(bg(i%2==0?Color.WHITE:Color.rgb(242,245,247),10));

            TextView name=label((i+1)+". "+n,14);
            name.setSingleLine(true); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            name.setGravity(Gravity.CENTER_VERTICAL);
            r.addView(name,new LinearLayout.LayoutParams(0,dp(64),1));

            Button p=btn("Pagi"),so=btn("Sore");
            styleSession(p,here(n,currentDay,"pagi"),Color.rgb(31,118,103));
            styleSession(so,here(n,currentDay,"sore"),Color.rgb(48,91,130));

            TextView t=label(String.valueOf(total(n)).replace(".0",""),18);
            t.setGravity(Gravity.CENTER); t.setTypeface(null,Typeface.BOLD);
            t.setTextColor(accent); t.setSingleLine(true);

            r.addView(p,new LinearLayout.LayoutParams(dp(88),dp(58)));
            r.addView(so,new LinearLayout.LayoutParams(dp(88),dp(58)));
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(dp(56),dp(58));
            tp.setMargins(dp(3),0,0,0); r.addView(t,tp);

            p.setOnClickListener(v->setHere(n,currentDay,"pagi",!here(n,currentDay,"pagi")));
            so.setOnClickListener(v->setHere(n,currentDay,"sore",!here(n,currentDay,"sore")));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(64));
            rp.setMargins(0,dp(2),0,dp(2)); list.addView(r,rp);
        }
    }

    void styleSession(Button b,boolean selected,int accent){
        b.setTypeface(null,Typeface.BOLD); b.setElevation(dp(1));
        if(selected){
            b.setTextColor(Color.WHITE); b.setBackground(bg(accent,10));
        }else{
            b.setTextColor(accent); b.setBackground(bg(Color.rgb(232,237,240),10));
        }
    }

    void markAll(String sess){
        SharedPreferences.Editor e=prefs.edit();
        for(String n:maleNames())e.putBoolean(key(n,currentDay,sess),true);
        for(String n:femaleNames())e.putBoolean(key(n,currentDay,sess),true);
        e.apply();render();Toast.makeText(this,"Semua "+sess+" tersimpan ✓",Toast.LENGTH_SHORT).show();
    }

    double dayVal(String n,int d){
        boolean a=here(n,d,"pagi"),b=here(n,d,"sore");return a&&b?1:((a||b)?0.5:0);
    }

    double dailyGrandTotal(int d){
        double x=0;
        for(String n:maleNames()) x+=dayVal(n,d);
        for(String n:femaleNames()) x+=dayVal(n,d);
        return x;
    }

    String csvCell(String v){
        return "\"" + v.replace("\"","\"\"") + "\"";
    }

    void exportCsv(){
        StringBuilder x=new StringBuilder("\ufeff");
        x.append(csvCell("No")).append(",").append(csvCell("Nama")).append(",").append(csvCell("Jenis Kelamin"));
        for(int d=1;d<=15;d++)x.append(",").append(csvCell("Hari "+d));
        x.append(",").append(csvCell("TOTAL HARI")).append("\n");

        int no=1;
        for(String n:maleNames()){
            x.append(no++).append(",").append(csvCell(n)).append(",").append(csvCell("Laki-laki"));
            for(int d=1;d<=15;d++)x.append(",").append(dayVal(n,d));
            x.append(",").append(total(n)).append("\n");
        }
        for(String n:femaleNames()){
            x.append(no++).append(",").append(csvCell(n)).append(",").append(csvCell("Perempuan"));
            for(int d=1;d<=15;d++)x.append(",").append(dayVal(n,d));
            x.append(",").append(total(n)).append("\n");
        }

        // Rekap total per hari: 1 = dua sesi, 0,5 = satu sesi.
        x.append(",").append(csvCell("TOTAL KEHADIRAN HARIAN")).append(",").append(csvCell("Semua"));
        for(int d=1;d<=15;d++)x.append(",").append(dailyGrandTotal(d));
        x.append(",").append(csvCell("-")).append("\n");

        File f=new File(getExternalFilesDir(null),"Rekap_Total_Absen_CV_Hikmah_Tani.csv");
        try(FileOutputStream o=new FileOutputStream(f)){
            o.write(x.toString().getBytes("UTF-8"));
            share(f,"text/csv");
        }catch(Exception e){toast("Gagal membuat CSV");}
    }

    void share(File f,String type){
        Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
        Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i,"Bagikan / Simpan"));
    }


    void backup(){
        try{
            JSONObject root=new JSONObject();root.put("app","Absen CV Hikmah Tani");root.put("appName",appTitle());
            JSONArray ma=new JSONArray();for(String n:maleNames())ma.put(n);root.put("male",ma);
            JSONArray fe=new JSONArray();for(String n:femaleNames())fe.put(n);root.put("female",fe);
            JSONArray at=new JSONArray();
            for(Map.Entry<String,?> e:prefs.getAll().entrySet())if(e.getValue() instanceof Boolean && Boolean.TRUE.equals(e.getValue()))at.put(e.getKey());
            root.put("attendance",at);
            // also keep a simple data object for compatibility
            JSONObject data=new JSONObject();for(int i=0;i<at.length();i++)data.put(at.getString(i),true);root.put("data",data);
            File f=new File(getExternalFilesDir(null),"BACKUP_Absen_CV_Hikmah_Tani.json");
            try(FileOutputStream o=new FileOutputStream(f)){o.write(root.toString(2).getBytes("UTF-8"));}
            share(f,"application/json");
        }catch(Exception e){toast("Backup gagal: "+e.getMessage());}
    }

    void pickBackup(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,77);
    }

    void clearAttendance(SharedPreferences.Editor e){
        for(String n:allKnownNames())for(int d=1;d<=15;d++){e.remove(key(n,d,"pagi"));e.remove(key(n,d,"sore"));}
    }

    HashSet<String> allKnownNames(){
        HashSet<String> s=new HashSet<>();
        Collections.addAll(s,DEFAULT_MALE);Collections.addAll(s,DEFAULT_FEMALE);
        Collections.addAll(s,maleNames());Collections.addAll(s,femaleNames());
        return s;
    }

    String[] jsonNames(JSONObject o,String key,String[] fallback)throws Exception{
        if(!o.has(key))return fallback.clone();
        JSONArray a=o.getJSONArray(key);ArrayList<String> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){String n=a.getString(i).trim();if(!n.isEmpty())out.add(n);}
        return out.isEmpty()?fallback.clone():out.toArray(new String[0]);
    }

    void migrateNames(String[] oldMale,String[] oldFemale,String[] newMale,String[] newFemale,SharedPreferences.Editor e){
        for(int i=0;i<Math.min(oldMale.length,newMale.length);i++)copyAttendance(oldMale[i],newMale[i],e);
        for(int i=0;i<Math.min(oldFemale.length,newFemale.length);i++)copyAttendance(oldFemale[i],newFemale[i],e);
    }

    void copyAttendance(String oldN,String newN,SharedPreferences.Editor e){
        if(oldN.equals(newN))return;
        for(int d=1;d<=15;d++)for(String s:new String[]{"pagi","sore"})
            if(here(oldN,d,s))e.putBoolean(key(newN,d,s),true);
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r!=77||c!=RESULT_OK||d==null||d.getData()==null)return;
        try{
            InputStream in=getContentResolver().openInputStream(d.getData());
            BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));
            StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line).append('\n');br.close();
            JSONObject root=new JSONObject(sb.toString());
            if(!"Absen CV Hikmah Tani".equals(root.optString("app")))throw new Exception("Format backup bukan milik aplikasi");
            String[] oldMale=maleNames(),oldFemale=femaleNames();
            String[] newMale=jsonNames(root, "male", oldMale),newFemale=jsonNames(root, "female", oldFemale);
            SharedPreferences.Editor e=prefs.edit();
            clearAttendance(e);
            if(root.has("attendance")){
                JSONArray a=root.getJSONArray("attendance");
                for(int i=0;i<a.length();i++)e.putBoolean(a.getString(i),true);
            }else if(root.has("data")){
                JSONObject data=root.getJSONObject("data");Iterator<String> it=data.keys();
                while(it.hasNext()){String k=it.next();if(data.optBoolean(k,false))e.putBoolean(k,true);}
            }
            e.putString(KEY_MALE,android.text.TextUtils.join("\n",newMale));
            e.putString(KEY_FEMALE,android.text.TextUtils.join("\n",newFemale));
            if(root.has("appName"))e.putString(KEY_APP,root.optString("appName","ABSEN CV HIKMAH TANI"));
            e.apply();
            build();
            toast("Backup berhasil dipulihkan ✓");
        }catch(Exception e){toast("Backup tidak valid atau tidak bisa dibaca");}
    }

    void confirmReset(){
        new AlertDialog.Builder(this).setTitle("Reset semua absensi?")
            .setMessage("Semua data Pagi dan Sore selama 15 hari akan dihapus. Nama dan pengaturan tetap.")
            .setNegativeButton("Batal",null).setPositiveButton("Reset",(dialog,which)->resetAll()).show();
    }

    void resetAll(){
        SharedPreferences.Editor e=prefs.edit();clearAttendance(e);e.apply();render();toast("Semua absensi sudah di-reset ✓");
    }

    void showSettings(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,8,24,4);
        Button app=btn("Ubah nama aplikasi");Button male=btn("Ubah nama laki-laki");Button female=btn("Ubah nama perempuan");Button reset=btn("Kembalikan nama bawaan");
        box.addView(app,new LinearLayout.LayoutParams(-1,58));box.addView(male,new LinearLayout.LayoutParams(-1,58));box.addView(female,new LinearLayout.LayoutParams(-1,58));box.addView(reset,new LinearLayout.LayoutParams(-1,58));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("⚙ Pengaturan").setView(box).setNegativeButton("Tutup",null).create();
        app.setOnClickListener(v->{dlg.dismiss();editSingle("Nama aplikasi",appTitle(),val->{prefs.edit().putString(KEY_APP,val).apply();build();});});
        male.setOnClickListener(v->{dlg.dismiss();editList("Nama laki-laki",maleNames(),KEY_MALE);});
        female.setOnClickListener(v->{dlg.dismiss();editList("Nama perempuan",femaleNames(),KEY_FEMALE);});
        reset.setOnClickListener(v->{prefs.edit().remove(KEY_MALE).remove(KEY_FEMALE).remove(KEY_APP).apply();build();toast("Nama dikembalikan ke bawaan");});
        dlg.show();
    }

    interface ValueCallback{void save(String value);}
    void editSingle(String title,String current,ValueCallback cb){
        EditText input=new EditText(this);input.setText(current);input.setSelectAllOnFocus(true);input.setSingleLine(true);input.setPadding(24,0,24,0);
        new AlertDialog.Builder(this).setTitle(title).setView(input).setNegativeButton("Batal",null)
            .setPositiveButton("Simpan",(d,w)->{String v=input.getText().toString().trim();if(!v.isEmpty())cb.save(v);else toast("Nama tidak boleh kosong");}).show();
    }

    void editList(String title,String[] current,String prefKey){
        EditText input=new EditText(this);input.setText(android.text.TextUtils.join("\n",current));input.setGravity(Gravity.TOP);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        input.setMinLines(Math.min(20,current.length));input.setPadding(24,8,24,8);
        new AlertDialog.Builder(this).setTitle(title+" (satu nama per baris)").setView(input).setNegativeButton("Batal",null)
            .setPositiveButton("Simpan",(d,w)->saveNameList(input.getText().toString(),prefKey,current)).show();
    }

    void saveNameList(String raw,String prefKey,String[] oldNames){
        ArrayList<String> a=new ArrayList<>();for(String s:raw.split("\\r?\\n")){s=s.trim();if(!s.isEmpty())a.add(s);}
        if(a.isEmpty()){toast("Daftar nama tidak boleh kosong");return;}
        String[] nn=a.toArray(new String[0]);
        SharedPreferences.Editor e=prefs.edit();
        migrateNames(oldNames, new String[0], prefKey.equals(KEY_MALE)?nn:new String[0], prefKey.equals(KEY_FEMALE)?nn:new String[0], e);
        e.putString(prefKey,android.text.TextUtils.join("\n",nn));e.apply();build();toast("Daftar nama tersimpan ✓");
    }

    void drawPdfTableHeader(Canvas c, Paint p, float[] col, float y, float rowH){
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(7);
        p.setColor(Color.rgb(232,241,233));
        c.drawRect(20,y,col[col.length-1],y+rowH,p);
        p.setColor(Color.DKGRAY);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1);
        for(float xx:col)c.drawLine(xx,y,xx,y+rowH,p);
        c.drawLine(col[0],y,col[col.length-1],y,p);
        c.drawLine(col[0],y+rowH,col[col.length-1],y+rowH,p);
        p.setStyle(Paint.Style.FILL);
        String[] h=new String[19];
        h[0]="No";h[1]="Nama";
        for(int i=0;i<15;i++)h[i+2]="H"+(i+1);
        h[17]="Total";h[18]="";
        for(int i=0;i<18;i++){
            float cx=(col[i]+col[i+1])/2f;
            float tw=p.measureText(h[i]);
            c.drawText(h[i],cx-tw/2,y+13,p);
        }
        // Total column is col[17]..col[18]
        float cx=(col[17]+col[18])/2f, tw=p.measureText("Total");
        c.drawText("Total",cx-tw/2,y+13,p);
        p.setStyle(Paint.Style.STROKE);
        for(float xx:col)c.drawLine(xx,y,xx,y+rowH,p);
        p.setStyle(Paint.Style.FILL);
    }

    boolean drawPdfRows(Canvas c, Paint p, float[] col, float y, float rowH,
                        String gender, String[] names, int[] noHolder, boolean headerAlready){
        if(!headerAlready){
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(9);p.setColor(Color.rgb(47,111,62));
            c.drawText(gender,20,y+12,p);y+=18;
        }
        drawPdfTableHeader(c,p,col,y,rowH);y+=rowH;

        p.setTypeface(Typeface.DEFAULT);p.setTextSize(7);
        for(String n:names){
            if(y+rowH>575) return false;
            p.setColor(Color.DKGRAY);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(.7f);
            c.drawRect(col[0],y,col[col.length-1],y+rowH,p);
            for(float xx:col)c.drawLine(xx,y,xx,y+rowH,p);
            p.setStyle(Paint.Style.FILL);
            c.drawText(String.valueOf(noHolder[0]++),col[0]+5,y+12,p);
            String name=n;
            if(name.length()>22)name=name.substring(0,22);
            c.drawText(name,col[1]+4,y+12,p);
            for(int d=1;d<=15;d++){
                String v=String.valueOf(dayVal(n,d)).replace(".0","");
                float cx=(col[d+1]+col[d+2])/2f;
                float tw=p.measureText(v);
                c.drawText(v,cx-tw/2,y+12,p);
            }
            String tv=String.valueOf(total(n)).replace(".0","")+"";
            float cx=(col[17]+col[18])/2f,tw=p.measureText(tv);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(tv,cx-tw/2,y+12,p);
            p.setTypeface(Typeface.DEFAULT);
            y+=rowH;
        }
        return true;
    }

    void makePdf(){
        PdfDocument doc=new PdfDocument();
        final int W=842,H=595;
        final float[] col=new float[19];
        col[0]=20;col[1]=52;
        for(int i=2;i<=16;i++)col[i]=52+(i-1)*38;
        col[17]=622;col[18]=822;

        int pageNo=1;
        PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(W,H,pageNo).create();
        PdfDocument.Page page=doc.startPage(pi);
        Canvas c=page.getCanvas();
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.DKGRAY);

        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(16);
        c.drawText(appTitle()+" - REKAP ABSENSI 15 HARI",20,24,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(8);
        c.drawText("Keterangan: 1 = Pagi+sore hadir penuh, 0,5 = satu sesi, 0 = tidak hadir",20,38,p);

        int[] noHolder={1};
        float y=48;
        // Draw male section, handling page breaks
        String[] groups={ "LAKI-LAKI", "PEREMPUAN" };
        String[][] lists={ maleNames(), femaleNames() };
        for(int g=0;g<2;g++){
            if(y+36>H-20){
                doc.finishPage(page);pageNo++;
                page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,pageNo).create());
                c=page.getCanvas();y=24;
                p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(14);
                c.drawText(appTitle()+" - REKAP ABSENSI",20,y,p);y+=20;
            }
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(9);p.setColor(Color.rgb(47,111,62));
            c.drawText(groups[g],20,y+10,p);y+=16;

            // Header + rows, manually so we can page-break safely
            drawPdfTableHeader(c,p,col,y,20);y+=20;
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(7);
            for(String n:lists[g]){
                if(y+20>H-20){
                    doc.finishPage(page);pageNo++;
                    page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,pageNo).create());
                    c=page.getCanvas();y=24;
                    p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(12);
                    c.drawText(appTitle()+" - REKAP ABSENSI (lanjutan)",20,y,p);y+=18;
                    drawPdfTableHeader(c,p,col,y,20);y+=20;
                    p.setTypeface(Typeface.DEFAULT);p.setTextSize(7);
                }
                p.setColor(Color.DKGRAY);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(.7f);
                c.drawRect(col[0],y,col[18],y+20,p);
                for(float xx:col)c.drawLine(xx,y,xx,y+20,p);
                p.setStyle(Paint.Style.FILL);
                c.drawText(String.valueOf(noHolder[0]++),col[0]+5,y+13,p);
                String name=n.length()>22?n.substring(0,22):n;
                c.drawText(name,col[1]+4,y+13,p);
                for(int d=1;d<=15;d++){
                    String v=String.valueOf(dayVal(n,d)).replace(".0","");
                    float cx=(col[d+1]+col[d+2])/2f,tw=p.measureText(v);
                    c.drawText(v,cx-tw/2,y+13,p);
                }
                String tv=String.valueOf(total(n)).replace(".0","");
                float cx=(col[17]+col[18])/2f,tw=p.measureText(tv);
                p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText(tv,cx-tw/2,y+13,p);p.setTypeface(Typeface.DEFAULT);
                y+=20;
            }
            y+=8;
        }

        // Baris total seluruh peserta untuk masing-masing Hari 1-15.
        if(y+20>H-20){
            doc.finishPage(page);pageNo++;
            page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,pageNo).create());
            c=page.getCanvas();y=24;
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(12);p.setColor(Color.DKGRAY);
            c.drawText(appTitle()+" - REKAP TOTAL HARIAN",20,y,p);y+=18;
        }
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(7);p.setColor(Color.rgb(232,241,233));
        c.drawRect(col[0],y,col[18],y+20,p);
        p.setStyle(Paint.Style.STROKE);p.setColor(Color.DKGRAY);p.setStrokeWidth(.7f);
        c.drawRect(col[0],y,col[18],y+20,p);
        for(float xx:col)c.drawLine(xx,y,xx,y+20,p);
        p.setStyle(Paint.Style.FILL);p.setColor(Color.DKGRAY);
        c.drawText("TOTAL HARIAN",col[0]+3,y+13,p);
        for(int d=1;d<=15;d++){
            String v=String.valueOf(dailyGrandTotal(d)).replace(".0","");
            float cx=(col[d+1]+col[d+2])/2f,tw=p.measureText(v);
            c.drawText(v,cx-tw/2,y+13,p);
        }
        p.setTypeface(Typeface.DEFAULT);
        c.drawText("-",(col[17]+col[18])/2f-2,y+13,p);
        doc.finishPage(page);

        File f=new File(getExternalFilesDir(null),"Rekap_Absen_CV_Hikmah_Tani.pdf");
        try(FileOutputStream o=new FileOutputStream(f)){
            doc.writeTo(o);doc.close();share(f,"application/pdf");
        }catch(Exception e){
            try{doc.close();}catch(Exception ignored){}
            toast("PDF gagal dibuat");
        }
    }

}
