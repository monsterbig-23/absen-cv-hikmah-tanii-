# Absen CV Hikmah Tani

Versi final untuk build Android melalui GitHub Actions.

Perubahan:
- Tampilan tombol diperbaiki agar teks Pagi/Sore dan tombol menu terlihat.
- Tanggal kalender dihilangkan; hanya Hari 1-15.
- Reset absensi tersedia dengan konfirmasi.
- Backup dan Pulihkan menggunakan JSON, termasuk daftar nama dan nama aplikasi.
- Pengaturan nama: ubah nama aplikasi, daftar laki-laki, dan daftar perempuan.
- Perubahan nama berusaha mempertahankan data absensi berdasarkan urutan nama.
- IKA berada di daftar perempuan.
- Pagi + sore = 1 hari; satu sesi = 0,5 hari.


## Versi perbaikan V2
- Memperbaiki fungsi `toast()` yang sebelumnya menyebabkan error compile Java.
- Memastikan penggunaan `setTypeface()` yang kompatibel.


## Versi FINAL
- Tombol Pagi/Sore diperbesar.
- Kolom total hari diperlebar agar tidak terpotong.
- CSV dibuat sebagai tabel rekap yang lebih rapi.
- PDF dibuat landscape dengan tabel 15 hari dan total.


## FINAL ELEGAN
- Total per orang hanya menampilkan angka.
- Tombol Pagi/Sore lebih besar.
- Tampilan kartu dengan warna navy, teal, biru, ungu lembut, dan aksen hangat.


## Rekap harian
CSV dan PDF sekarang memiliki baris **TOTAL HARIAN** untuk Hari 1 sampai Hari 15, dihitung dari seluruh peserta dengan nilai 1 untuk Pagi+Sore dan 0,5 untuk satu sesi.


## V3 - perbaikan tabel PDF
- Lebar kolom H1-H15 dan Total dihitung konsisten.
- Kolom H15 tidak lagi bertabrakan dengan Total.
- Garis tabel dan baris total harian menggunakan batas kolom yang sama.
