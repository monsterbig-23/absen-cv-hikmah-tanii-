# Absen CV Hikmah Tani — ONLINE

Versi ini memakai Firebase Realtime Database agar beberapa perangkat dapat melihat dan mengubah data absensi yang sama secara realtime.

## Setup satu kali
1. Buat project di Firebase Console.
2. Tambahkan Android App dengan package name: `com.hikmahtani.absen`.
3. Download `google-services.json`.
4. Masukkan file tersebut ke folder `app/`.
5. Aktifkan Authentication > Sign-in method > Anonymous.
6. Buat Realtime Database.
7. Untuk pengujian, database boleh dibuat dalam Test mode. Setelah aplikasi berhasil, gunakan rules:

```json
{
  "rules": {
    ".read": "auth != null",
    ".write": "auth != null"
  }
}
```

## GitHub Actions
Setelah `google-services.json` berada di `app/`, workflow `.github/workflows/build-apk.yml` akan membangun APK debug.

## Cara kerja
- Semua perangkat memakai database `cv_hikmah_tani/state` yang sama.
- Perubahan Pagi/Sore dikirim ke cloud dan perangkat lain menerima perubahan realtime.
- Nama dan judul aplikasi juga disinkronkan.
- Reset absensi menjadi reset bersama.
- Jika internet terputus, Firebase tetap menggunakan cache lokal dan melakukan sinkronisasi saat koneksi kembali.


## Firebase Online

File `app/google-services.json` sudah terpasang dan package Android adalah
`com.hikmahtani.absen`.

Sebelum APK digunakan di beberapa HP:
1. Firebase Console -> Authentication -> Sign-in method -> aktifkan Anonymous.
2. Firebase Console -> Realtime Database -> buat database.
3. Gunakan Rules yang membutuhkan `auth != null` (jangan gunakan akses publik).
4. Build APK melalui GitHub Actions.

Aplikasi memakai Firebase Realtime Database pada node `cv_hikmah_tani/state`.
Perubahan absensi, daftar nama, dan judul aplikasi akan disinkronkan ke perangkat
lain yang memakai project Firebase yang sama.
