package com.hikmahtani.absen;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.CancellationSignal;
import android.util.Log;
import android.util.Base64;
import androidx.core.content.FileProvider;
import androidx.core.content.ContextCompat;
import androidx.credentials.ClearCredentialStateRequest;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.NoCredentialException;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.*;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import android.view.*;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.text.DateFormatSymbols;

public class MainActivity extends Activity {
    static final String PREF="absen_data_v2";
    static final String KEY_MALE="names_male";
    static final String KEY_FEMALE="names_female";
    static final String KEY_APP="app_title";
    static final String KEY_PENDING_FULL_SYNC="pending_full_sync";
    // Realtime Database dibuat di lokasi us-central1. Pakai URL eksplisit agar
    // kedua perangkat selalu terhubung ke instance database yang sama.
    static final int TOTAL_DAYS=16;
    static final int MAX_MONTH_DAYS=31;
    static final String KEY_PERIOD_YEAR="period_year";
    static final String KEY_PERIOD_MONTH="period_month";
    static final String KEY_PERIOD_SESSION="period_session";
    static final String KEY_STATUS_PREFIX="status_";
    static final String STATUS_NONE="";
    static final String STATUS_ABSENT="tidak_hadir";
    static final String STATUS_NO_MORNING="tidak_masuk_pagi";
    static final String STATUS_NO_AFTERNOON="tidak_masuk_sore";
    static final String FIREBASE_DB_URL="https://absensi-cv-hikmah-tani-default-rtdb.firebaseio.com";

    final String[] DEFAULT_MALE = {"SLAMET","BIRIN","KURNIA","JOHAN","NENDI","KABUL","PIYAN","UDIN","JUNAEDI","ASEP C","ADE T","ANGGI","ANTO","AGUNG","RIJAL","DIKA","EKO","AANG","AGUNG GT","CICI","GIMIN","ALI","BENI","ASEP M","DEDI","BUYUNG","JALI","ADE CUMARNO","JONI H","ROJAK","USUP","AMANG","AHMAD","P. USTAD","IRMAN","TOMI","D. MARJI"};
    final String[] DEFAULT_FEMALE = {"DEDEH","TINI","ENTUN","ONEH","TITI","IIS","NURUL","YUYUN","SUTIAH","EPON","NENG AGUS","AMBU","YANI","NURSIAH","TITIN","TUSIAH","SOLEHAH","GIYEM","SANTI","TETEH","M. IBAH","MARINAH","KHOTIMAH","MBA SUM","IPAT","IKA"};

    SharedPreferences prefs;
    LinearLayout list;
    ScrollView sv;
    Spinner daySpinner;
    int currentDay=1;
    int periodYear, periodMonth, periodSession, sessionStartDay, sessionEndDay;

    FirebaseAuth firebaseAuth;
    DatabaseReference cloudState;
    ValueEventListener cloudListener;
    CredentialManager credentialManager;
    boolean cloudReady=false;
    boolean cloudConnected=false;
    boolean remoteApplying=false;
    boolean restoringBackup=false;
    boolean restoreUploadInProgress=false;
    boolean fullCloudWriteInProgress=false;
    boolean pendingFullSync=false;
    boolean initialCloudCheckDone=false;
    int fullSyncRetryCount=0;
    boolean localChangedDuringFullSync=false;
    DatabaseReference cloudConnection;
    ValueEventListener cloudConnectionListener;
    TextView cloudStatus;
    boolean signInInProgress=false;
    GoogleSignInClient legacyGoogleClient;
    static final int REQ_GOOGLE_LEGACY=9001;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences(PREF,MODE_PRIVATE);
        pendingFullSync=prefs.getBoolean(KEY_PENDING_FULL_SYNC,false);
        initPeriodSettings();
        connectCloud();
    }

    void connectCloud(){
        try{
            firebaseAuth=FirebaseAuth.getInstance();
            credentialManager=CredentialManager.create(this);
            GoogleSignInOptions gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(getString(R.string.default_web_client_id))
                    .requestEmail()
                    .build();
            legacyGoogleClient=GoogleSignIn.getClient(this,gso);

            FirebaseUser current=firebaseAuth.getCurrentUser();
            if(current!=null){
                build();
                startCloudSync();
            }else{
                buildLogin();
            }
        }catch(Exception e){
            buildLogin();
            toast("Firebase belum terhubung");
        }
    }

    void requestGoogleSignIn(){
        if(signInInProgress)return;
        signInInProgress=true;
        // V5: karena pengguna menekan tombol login secara eksplisit,
        // gunakan Button Flow resmi GetSignInWithGoogleOption terlebih dahulu.
        // Ini juga merupakan alur yang direkomendasikan Android untuk kondisi
        // akun belum pernah dipakai, perlu re-authentication, atau sheet biasa
        // tidak menemukan credential.
        requestGoogleSignInExplicit();
    }

    void requestGoogleSignInExplicit(){
        if(credentialManager==null){
            signInInProgress=false;
            showLoginError("Credential Manager tidak tersedia di perangkat");
            return;
        }
        try{
            GetSignInWithGoogleOption option=new GetSignInWithGoogleOption.Builder(
                    getString(R.string.default_web_client_id))
                    .setNonce(generateSecureNonce())
                    .build();

            GetCredentialRequest request=new GetCredentialRequest.Builder()
                    .addCredentialOption(option)
                    .build();

            credentialManager.getCredentialAsync(
                    this,
                    request,
                    new CancellationSignal(),
                    ContextCompat.getMainExecutor(this),
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override public void onResult(GetCredentialResponse result){
                            signInInProgress=false;
                            handleGoogleCredential(result);
                        }

                        @Override public void onError(GetCredentialException e){
                            Log.e("AbsenGoogle", "Google Sign-In error: "+e.getClass().getName()+" / "+String.valueOf(e.getMessage()), e);
                            if(isUserCancel(e)){
                                // Beberapa perangkat/versi Google Play services dapat menutup
                                // Button Flow Credential Manager tanpa menampilkan picker.
                                // Gunakan compatibility fallback agar pengguna tetap mendapat
                                // pemilih akun Google yang nyata.
                                requestLegacyGoogleSignIn();
                            }else if(isNoCredential(e)){
                                // Coba bottom-sheet dengan semua akun sebagai fallback.
                                requestGoogleAccountSheet();
                            }else{
                                signInInProgress=false;
                                showLoginError(credentialErrorMessage(e));
                            }
                        }
                    });
        }catch(Exception e){
            Log.e("AbsenGoogle", "Unable to start Google Sign-In", e);
            signInInProgress=false;
            showLoginError("Tidak dapat memulai Login Google");
        }
    }

    void requestLegacyGoogleSignIn(){
        if(legacyGoogleClient==null){
            signInInProgress=false;
            showLoginError("Layanan Login Google tidak tersedia di perangkat ini");
            return;
        }
        try{
            legacyGoogleClient.signOut().addOnCompleteListener(task -> {
                try{
                    Intent intent=legacyGoogleClient.getSignInIntent();
                    startActivityForResult(intent,REQ_GOOGLE_LEGACY);
                }catch(Exception e){
                    signInInProgress=false;
                    Log.e("AbsenGoogle","Legacy Google Sign-In could not start",e);
                    showLoginError("Pemilih akun Google tidak dapat dibuka");
                }
            });
        }catch(Exception e){
            signInInProgress=false;
            Log.e("AbsenGoogle","Legacy Google Sign-In failed to start",e);
            showLoginError("Pemilih akun Google tidak dapat dibuka");
        }
    }

    void requestGoogleAccountSheet(){
        try{
            GetGoogleIdOption googleIdOption=new GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(getString(R.string.default_web_client_id))
                    .setNonce(generateSecureNonce())
                    .build();

            GetCredentialRequest request=new GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build();

            credentialManager.getCredentialAsync(
                    this,
                    request,
                    new CancellationSignal(),
                    ContextCompat.getMainExecutor(this),
                    new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                        @Override public void onResult(GetCredentialResponse result){
                            signInInProgress=false;
                            handleGoogleCredential(result);
                        }

                        @Override public void onError(GetCredentialException e){
                            Log.e("AbsenGoogle", "Google account sheet error: "+e.getClass().getName()+" / "+String.valueOf(e.getMessage()), e);
                            if(isUserCancel(e)){
                                requestLegacyGoogleSignIn();
                            }else{
                                signInInProgress=false;
                                if(isNoCredential(e)) showLoginError("Tidak ada akun Google yang bisa digunakan di perangkat ini");
                                else showLoginError(credentialErrorMessage(e));
                            }
                        }
                    });
        }catch(Exception e){
            Log.e("AbsenGoogle", "Unable to open Google account sheet", e);
            signInInProgress=false;
            showLoginError("Tidak dapat membuka pilihan akun Google");
        }
    }

    boolean isNoCredential(Exception e){
        return e instanceof NoCredentialException || e.getClass().getSimpleName().contains("NoCredential");
    }

    boolean isUserCancel(Exception e){
        String n=e.getClass().getSimpleName();
        return n.contains("Cancellation") || n.contains("UserCanceled") || n.contains("UserCancel");
    }

    String credentialErrorMessage(Exception e){
        String n=e==null?"":e.getClass().getSimpleName();
        String m=e==null?null:e.getMessage();
        if(n.contains("ProviderConfiguration")) return "Konfigurasi Google di perangkat bermasalah";
        if(n.contains("ProviderUnavailable")) return "Layanan Google untuk Login tidak tersedia";
        if(n.contains("GetCredentialUnsupported")) return "Perangkat tidak mendukung Login Google ini";
        if(m!=null && !m.trim().isEmpty()) return "Login Google gagal ("+n+")";
        return "Login Google gagal ("+n+")";
    }

    void showLoginError(String message){
        new AlertDialog.Builder(this)
                .setTitle("Login Google tidak berhasil")
                .setMessage(message+"\n\nPastikan akun Google ada di perangkat dan Google Play services sudah aktif/terbarui.")
                .setNegativeButton("Tutup",null)
                .setPositiveButton("Coba lagi",(d,w)->requestGoogleSignIn())
                .show();
    }

    void handleGoogleCredential(GetCredentialResponse result){
        Credential credential=result.getCredential();

        if(!(credential instanceof CustomCredential)){
            toast("Kredensial Google tidak valid");
            return;
        }

        CustomCredential custom=(CustomCredential)credential;
        if(!GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(custom.getType())){
            toast("Jenis akun Google tidak didukung");
            return;
        }

        try{
            GoogleIdTokenCredential google=GoogleIdTokenCredential.createFrom(custom.getData());
            String idToken=google.getIdToken();
            AuthCredential firebaseCredential=GoogleAuthProvider.getCredential(idToken,null);

            firebaseAuth.signInWithCredential(firebaseCredential)
                    .addOnSuccessListener(resultAuth->{
                        toast("Login Google berhasil ✓");
                        build();
                        startCloudSync();
                    })
                    .addOnFailureListener(e->{
                        Log.e("AbsenGoogle", "Firebase sign-in failed", e);
                        String msg=firebaseErrorMessage(e);
                        showLoginError(msg);
                    });
        }catch(Exception e){
            Log.e("AbsenGoogle", "Google ID token parsing/handling failed", e);
            showLoginError("Credential Google tidak valid ("+e.getClass().getSimpleName()+")");
        }
    }

    String firebaseErrorMessage(Exception e){
        if(e instanceof FirebaseAuthException){
            String code=((FirebaseAuthException)e).getErrorCode();
            if("ERROR_INVALID_CREDENTIAL".equals(code)) return "Credential Google ditolak Firebase (ERROR_INVALID_CREDENTIAL)";
            if("ERROR_IDP_RESPONSE_DENIED".equals(code)) return "Google menolak proses Login (ERROR_IDP_RESPONSE_DENIED)";
            if("ERROR_OPERATION_NOT_ALLOWED".equals(code)) return "Login Google belum diizinkan di Firebase (ERROR_OPERATION_NOT_ALLOWED)";
            if("ERROR_INVALID_API_KEY".equals(code)) return "Konfigurasi Firebase API key tidak valid (ERROR_INVALID_API_KEY)";
            if("ERROR_APP_NOT_AUTHORIZED".equals(code)) return "Aplikasi Android belum diotorisasi di Firebase/Google (ERROR_APP_NOT_AUTHORIZED)";
            return "Login Firebase gagal ("+code+")";
        }
        return "Login Firebase gagal ("+safeError(e)+")";
    }

    String safeError(Exception e){
        String m=e==null?null:e.getMessage();
        if(m==null||m.trim().isEmpty())return "silakan coba lagi";
        return m.length()>90?m.substring(0,90):m;
    }

    String generateSecureNonce(){
        try{
            byte[] bytes=new byte[32];
            new SecureRandom().nextBytes(bytes);
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            byte[] hash=digest.digest(bytes);
            StringBuilder out=new StringBuilder(hash.length*2);
            for(byte b:hash)out.append(String.format(Locale.US,"%02x",b));
            return out.toString();
        }catch(Exception e){
            return Long.toHexString(System.nanoTime())+Long.toHexString(new SecureRandom().nextLong());
        }
    }

    void startCloudSync(){
        if(cloudState!=null && cloudListener!=null) cloudState.removeEventListener(cloudListener);
        if(cloudConnection!=null && cloudConnectionListener!=null) cloudConnection.removeEventListener(cloudConnectionListener);

        FirebaseDatabase db=FirebaseDatabase.getInstance(FIREBASE_DB_URL);
        cloudState=db.getReference("cv_hikmah_tani").child("state");
        cloudConnection=db.getReference(".info/connected");
        cloudReady=true;
        initialCloudCheckDone=false;
        setCloudStatus("☁ Menghubungkan ke Firebase…");

        cloudConnectionListener=new ValueEventListener(){
            @Override public void onDataChange(DataSnapshot snapshot){
                final boolean connected=Boolean.TRUE.equals(snapshot.getValue(Boolean.class));
                runOnUiThread(()->handleConnectionState(connected));
            }
            @Override public void onCancelled(DatabaseError error){
                runOnUiThread(()->{
                    cloudConnected=false;
                    setCloudStatus("☁ Gagal koneksi: "+error.getCode()+" - "+error.getMessage());
                });
            }
        };
        cloudConnection.addValueEventListener(cloudConnectionListener);

        cloudListener=new ValueEventListener(){
            @Override public void onDataChange(DataSnapshot snapshot){
                // Do not execute application logic inside the Firebase Database runloop.
                // Only hand the snapshot to the Android main thread.
                final DataSnapshot safeSnapshot=snapshot;
                runOnUiThread(()->handleCloudSnapshot(safeSnapshot));
            }
            @Override public void onCancelled(DatabaseError error){
                runOnUiThread(()->{
                    setCloudStatus("☁ Gagal sinkron: "+error.getCode()+" - "+error.getMessage());
                    toast("Firebase gagal membaca: "+error.getMessage());
                });
            }
        };
        cloudState.addValueEventListener(cloudListener);
    }

    void handleConnectionState(boolean connected){
        cloudConnected=connected;
        if(!connected){
            setCloudStatus("☁ Offline • perubahan disimpan di perangkat");
            return;
        }
        if(pendingFullSync){
            setCloudStatus(restoringBackup ? "☁ Online • mengirim hasil restore…" : "☁ Online • mengirim perubahan…");
            uploadPendingFullState();
            return;
        }
        setCloudStatus("☁ Online • memeriksa data…");
        if(initialCloudCheckDone)return;
        initialCloudCheckDone=true;
        cloudState.addListenerForSingleValueEvent(new ValueEventListener(){
            @Override public void onDataChange(DataSnapshot snapshot){
                final DataSnapshot safeSnapshot=snapshot;
                runOnUiThread(()->{
                    if(pendingFullSync || fullCloudWriteInProgress)return;
                    Map<String,Object> remote=readSnapshotMap(safeSnapshot);
                    if(!safeSnapshot.exists() || remote.isEmpty()) syncAllLocalToCloud();
                    else applyRemoteMap(remote);
                });
            }
            @Override public void onCancelled(DatabaseError error){
                runOnUiThread(()->setCloudStatus("☁ Gagal membaca: "+error.getCode()+" - "+error.getMessage()));
            }
        });
    }

    void handleCloudSnapshot(DataSnapshot snapshot){
        if(pendingFullSync || fullCloudWriteInProgress || remoteApplying)return;
        Map<String,Object> remote=readSnapshotMap(snapshot);
        if(remote.isEmpty()){
            if(cloudConnected && initialCloudCheckDone) syncAllLocalToCloud();
        }else{
            applyRemoteMap(remote);
        }
    }

    Map<String,Object> readSnapshotMap(DataSnapshot snapshot){
        Map<String,Object> remote=new HashMap<>();
        if(snapshot==null || !snapshot.exists()) return remote;
        try{
            GenericTypeIndicator<Map<String,Object>> type=new GenericTypeIndicator<Map<String,Object>>(){};
            Map<String,Object> raw=snapshot.getValue(type);
            if(raw==null) return remote;
            for(Map.Entry<String,Object> en:raw.entrySet()){
                String cloudKey=en.getKey();
                if(cloudKey==null || cloudKey.startsWith("__meta_")) continue;
                String localKey=decodeCloudKey(cloudKey);
                if(localKey==null || localKey.startsWith("__")) continue;
                Object v=en.getValue();
                if(v instanceof Boolean || v instanceof String || v instanceof Number) remote.put(localKey,v);
            }
        }catch(Exception ex){
            Log.e("AbsenFirebase","Gagal membaca snapshot Firebase",ex);
        }
        return remote;
    }

    boolean needsCloudKeyEncoding(String key){
        if(key==null || key.length()==0) return true;
        return key.indexOf('.')>=0 || key.indexOf('#')>=0 || key.indexOf('$')>=0
                || key.indexOf('[')>=0 || key.indexOf(']')>=0 || key.indexOf('/')>=0;
    }

    String encodeCloudKey(String key){
        if(key==null) return "";
        if(!needsCloudKeyEncoding(key)) return key;
        try{
            return "__ck__"+Base64.encodeToString(key.getBytes("UTF-8"),Base64.NO_WRAP|Base64.URL_SAFE);
        }catch(Exception e){
            return "__ck__"+Integer.toHexString(key.hashCode());
        }
    }

    String decodeCloudKey(String key){
        if(key==null) return null;
        if(!key.startsWith("__ck__")) return key;
        try{
            byte[] bytes=Base64.decode(key.substring(6),Base64.NO_WRAP|Base64.URL_SAFE);
            String decoded=new String(bytes,"UTF-8");
            return needsCloudKeyEncoding(decoded) ? decoded : key;
        }catch(Exception e){
            Log.e("AbsenFirebase","Key Firebase tidak dapat didekode: "+key,e);
            return null;
        }
    }

    Map<String,Object> cloudMapFromLocal(){
        HashMap<String,Object> values=new HashMap<>();
        for(Map.Entry<String,?> entry:prefs.getAll().entrySet()){
            if(KEY_PENDING_FULL_SYNC.equals(entry.getKey())) continue;
            Object v=entry.getValue();
            if(v instanceof Boolean || v instanceof String || v instanceof Number){
                values.put(encodeCloudKey(entry.getKey()),v);
            }
        }
        return values;
    }

    boolean cloudMapMatchesLocal(Map<String,Object> remote){
        HashMap<String,Object> local=new HashMap<>();
        for(Map.Entry<String,?> entry:prefs.getAll().entrySet()){
            if(KEY_PENDING_FULL_SYNC.equals(entry.getKey())) continue;
            Object v=entry.getValue();
            if(v instanceof Boolean || v instanceof String || v instanceof Number) local.put(entry.getKey(),v);
        }
        if(remote.size()!=local.size()) return false;
        for(Map.Entry<String,Object> en:remote.entrySet()){
            Object mine=local.get(en.getKey());
            if(mine==null || !String.valueOf(mine).equals(String.valueOf(en.getValue()))) return false;
        }
        return true;
    }

    void applyRemoteMap(Map<String,Object> remote){
        if(pendingFullSync || fullCloudWriteInProgress || remoteApplying)return;
        if(cloudMapMatchesLocal(remote)){
            setCloudStatus("☁ Online • tersinkron ✓");
            return;
        }
        remoteApplying=true;
        int y=sv==null?0:sv.getScrollY();
        int day=currentDay;
        try{
            SharedPreferences.Editor e=prefs.edit();
            clearAttendance(e);
            e.remove(KEY_MALE).remove(KEY_FEMALE).remove(KEY_APP);
            for(Map.Entry<String,Object> en:remote.entrySet()){
                Object v=en.getValue();
                if(v instanceof Boolean) e.putBoolean(en.getKey(),(Boolean)v);
                else if(v instanceof String) e.putString(en.getKey(),(String)v);
                else if(v!=null) e.putString(en.getKey(),String.valueOf(v));
            }
            e.apply();
        }finally{
            remoteApplying=false;
        }
        initPeriodSettings();
        currentDay=Math.max(sessionStartDay,Math.min(sessionEndDay,day));
        setCloudStatus("☁ Online • data HP lain diterima ✓");
        buildPreservePosition(y,currentDay);
    }

    void setCloudStatus(String text){
        if(cloudStatus!=null) cloudStatus.setText(text);
    }

    Map<String,Object> localCloudMap(){
        HashMap<String,Object> values=new HashMap<>();
        for(Map.Entry<String,?> entry:prefs.getAll().entrySet()){
            if(KEY_PENDING_FULL_SYNC.equals(entry.getKey())) continue;
            Object v=entry.getValue();
            if(v instanceof Boolean || v instanceof String || v instanceof Number) values.put(entry.getKey(),v);
        }
        return values;
    }

    void syncAllLocalToCloud(){
        if(!cloudReady || cloudState==null || remoteApplying || pendingFullSync || fullCloudWriteInProgress)return;
        fullCloudWriteInProgress=true;
        cloudState.setValue(cloudMapFromLocal()).addOnCompleteListener(task->{
            fullCloudWriteInProgress=false;
            if(task.isSuccessful()) setCloudStatus(cloudConnected ? "☁ Online • tersimpan di cloud ✓" : "☁ Offline • tersimpan di perangkat");
            else{
                String msg=task.getException()==null?"gagal menulis data":safeError(task.getException());
                setCloudStatus("☁ Gagal sinkron: "+msg);
                toast("Firebase gagal menyimpan: "+msg);
            }
        });
    }

    void cloudPut(String key,Object value){
        if(!cloudReady || cloudState==null || remoteApplying)return;
        if(pendingFullSync || fullCloudWriteInProgress){ localChangedDuringFullSync=true; return; }
        HashMap<String,Object> updates=new HashMap<>();
        updates.put(encodeCloudKey(key),value);
        cloudState.updateChildren(updates).addOnCompleteListener(task->{
            if(task.isSuccessful()){
                setCloudStatus(cloudConnected ? "☁ Online • tersinkron ✓" : "☁ Offline • menunggu koneksi ✓");
            }else{
                String msg=task.getException()==null?"gagal menulis data":safeError(task.getException());
                setCloudStatus("☁ Gagal sinkron: "+msg);
                toast("Firebase gagal menyimpan: "+msg);
            }
        });
    }

    void cloudRemove(String key){
        if(!cloudReady || cloudState==null || remoteApplying)return;
        if(pendingFullSync || fullCloudWriteInProgress){ localChangedDuringFullSync=true; return; }
        HashMap<String,Object> updates=new HashMap<>(); updates.put(encodeCloudKey(key),null);
        cloudState.updateChildren(updates).addOnCompleteListener(task->{
            if(task.isSuccessful()) setCloudStatus(cloudConnected ? "☁ Online • tersinkron ✓" : "☁ Offline • menunggu koneksi ✓");
            else setCloudStatus("☁ Gagal sinkron: "+safeError(task.getException()));
        });
    }

    void uploadPendingFullState(){
        if(!pendingFullSync || cloudState==null || !cloudConnected || fullCloudWriteInProgress)return;
        fullCloudWriteInProgress=true;
        Map<String,Object> values=cloudMapFromLocal();
        cloudState.setValue(values).addOnCompleteListener(task->{
            fullCloudWriteInProgress=false;
            if(task.isSuccessful()){
                fullSyncRetryCount=0;
                if(localChangedDuringFullSync){
                    localChangedDuringFullSync=false;
                    setCloudStatus("☁ Online • perubahan tambahan dikirim…");
                    new Handler(Looper.getMainLooper()).postDelayed(()->uploadPendingFullState(),150L);
                }else{
                    pendingFullSync=false;
                    prefs.edit().remove(KEY_PENDING_FULL_SYNC).apply();
                    restoringBackup=false;
                    setCloudStatus("☁ Online • data tersimpan di cloud ✓");
                }
            }else{
                fullSyncRetryCount++;
                setCloudStatus("☁ Gagal sinkron: "+safeError(task.getException()));
                if(fullSyncRetryCount<=3){
                    new Handler(Looper.getMainLooper()).postDelayed(()->{
                        if(pendingFullSync && cloudConnected) uploadPendingFullState();
                    },3000L);
                }else{
                    toast("Firebase belum menerima data. Data lokal tetap aman; akan dicoba lagi saat koneksi berikutnya.");
                }
            }
        });
    }

    String appTitle(){ return prefs.getString(KEY_APP,"ABSEN CV HIKMAH TANI"); }

    private void toast(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    String[] getNames(String key, String[] defaults){
        String raw=prefs.getString(key,null);
        if(raw==null || raw.trim().isEmpty()) return defaults.clone();
        String[] a=raw.split("\\n",-1);
        ArrayList<String> out=new ArrayList<>();
        for(String s:a){ s=s.trim(); if(!s.isEmpty()) out.add(s); }
        return out.isEmpty()?defaults.clone():out.toArray(new String[0]);
    }
    String[] maleNames(){ return getNames(KEY_MALE,DEFAULT_MALE); }
    String[] femaleNames(){ return getNames(KEY_FEMALE,DEFAULT_FEMALE); }

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    GradientDrawable bg(int color,float radius){
        GradientDrawable g=new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        return g;
    }

    GradientDrawable gradientBg(int start,int end,float radius){
        GradientDrawable g=new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{start,end});
        g.setCornerRadius(dp(radius));
        return g;
    }

    Button btn(String text) {
        Button b=new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextSize(13);
        b.setTextColor(Color.rgb(43,47,54));
        b.setMinHeight(0); b.setMinWidth(0);
        b.setPadding(dp(5),0,dp(5),0); b.setGravity(Gravity.CENTER);
        b.setBackground(bg(Color.WHITE,10)); b.setElevation(dp(1));
        // Tombol absensi tidak boleh mengambil fokus keyboard/navigasi yang dapat
        // membuat ScrollView otomatis menggeser posisi saat ditekan.
        b.setFocusable(false);
        b.setFocusableInTouchMode(false);
        return b;
    }

    void styleAction(Button b,int color,boolean white){
        b.setTextColor(white?Color.WHITE:Color.rgb(43,47,54));
        b.setBackground(bg(color,12)); b.setElevation(dp(2));
    }


    void buildLogin(){
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22),dp(24),dp(22),dp(24));
        root.setBackground(gradientBg(Color.rgb(10,24,38),Color.rgb(94,25,47),0));

        Space top=new Space(this);
        root.addView(top,new LinearLayout.LayoutParams(1,0,1));

        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(22),dp(24),dp(22),dp(24));
        card.setBackground(bg(Color.rgb(250,247,242),24));
        card.setElevation(dp(8));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(430));
        root.addView(card,cp);

        ImageView icon=new ImageView(this);
        icon.setImageResource(com.hikmahtani.absen.R.drawable.app_icon);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        card.addView(icon,new LinearLayout.LayoutParams(dp(105),dp(105)));

        TextView brand=new TextView(this);
        brand.setText("ABSEN CV HIKMAH TANI");
        brand.setTextSize(22); brand.setTypeface(null,Typeface.BOLD);
        brand.setTextColor(Color.rgb(20,38,54)); brand.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(46));
        bp.setMargins(0,dp(8),0,0); card.addView(brand,bp);

        TextView welcome=new TextView(this);
        welcome.setText("Selamat datang\nSilakan masuk untuk melanjutkan");
        welcome.setTextSize(14); welcome.setTextColor(Color.rgb(92,90,91));
        welcome.setGravity(Gravity.CENTER); welcome.setLineSpacing(2,1.0f);
        LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-1,dp(58));
        wp.setMargins(0,dp(2),0,dp(18)); card.addView(welcome,wp);

        Button login=btn("Masuk dengan Google");
        login.setTextSize(15); login.setTypeface(null,Typeface.BOLD);
        login.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_myplaces,0,0,0);
        login.setCompoundDrawablePadding(dp(8));
        styleAction(login,Color.rgb(156,35,53),true);
        card.addView(login,new LinearLayout.LayoutParams(-1,dp(58)));

        Button diag=btn("Periksa konfigurasi Login Google");
        diag.setTextSize(11);
        diag.setTypeface(null,Typeface.BOLD);
        styleAction(diag,Color.rgb(34,71,99),false);
        LinearLayout.LayoutParams dpms=new LinearLayout.LayoutParams(-1,dp(42));
        dpms.setMargins(0,dp(8),0,0);
        card.addView(diag,dpms);

        TextView secure=new TextView(this);
        secure.setText("🔒 Login aman dengan Google & Firebase");
        secure.setTextSize(12); secure.setTextColor(Color.rgb(92,90,91));
        secure.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(40));
        sp.setMargins(0,dp(12),0,0); card.addView(secure,sp);

        TextView footer=new TextView(this);
        footer.setText("Akses absensi hanya setelah akun berhasil masuk.");
        footer.setTextSize(11); footer.setTextColor(Color.argb(210,255,255,255));
        footer.setGravity(Gravity.CENTER);
        root.addView(footer,new LinearLayout.LayoutParams(-1,dp(54)));

        Space bottom=new Space(this);
        root.addView(bottom,new LinearLayout.LayoutParams(1,0,1));
        setContentView(root);

        login.setOnClickListener(v->requestGoogleSignIn());
        diag.setOnClickListener(v->showGoogleDiagnostics());
    }

    void showGoogleDiagnostics(){
        String sha1=getSigningSha1();
        String sha256=getSigningSha256();
        String webClient="(tidak tersedia)";
        try{ webClient=getString(R.string.default_web_client_id); }catch(Exception ignored){}
        String msg="Package aplikasi:\n"+getPackageName()+
                "\n\nSHA-1 APK saat ini:\n"+sha1+
                "\n\nSHA-256 APK saat ini:\n"+sha256+
                "\n\nWeb Client ID:\n"+webClient+
                "\n\nUntuk Google Sign-In, SHA-1 APK ini harus terdaftar pada Firebase Android App yang sama.\n\nJika SHA-1 berbeda dengan yang ada di Firebase, tambahkan SHA-1 ini ke Firebase lalu download google-services.json terbaru.";
        new AlertDialog.Builder(this).setTitle("Diagnostik Login Google V7").setMessage(msg)
                .setPositiveButton("Tutup",null).show();
    }

    String getSigningSha1(){ return getSigningFingerprint("SHA-1"); }
    String getSigningSha256(){ return getSigningFingerprint("SHA-256"); }
    String getSigningFingerprint(String algorithm){
        try{
            PackageManager pm=getPackageManager();
            PackageInfo pi;
            if(Build.VERSION.SDK_INT>=28) pi=pm.getPackageInfo(getPackageName(),PackageManager.GET_SIGNING_CERTIFICATES);
            else pi=pm.getPackageInfo(getPackageName(),PackageManager.GET_SIGNATURES);
            byte[] cert;
            if(Build.VERSION.SDK_INT>=28){
                Signature[] sigs=pi.signingInfo.hasMultipleSigners()?pi.signingInfo.getApkContentsSigners():pi.signingInfo.getSigningCertificateHistory();
                cert=sigs[0].toByteArray();
            }else cert=pi.signatures[0].toByteArray();
            MessageDigest md=MessageDigest.getInstance(algorithm);
            byte[] digest=md.digest(cert);
            StringBuilder out=new StringBuilder();
            for(int i=0;i<digest.length;i++){if(i>0)out.append(":");out.append(String.format(Locale.US,"%02X",digest[i]));}
            return out.toString();
        }catch(Exception e){ return "Tidak dapat membaca sertifikat ("+e.getClass().getSimpleName()+")"; }
    }


    int getPeriodIntCompat(String key,int def){
        try{
            Map<String,?> all=prefs.getAll();
            Object v=all.get(key);
            if(v instanceof Number) return ((Number)v).intValue();
            if(v instanceof String){
                String s=((String)v).trim();
                if(!s.isEmpty()) return Integer.parseInt(s);
            }
        }catch(Exception ignored){}
        return def;
    }

    void initPeriodSettings(){
        Calendar now=Calendar.getInstance();
        periodYear=getPeriodIntCompat(KEY_PERIOD_YEAR,now.get(Calendar.YEAR));
        periodMonth=getPeriodIntCompat(KEY_PERIOD_MONTH,now.get(Calendar.MONTH)+1);
        periodSession=getPeriodIntCompat(KEY_PERIOD_SESSION,1);

        if(periodYear<2000 || periodYear>2100) periodYear=now.get(Calendar.YEAR);
        if(periodMonth<1 || periodMonth>12) periodMonth=now.get(Calendar.MONTH)+1;
        if(periodSession!=1 && periodSession!=2) periodSession=1;

        // Migrasi nilai lama yang mungkin tersimpan sebagai String menjadi Integer.
        prefs.edit()
                .putInt(KEY_PERIOD_YEAR,periodYear)
                .putInt(KEY_PERIOD_MONTH,periodMonth)
                .putInt(KEY_PERIOD_SESSION,periodSession)
                .apply();

        updateSessionRange();
    }

    void updateSessionRange(){
        sessionStartDay=periodSession==1?1:16;
        Calendar cal=Calendar.getInstance();
        cal.set(Calendar.YEAR,periodYear); cal.set(Calendar.MONTH,periodMonth-1); cal.set(Calendar.DAY_OF_MONTH,1);
        int last=cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        sessionEndDay=periodSession==1?Math.min(15,last):last;
        if(currentDay<sessionStartDay || currentDay>sessionEndDay) currentDay=sessionStartDay;
    }

    int activeDayCount(){ return sessionEndDay-sessionStartDay+1; }

    String monthName(int month){ return new DateFormatSymbols(new Locale("id","ID")).getMonths()[month-1]; }

    String dateLabel(int day){ return "Tanggal "+day+" "+monthName(periodMonth)+" "+periodYear; }

    String shortDateLabel(int day){ return String.format(Locale.US,"%02d/%02d",day,periodMonth); }

    String statusKey(String n,int d){ return KEY_STATUS_PREFIX+n+"_"+d+"_status"; }

    String status(String n,int d){ return prefs.getString(statusKey(n,d),STATUS_NONE); }

    String statusLabel(String st){
        if(STATUS_ABSENT.equals(st)) return "Tidak Hadir";
        if(STATUS_NO_MORNING.equals(st)) return "Tidak Masuk Pagi";
        if(STATUS_NO_AFTERNOON.equals(st)) return "Tidak Masuk Sore";
        return "Status";
    }

    int statusColor(String st){
        if(STATUS_ABSENT.equals(st)) return Color.rgb(190,48,55);
        if(STATUS_NO_MORNING.equals(st) || STATUS_NO_AFTERNOON.equals(st)) return Color.rgb(204,145,30);
        return Color.rgb(95,98,105);
    }

    void savePeriodSetting(){
        prefs.edit().putInt(KEY_PERIOD_YEAR,periodYear).putInt(KEY_PERIOD_MONTH,periodMonth)
                .putInt(KEY_PERIOD_SESSION,periodSession).apply();
        cloudPut(KEY_PERIOD_YEAR,periodYear); cloudPut(KEY_PERIOD_MONTH,periodMonth); cloudPut(KEY_PERIOD_SESSION,periodSession);
    }

    void showPeriodSettings(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18),dp(4),dp(18),dp(4));
        Spinner month=new Spinner(this);
        String[] months=new String[12]; for(int i=0;i<12;i++)months[i]=monthName(i+1);
        month.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,months));
        month.setSelection(periodMonth-1,false);
        EditText year=new EditText(this); year.setHint("Tahun, contoh 2026");
        year.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); year.setText(String.valueOf(periodYear));
        Spinner session=new Spinner(this);
        session.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Sesi 1 • tanggal 1–15","Sesi 2 • tanggal 16–hari terakhir bulan"}));
        session.setSelection(periodSession-1,false);
        TextView info=label("Sesi 1 = tanggal 1–15. Sesi 2 = tanggal 16–hari terakhir bulan. Pengaturan ini hanya menentukan periode yang ditampilkan; data absensi lama tetap tersimpan.",12);
        info.setPadding(dp(4),dp(8),dp(4),dp(10));
        box.addView(label("Bulan",13)); box.addView(month,new LinearLayout.LayoutParams(-1,dp(48)));
        box.addView(label("Tahun",13)); box.addView(year,new LinearLayout.LayoutParams(-1,dp(48)));
        box.addView(label("Sesi",13)); box.addView(session,new LinearLayout.LayoutParams(-1,dp(48)));
        box.addView(info);
        new AlertDialog.Builder(this).setTitle("📅 Pengaturan Periode Absensi").setView(box).setNegativeButton("Batal",null)
            .setPositiveButton("Simpan",(d,w)->{
                int y;
                try{y=Integer.parseInt(year.getText().toString().trim());}catch(Exception e){toast("Tahun tidak valid");return;}
                if(y<2000||y>2100){toast("Tahun harus 2000–2100");return;}
                periodYear=y; periodMonth=month.getSelectedItemPosition()+1; periodSession=session.getSelectedItemPosition()+1;
                updateSessionRange(); currentDay=sessionStartDay; savePeriodSetting();
                buildPreservePosition(0,currentDay); toast("Periode tersimpan ✓");
            }).show();
    }

    void build() {
        buildPreservePosition(sv==null?0:sv.getScrollY(), currentDay);
    }

    void buildPreservePosition(final int savedScrollY, final int savedDay) {
        updateSessionRange();
        final int dayToKeep=Math.max(sessionStartDay,Math.min(sessionEndDay,savedDay));
        currentDay=dayToKeep;
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10),dp(8),dp(10),dp(8));
        root.setBackgroundColor(Color.rgb(247,244,239));

        TextView title=new TextView(this);
        title.setText(appTitle()); title.setTextSize(21);
        title.setTextColor(Color.WHITE); title.setTypeface(null,Typeface.BOLD);
        title.setGravity(Gravity.CENTER); title.setPadding(dp(14),0,dp(14),0);
        title.setBackground(gradientBg(Color.rgb(12,35,55),Color.rgb(122,28,54),16)); title.setElevation(dp(3));
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(62)));

        TextView sub=new TextView(this);
        sub.setText((periodSession==1?"SESI 1 • TANGGAL 1–15":"SESI 2 • TANGGAL 16–"+sessionEndDay)+"  •  Pagi + Sore = 1 hari");
        sub.setTextSize(12); sub.setTextColor(Color.rgb(96,99,103));
        sub.setGravity(Gravity.CENTER); sub.setPadding(0,dp(5),0,dp(2));
        root.addView(sub,new LinearLayout.LayoutParams(-1,dp(30)));

        FirebaseUser activeUser=firebaseAuth==null?null:firebaseAuth.getCurrentUser();
        TextView accountLine=new TextView(this);
        accountLine.setText(activeUser!=null && activeUser.getEmail()!=null ? "👤 "+activeUser.getEmail() : "👤 Akun Google");
        accountLine.setTextSize(11); accountLine.setTextColor(Color.rgb(107,80,87));
        accountLine.setGravity(Gravity.CENTER);
        root.addView(accountLine,new LinearLayout.LayoutParams(-1,dp(24)));

        cloudStatus=new TextView(this);
        cloudStatus.setText(cloudConnected ? "☁ Online • tersinkron" : "☁ Menghubungkan ke Firebase…");
        cloudStatus.setTextSize(11); cloudStatus.setTypeface(null,Typeface.BOLD);
        cloudStatus.setTextColor(Color.rgb(19,116,105)); cloudStatus.setGravity(Gravity.CENTER);
        cloudStatus.setPadding(dp(4),0,dp(4),0);
        root.addView(cloudStatus,new LinearLayout.LayoutParams(-1,dp(24)));

        LinearLayout top=new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL); top.setPadding(dp(4),0,dp(4),dp(4));
        daySpinner=new Spinner(this);
        String[] days=new String[activeDayCount()];
        for(int i=0;i<activeDayCount();i++){int d=sessionStartDay+i;days[i]="Hari "+d+" • "+shortDateLabel(d);}
        daySpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,days));
        top.addView(daySpinner,new LinearLayout.LayoutParams(-1,dp(52)));
        daySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){currentDay=sessionStartDay+pos;render();}
        });
        root.addView(top);

        LinearLayout actions2=new LinearLayout(this); actions2.setPadding(dp(2),0,dp(2),dp(3));
        Button csv=btn("⬇  Rekap CSV"), pdf=btn("▣  PDF"), backup=btn("▣  Backup"), restore=btn("↥  Pulihkan");
        styleAction(csv,Color.rgb(218,239,231),false); styleAction(pdf,Color.rgb(220,231,244),false);
        styleAction(backup,Color.rgb(245,231,201),false); styleAction(restore,Color.rgb(235,220,238),false);
        actions2.addView(csv,new LinearLayout.LayoutParams(0,dp(52),1));
        actions2.addView(pdf,new LinearLayout.LayoutParams(0,dp(52),1));
        actions2.addView(backup,new LinearLayout.LayoutParams(0,dp(52),1));
        actions2.addView(restore,new LinearLayout.LayoutParams(0,dp(52),1)); root.addView(actions2);

        LinearLayout actions3=new LinearLayout(this); actions3.setPadding(dp(2),0,dp(2),dp(5));
        Button reset=btn("↻  Reset absensi"), settings=btn("⚙  Pengaturan nama");
        styleAction(reset,Color.rgb(244,214,220),false); styleAction(settings,Color.rgb(218,228,239),false);
        actions3.addView(reset,new LinearLayout.LayoutParams(0,dp(52),1));
        actions3.addView(settings,new LinearLayout.LayoutParams(0,dp(52),1));
        Button period=btn("📅  Periode / Sesi"); styleAction(period,Color.rgb(232,224,204),false);
        actions3.addView(period,new LinearLayout.LayoutParams(0,dp(52),1)); root.addView(actions3);

        sv=new ScrollView(this); sv.setFillViewport(true); sv.setFocusable(false); sv.setFocusableInTouchMode(false);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(2),0,dp(2),dp(8)); sv.addView(list);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);

        csv.setOnClickListener(v->exportCsv()); pdf.setOnClickListener(v->makePdf());
        backup.setOnClickListener(v->backup()); restore.setOnClickListener(v->pickBackup());
        reset.setOnClickListener(v->confirmReset()); settings.setOnClickListener(v->showSettings()); period.setOnClickListener(v->showPeriodSettings());
        daySpinner.setSelection(dayToKeep-sessionStartDay,false);
        render();
        if(sv!=null) sv.post(()->sv.scrollTo(0,savedScrollY));
    }


    boolean here(String n,int d,String s){return prefs.getBoolean(key(n,d,s),false);}
    String key(String n,int d,String s){return n+"_"+d+"_"+s;}
    boolean validAttendanceKey(String k){return k!=null && (k.matches(".+_(?:[1-9]|[12][0-9]|3[01])_(?:pagi|sore)") || k.matches("status_.+_(?:[1-9]|[12][0-9]|3[01])_status"));}

    void setHere(View clicked,String n,int d,String s,boolean val){
        String k=key(n,d,s), sk=statusKey(n,d);
        String oldStatus=status(n,d);
        SharedPreferences.Editor e=prefs.edit(); e.putBoolean(k,val);
        if(val && (STATUS_ABSENT.equals(oldStatus) ||
                ("pagi".equals(s)&&STATUS_NO_MORNING.equals(oldStatus)) ||
                ("sore".equals(s)&&STATUS_NO_AFTERNOON.equals(oldStatus)))) e.remove(sk);
        e.apply(); cloudPut(k,val);
        if(val && !oldStatus.equals(status(n,d))) cloudRemove(sk);

        if(clicked instanceof Button){
            Button b=(Button)clicked;
            int accent="pagi".equals(s)?Color.rgb(18,125,110):Color.rgb(86,73,151);
            styleSession(b,val,accent);
            ViewParent parent=b.getParent();
            if(parent instanceof LinearLayout){
                LinearLayout row=(LinearLayout)parent;
                if(row.getChildCount()>4 && row.getChildAt(4) instanceof TextView){
                    TextView totalView=(TextView)row.getChildAt(4);
                    totalView.setText(String.valueOf(total(n)).replace(".0",""));
                }
            }
            b.clearFocus();
            // Restaure posisi yang sedang dilihat setelah Android menyelesaikan
            // event klik. Tidak ada render ulang daftar.

        }
        Toast.makeText(this,"Tersimpan otomatis ✓",Toast.LENGTH_SHORT).show();
    }

    double total(String n){
        double x=0;
        for(int d=sessionStartDay;d<=sessionEndDay;d++){if(here(n,d,"pagi"))x+=.5;if(here(n,d,"sore"))x+=.5;}
        return x;
    }

    TextView label(String s,int size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(47,52,59));
        t.setPadding(dp(8),dp(6),dp(4),dp(6)); return t;
    }


    void render(){
        if(list==null)return;
        final int savedScrollY = sv==null ? 0 : sv.getScrollY();
        list.removeAllViews();
        TextView info=label("HARI "+currentDay+"  •  "+dateLabel(currentDay)+"   •   Pagi + sore = 1 hari   •   1 sesi = 0,5",14);
        info.setGravity(Gravity.CENTER); info.setTypeface(null,Typeface.BOLD);
        info.setTextColor(Color.rgb(18,48,62)); info.setBackground(gradientBg(Color.rgb(226,242,238),Color.rgb(240,230,214),12));
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(46)); ip.setMargins(0,0,0,dp(2));
        list.addView(info,ip);
        section("Laki-laki",maleNames(),Color.rgb(19,116,105));
        section("Perempuan",femaleNames(),Color.rgb(132,61,103));
        // Render ulang daftar absensi tanpa mengubah posisi scroll.
        // Sebelumnya setiap klik Pagi/Sore memanggil render(), sehingga ScrollView
        // kembali ke bagian paling atas dan pengguna kehilangan posisi nama yang sedang dikerjakan.
        if(sv!=null){
            sv.post(() -> sv.scrollTo(0,savedScrollY));
        }
    }


    void section(String gender,String[] names,int accent){
        TextView h=label(gender+"  •  "+names.length+" orang",17);
        h.setTypeface(null,Typeface.BOLD); h.setTextColor(Color.WHITE);
        h.setGravity(Gravity.CENTER_VERTICAL); h.setPadding(dp(12),0,dp(12),0);
        h.setBackground(bg(accent,10)); h.setElevation(dp(2));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(44));
        hp.setMargins(0,dp(7),0,dp(4)); list.addView(h,hp);

        for(int i=0;i<names.length;i++){
            String n=names[i];
            LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(5),dp(3),dp(5),dp(3));
            r.setBackground(bg(i%2==0?Color.WHITE:Color.rgb(244,241,242),10));

            TextView name=label((i+1)+". "+n,12);
            // Nama tidak dipotong dengan ellipsis. Jika ruang sempit, nama boleh
            // turun ke baris berikutnya agar seluruh nama tetap terlihat.
            name.setSingleLine(false);
            name.setMaxLines(2);
            name.setEllipsize(null);
            name.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
            r.addView(name,new LinearLayout.LayoutParams(0,dp(70),1));

            Button p=btn("Pagi"),so=btn("Sore"),st=btn(statusLabel(status(n,currentDay)));
            styleSession(p,here(n,currentDay,"pagi"),Color.rgb(18,125,110));
            styleSession(so,here(n,currentDay,"sore"),Color.rgb(86,73,151));
            styleStatus(st,status(n,currentDay));

            TextView t=label(String.valueOf(total(n)).replace(".0",""),18);
            t.setGravity(Gravity.CENTER); t.setTypeface(null,Typeface.BOLD);
            t.setTextColor(accent); t.setSingleLine(true);

            r.addView(p,new LinearLayout.LayoutParams(dp(76),dp(58)));
            r.addView(so,new LinearLayout.LayoutParams(dp(76),dp(58)));
            r.addView(st,new LinearLayout.LayoutParams(dp(88),dp(58)));
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(dp(52),dp(58));
            tp.setMargins(dp(2),0,0,0); r.addView(t,tp);

            p.setOnClickListener(v->setHere(v,n,currentDay,"pagi",!here(n,currentDay,"pagi")));
            so.setOnClickListener(v->setHere(v,n,currentDay,"sore",!here(n,currentDay,"sore")));
            st.setOnClickListener(v->showStatusDialog(n,currentDay,st));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(70));
            rp.setMargins(0,dp(2),0,dp(2)); list.addView(r,rp);
        }
    }


    void styleStatus(Button b,String st){
        b.setTypeface(null,Typeface.BOLD); b.setTextSize(11); b.setFocusable(false); b.setFocusableInTouchMode(false);
        if(STATUS_NONE.equals(st)){b.setTextColor(Color.rgb(95,98,105));b.setBackground(bg(Color.rgb(233,236,239),10));}
        else{b.setTextColor(Color.WHITE);b.setBackground(bg(statusColor(st),10));}
    }

    void showStatusDialog(String n,int d,Button target){
        // Simpan posisi SEBELUM dialog dibuka. Pada sebagian perangkat Android,
        // saat AlertDialog ditutup fokus dikembalikan ke tombol yang diklik dan
        // ScrollView otomatis menggulir ke tombol tersebut. Karena itu posisi
        // harus dipulihkan setelah dialog benar-benar ditutup, bukan hanya saat
        // status disimpan.
        final int savedScrollY = sv==null ? 0 : sv.getScrollY();
        String[] labels={"Hapus status","Tidak Hadir","Tidak Masuk Pagi","Tidak Masuk Sore"};

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Status • "+n+"\n"+dateLabel(d))
                .setItems(labels,(dlg,which)->{
                    String st=which==0?STATUS_NONE:(which==1?STATUS_ABSENT:(which==2?STATUS_NO_MORNING:STATUS_NO_AFTERNOON));
                    setStatus(n,d,st,target);
                }).create();

        dialog.setOnDismissListener(dlg -> restoreStatusScroll(savedScrollY));
        dialog.setOnShowListener(dlg -> {
            if(sv!=null) sv.postDelayed(() -> sv.scrollTo(0,savedScrollY), 20);
        });
        dialog.show();
    }

    void restoreStatusScroll(final int savedScrollY){
        if(sv==null)return;
        sv.clearFocus();
        sv.post(() -> sv.scrollTo(0,savedScrollY));
        sv.postDelayed(() -> sv.scrollTo(0,savedScrollY),50);
        sv.postDelayed(() -> sv.scrollTo(0,savedScrollY),150);
        sv.postDelayed(() -> sv.scrollTo(0,savedScrollY),300);
    }

    void setStatus(String n,int d,String st,Button target){
        // Penting: jangan rebuild ScrollView saat status dipilih. Rebuild menyebabkan
        // posisi daftar dapat kembali ke atas pada sebagian perangkat Android.
        SharedPreferences.Editor e=prefs.edit(); String sk=statusKey(n,d);
        if(STATUS_NONE.equals(st)){
            e.remove(sk);
            cloudRemove(sk);
        }else{
            if(STATUS_ABSENT.equals(st)){
                e.putBoolean(key(n,d,"pagi"),false).putBoolean(key(n,d,"sore"),false);
                cloudPut(key(n,d,"pagi"),false);
                cloudPut(key(n,d,"sore"),false);
            }else if(STATUS_NO_MORNING.equals(st)){
                e.putBoolean(key(n,d,"pagi"),false);
                cloudPut(key(n,d,"pagi"),false);
            }else if(STATUS_NO_AFTERNOON.equals(st)){
                e.putBoolean(key(n,d,"sore"),false);
                cloudPut(key(n,d,"sore"),false);
            }
            e.putString(sk,st);
            cloudPut(sk,st);
        }
        e.apply();

        // Perbarui hanya baris yang sedang dipilih; ScrollView tetap di posisi semula.
        if(target!=null){
            target.setText(statusLabel(st));
            styleStatus(target,st);
            ViewParent parent=target.getParent();
            if(parent instanceof LinearLayout){
                LinearLayout row=(LinearLayout)parent;
                if(row.getChildCount()>4 && row.getChildAt(4) instanceof TextView){
                    TextView totalView=(TextView)row.getChildAt(4);
                    totalView.setText(String.valueOf(total(n)).replace(".0",""));
                }
            }
            target.clearFocus();
        }
        toast(STATUS_NONE.equals(st)?"Status dihapus ✓":"Status "+statusLabel(st)+" tersimpan ✓");
    }

    void styleSession(Button b,boolean selected,int accent){
        b.setTypeface(null,Typeface.BOLD); b.setElevation(dp(1));
        b.setFocusable(false); b.setFocusableInTouchMode(false);
        if(selected){
            b.setTextColor(Color.WHITE); b.setBackground(bg(accent,10));
        }else{
            b.setTextColor(accent); b.setBackground(bg(Color.rgb(233,236,239),10));
        }
    }

    void markAll(String sess){
        SharedPreferences.Editor e=prefs.edit();
        for(String n:maleNames())e.putBoolean(key(n,currentDay,sess),true);
        for(String n:femaleNames())e.putBoolean(key(n,currentDay,sess),true);
        e.apply();
        for(String n:maleNames()) cloudPut(key(n,currentDay,sess),true);
        for(String n:femaleNames()) cloudPut(key(n,currentDay,sess),true);
        render();Toast.makeText(this,"Semua "+sess+" tersimpan ✓",Toast.LENGTH_SHORT).show();
    }

    double dayVal(String n,int d){
        boolean a=here(n,d,"pagi"),b=here(n,d,"sore");return a&&b?1:((a||b)?0.5:0);
    }

    double dailyGrandTotal(int d){
        double x=0;
        for(String n:maleNames()) x+=dayVal(n,d);
        for(String n:femaleNames()) x+=dayVal(n,d);
        return x;
    }

    String csvCell(String v){
        return "\"" + v.replace("\"","\"\"") + "\"";
    }

    void exportCsv(){
        StringBuilder x=new StringBuilder("\ufeff");
        x.append(csvCell("No")).append(",").append(csvCell("Nama")).append(",").append(csvCell("Jenis Kelamin"));
        for(int d=sessionStartDay;d<=sessionEndDay;d++)x.append(",").append(csvCell("Tanggal "+d));
        x.append(",").append(csvCell("TOTAL HARI")).append("\n");

        int no=1;
        for(String n:maleNames()){
            x.append(no++).append(",").append(csvCell(n)).append(",").append(csvCell("Laki-laki"));
            for(int d=sessionStartDay;d<=sessionEndDay;d++)x.append(",").append(dayVal(n,d));
            x.append(",").append(total(n)).append("\n");
        }
        for(String n:femaleNames()){
            x.append(no++).append(",").append(csvCell(n)).append(",").append(csvCell("Perempuan"));
            for(int d=sessionStartDay;d<=sessionEndDay;d++)x.append(",").append(dayVal(n,d));
            x.append(",").append(total(n)).append("\n");
        }

        // Rekap total per hari: 1 = dua sesi, 0,5 = satu sesi.
        x.append(",").append(csvCell("TOTAL KEHADIRAN HARIAN")).append(",").append(csvCell("Semua"));
        for(int d=sessionStartDay;d<=sessionEndDay;d++)x.append(",").append(dailyGrandTotal(d));
        x.append(",").append(csvCell("-")).append("\n");

        File f=new File(getExternalFilesDir(null),"Rekap_Total_Absen_CV_Hikmah_Tani.csv");
        try(FileOutputStream o=new FileOutputStream(f)){
            o.write(x.toString().getBytes("UTF-8"));
            share(f,"text/csv");
        }catch(Exception e){toast("Gagal membuat CSV");}
    }

    void share(File f,String type){
        Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
        Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i,"Bagikan / Simpan"));
    }


    void backup(){
        try{
            JSONObject root=new JSONObject();root.put("app","Absen CV Hikmah Tani");root.put("appName",appTitle());
            JSONArray ma=new JSONArray();for(String n:maleNames())ma.put(n);root.put("male",ma);
            JSONArray fe=new JSONArray();for(String n:femaleNames())fe.put(n);root.put("female",fe);
            JSONArray at=new JSONArray(); JSONObject data=new JSONObject();
            for(Map.Entry<String,?> e:prefs.getAll().entrySet()){
                if(KEY_PENDING_FULL_SYNC.equals(e.getKey())) continue;
                Object v=e.getValue();
                if(v instanceof Boolean && Boolean.TRUE.equals(v)) at.put(e.getKey());
                if(v instanceof Boolean || v instanceof String || v instanceof Number) data.put(e.getKey(),v);
            }
            root.put("attendance",at); root.put("data",data);
            root.put("periodYear",periodYear);root.put("periodMonth",periodMonth);root.put("periodSession",periodSession);
            File f=new File(getExternalFilesDir(null),"BACKUP_Absen_CV_Hikmah_Tani.json");
            try(FileOutputStream o=new FileOutputStream(f)){o.write(root.toString(2).getBytes("UTF-8"));}
            share(f,"application/json");
        }catch(Exception e){toast("Backup gagal: "+e.getMessage());}
    }

    void pickBackup(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/json","text/plain","*/*"});
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,77);
    }

    void clearAttendance(SharedPreferences.Editor e){
        // Remove every attendance key, including keys belonging to old/custom names.
        for(String k:prefs.getAll().keySet()){
            if(k.matches(".+_\\d+_(?:pagi|sore)") || k.startsWith(KEY_STATUS_PREFIX)) e.remove(k);
        }
    }

    HashSet<String> allKnownNames(){
        HashSet<String> s=new HashSet<>();
        Collections.addAll(s,DEFAULT_MALE);Collections.addAll(s,DEFAULT_FEMALE);
        Collections.addAll(s,maleNames());Collections.addAll(s,femaleNames());
        return s;
    }

    String[] jsonNames(JSONObject o,String key,String[] fallback)throws Exception{
        if(!o.has(key))return fallback.clone();
        JSONArray a=o.getJSONArray(key);ArrayList<String> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){String n=a.getString(i).trim();if(!n.isEmpty())out.add(n);}
        return out.isEmpty()?fallback.clone():out.toArray(new String[0]);
    }

    void migrateNames(String[] oldMale,String[] oldFemale,String[] newMale,String[] newFemale,SharedPreferences.Editor e){
        for(int i=0;i<Math.min(oldMale.length,newMale.length);i++)copyAttendance(oldMale[i],newMale[i],e);
        for(int i=0;i<Math.min(oldFemale.length,newFemale.length);i++)copyAttendance(oldFemale[i],newFemale[i],e);
    }

    void copyAttendance(String oldN,String newN,SharedPreferences.Editor e){
        if(oldN.equals(newN))return;
        for(int d=1;d<=MAX_MONTH_DAYS;d++)for(String s:new String[]{"pagi","sore"})
            if(here(oldN,d,s))e.putBoolean(key(newN,d,s),true);
        for(int d=1;d<=MAX_MONTH_DAYS;d++){
            String st=status(oldN,d);
            if(!STATUS_NONE.equals(st)) e.putString(statusKey(newN,d),st);
        }
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==REQ_GOOGLE_LEGACY){
            try{
                com.google.android.gms.auth.api.signin.GoogleSignInAccount legacyAccount =
                        GoogleSignIn.getSignedInAccountFromIntent(d).getResult(ApiException.class);
                if(legacyAccount==null || legacyAccount.getIdToken()==null){
                    signInInProgress=false;
                    toast("Login Google dibatalkan atau akun tidak tersedia");
                    return;
                }
                signInInProgress=false;
                AuthCredential firebaseCredential=GoogleAuthProvider.getCredential(legacyAccount.getIdToken(),null);
                firebaseAuth.signInWithCredential(firebaseCredential)
                        .addOnSuccessListener(resultAuth->{
                            toast("Login Google berhasil ✓");
                            build();
                            startCloudSync();
                        })
                        .addOnFailureListener(e->{
                            Log.e("AbsenGoogle","Firebase legacy sign-in failed",e);
                            showLoginError(firebaseErrorMessage(e));
                        });
            }catch(ApiException e){
                signInInProgress=false;
                Log.e("AbsenGoogle","Legacy Google Sign-In result error: "+e.getStatusCode(),e);
                if(e.getStatusCode()==12501 || e.getStatusCode()==16){
                    toast("Login Google dibatalkan");
                }else if(e.getStatusCode()==10){
                    showLoginError("DEVELOPER_ERROR (kode 10): SHA-1 signing APK tidak cocok dengan konfigurasi Google/Firebase.");
                }else{
                    showLoginError("Login Google gagal (kode "+e.getStatusCode()+")");
                }
            }catch(Exception e){
                signInInProgress=false;
                Log.e("AbsenGoogle","Legacy Google Sign-In unexpected error",e);
                showLoginError("Hasil Login Google tidak dapat diproses");
            }
            return;
        }
        if(r!=77)return;
        if(c!=RESULT_OK || d==null || d.getData()==null){
            toast("Pemulihan dibatalkan");
            return;
        }
        Uri backupUri=d.getData();
        try{
            StringBuilder sb=new StringBuilder();
            try(InputStream in=getContentResolver().openInputStream(backupUri)){
                if(in==null)throw new IOException("File tidak dapat dibuka");
                try(BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"))){
                    char[] buf=new char[4096];
                    int n;
                    while((n=br.read(buf))!=-1)sb.append(buf,0,n);
                }
            }
            String json=sb.toString();
            if(json.length()>0 && json.charAt(0)=='\ufeff')json=json.substring(1);
            json=json.trim();
            if(json.isEmpty())throw new Exception("File backup kosong");

            JSONObject root=new JSONObject(json);
            boolean hasData=root.has("attendance") || root.has("data");
            boolean hasNames=root.has("male") || root.has("female");
            String app=root.optString("app","").trim();
            // Terima backup lama/baru selama strukturnya memang milik aplikasi.
            // Ini menjaga kompatibilitas jika nama aplikasi pernah diubah.
            boolean knownApp=app.isEmpty() ||
                    "Absen CV Hikmah Tani".equalsIgnoreCase(app) ||
                    "ABSEN CV HIKMAH TANI".equalsIgnoreCase(app);
            if(!knownApp || (!hasData && !hasNames))
                throw new Exception("Format backup tidak dikenali");

            String[] oldMale=maleNames(),oldFemale=femaleNames();
            String[] newMale=jsonNames(root,"male",oldMale);
            String[] newFemale=jsonNames(root,"female",oldFemale);
            SharedPreferences.Editor e=prefs.edit();
            clearAttendance(e);

            int restored=0;
            if(root.has("attendance")){
                JSONArray a=root.getJSONArray("attendance");
                for(int i=0;i<a.length();i++){
                    String k=a.optString(i,"").trim();
                    if(validAttendanceKey(k)){e.putBoolean(k,true);restored++;}
                }
            }else if(root.has("data")){
                JSONObject data=root.getJSONObject("data");
                Iterator<String> it=data.keys();
                while(it.hasNext()){
                    String k=it.next(); Object v=data.opt(k);
                    if(v instanceof Boolean){
                        if(validAttendanceKey(k) && data.optBoolean(k,false)){e.putBoolean(k,true);restored++;}
                    }else if(v instanceof String && k.startsWith(KEY_STATUS_PREFIX)) e.putString(k,data.optString(k,""));
                    else if((k.equals(KEY_PERIOD_YEAR)||k.equals(KEY_PERIOD_MONTH)||k.equals(KEY_PERIOD_SESSION)) && v instanceof Number) e.putInt(k,((Number)v).intValue());
                }
                if(root.has("periodYear")) e.putInt(KEY_PERIOD_YEAR,root.optInt("periodYear",periodYear));
                if(root.has("periodMonth")) e.putInt(KEY_PERIOD_MONTH,root.optInt("periodMonth",periodMonth));
                if(root.has("periodSession")) e.putInt(KEY_PERIOD_SESSION,root.optInt("periodSession",periodSession));
            }

            e.putString(KEY_MALE,android.text.TextUtils.join("\n",newMale));
            e.putString(KEY_FEMALE,android.text.TextUtils.join("\n",newFemale));
            if(root.has("appName")){
                String restoredTitle=root.optString("appName","").trim();
                if(!restoredTitle.isEmpty())e.putString(KEY_APP,restoredTitle);
            }
            e.apply();
            initPeriodSettings();

            // Backup adalah perintah eksplisit dari pengguna: jangan biarkan
            // listener Firebase mengembalikan data cloud lama sebelum hasil
            // restore sempat ditulis ke database.
            restoringBackup=true;
            pendingFullSync=true;
            if(fullCloudWriteInProgress)localChangedDuringFullSync=true;
            prefs.edit().putBoolean(KEY_PENDING_FULL_SYNC,true).apply();
            if(cloudConnected) uploadPendingFullState();
            else setCloudStatus("☁ Offline • restore tersimpan di perangkat, menunggu koneksi");
            buildPreservePosition(sv==null?0:sv.getScrollY(),currentDay);
            toast("Backup berhasil dipulihkan ✓ ("+restored+" absensi)");
        }catch(JSONException e){
            Log.e("AbsenBackup","JSON backup tidak valid",e);
            toast("Backup tidak valid: format JSON rusak");
        }catch(SecurityException e){
            Log.e("AbsenBackup","Tidak punya akses ke file backup",e);
            toast("Backup tidak bisa dibaca: izin file ditolak");
        }catch(Exception e){
            Log.e("AbsenBackup","Gagal memulihkan backup",e);
            String msg=e.getMessage();
            if(msg==null || msg.trim().isEmpty())msg="file tidak bisa dibaca";
            toast("Backup gagal: "+msg);
        }
    }

    void confirmReset(){
        new AlertDialog.Builder(this).setTitle("Reset semua absensi?")
            .setMessage("Semua data Pagi, Sore, dan status selama periode yang tersimpan akan dihapus. Nama dan pengaturan tetap.")
            .setNegativeButton("Batal",null).setPositiveButton("Reset",(dialog,which)->resetAll()).show();
    }

    void resetAll(){
        try{
            SharedPreferences.Editor e=prefs.edit();
            clearAttendance(e);
            e.apply();
            restoringBackup=false;
            pendingFullSync=true;
            if(fullCloudWriteInProgress)localChangedDuringFullSync=true;
            prefs.edit().putBoolean(KEY_PENDING_FULL_SYNC,true).apply();
            if(cloudConnected) uploadPendingFullState();
            else setCloudStatus("☁ Offline • reset tersimpan di perangkat, menunggu koneksi");
            updateVisibleRowsAfterReset();
            toast("Semua absensi sudah di-reset ✓");
        }catch(Exception ex){
            Log.e("AbsenReset","Gagal reset absensi",ex);
            toast("Reset gagal: "+safeError(ex));
        }
    }

    void updateVisibleRowsAfterReset(){
        if(list==null)return;
        for(int i=0;i<list.getChildCount();i++){
            View v=list.getChildAt(i);
            if(v instanceof LinearLayout){
                LinearLayout row=(LinearLayout)v;
                if(row.getChildCount()>3 && row.getChildAt(1) instanceof Button && row.getChildAt(2) instanceof Button && row.getChildAt(3) instanceof TextView){
                    Button p=(Button)row.getChildAt(1), so=(Button)row.getChildAt(2);
                    styleSession(p,false,Color.rgb(18,125,110));
                    styleSession(so,false,Color.rgb(86,73,151));
                    ((TextView)row.getChildAt(3)).setText("0");
                }
            }
        }
    }

    void showSettings(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,8,24,4);
        Button app=btn("Ubah nama aplikasi");Button male=btn("Ubah nama laki-laki");Button female=btn("Ubah nama perempuan");Button reset=btn("Kembalikan nama bawaan");
        Button account=btn(firebaseAuth!=null&&firebaseAuth.getCurrentUser()!=null ? "Keluar dari akun Google" : "Masuk dengan Google");
        box.addView(app,new LinearLayout.LayoutParams(-1,58));box.addView(male,new LinearLayout.LayoutParams(-1,58));box.addView(female,new LinearLayout.LayoutParams(-1,58));box.addView(reset,new LinearLayout.LayoutParams(-1,58));box.addView(account,new LinearLayout.LayoutParams(-1,58));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("⚙ Pengaturan").setView(box).setNegativeButton("Tutup",null).create();
        app.setOnClickListener(v->{dlg.dismiss();editSingle("Nama aplikasi",appTitle(),val->{prefs.edit().putString(KEY_APP,val).apply(); cloudPut(KEY_APP,val); buildPreservePosition(sv==null?0:sv.getScrollY(),currentDay);});});
        male.setOnClickListener(v->{dlg.dismiss();editList("Nama laki-laki",maleNames(),KEY_MALE);});
        female.setOnClickListener(v->{dlg.dismiss();editList("Nama perempuan",femaleNames(),KEY_FEMALE);});
        reset.setOnClickListener(v->{prefs.edit().remove(KEY_MALE).remove(KEY_FEMALE).remove(KEY_APP).apply();
            cloudRemove(KEY_MALE); cloudRemove(KEY_FEMALE); cloudRemove(KEY_APP);
            buildPreservePosition(sv==null?0:sv.getScrollY(),currentDay);toast("Nama dikembalikan ke bawaan");});
        account.setOnClickListener(v->{
            dlg.dismiss();
            if(firebaseAuth!=null&&firebaseAuth.getCurrentUser()!=null){
                confirmLogout();
            }else{
                requestGoogleSignIn();
            }
        });
        dlg.show();
    }

    void confirmLogout(){
        new AlertDialog.Builder(this)
                .setTitle("Keluar dari akun?")
                .setMessage("Anda akan kembali ke halaman login. Data absensi di perangkat tidak dihapus.")
                .setNegativeButton("Batal",null)
                .setPositiveButton("Keluar",(dialog,which)->logout())
                .show();
    }

    void logout(){
        if(cloudState!=null && cloudListener!=null){
            cloudState.removeEventListener(cloudListener);
        }
        if(cloudConnection!=null && cloudConnectionListener!=null){
            cloudConnection.removeEventListener(cloudConnectionListener);
        }
        cloudState=null;
        cloudListener=null;
        cloudConnection=null;
        cloudConnectionListener=null;
        cloudReady=false;
        cloudConnected=false;
        if(firebaseAuth!=null) firebaseAuth.signOut();
        if(legacyGoogleClient!=null){
            try{ legacyGoogleClient.signOut(); }catch(Exception ignored){}
        }
        if(credentialManager!=null){
            try{
                credentialManager.clearCredentialStateAsync(
                        new ClearCredentialStateRequest(),
                        new CancellationSignal(),
                        ContextCompat.getMainExecutor(this),
                        new CredentialManagerCallback<Void, androidx.credentials.exceptions.ClearCredentialException>() {
                            @Override public void onResult(Void result){}
                            @Override public void onError(androidx.credentials.exceptions.ClearCredentialException e){}
                        });
            }catch(Exception ignored){}
        }
        buildLogin();
        toast("Anda sudah keluar dari akun");
    }

    interface ValueCallback{void save(String value);}
    void editSingle(String title,String current,ValueCallback cb){
        EditText input=new EditText(this);input.setText(current);input.setSelectAllOnFocus(true);input.setSingleLine(true);input.setPadding(24,0,24,0);
        new AlertDialog.Builder(this).setTitle(title).setView(input).setNegativeButton("Batal",null)
            .setPositiveButton("Simpan",(d,w)->{String v=input.getText().toString().trim();if(!v.isEmpty())cb.save(v);else toast("Nama tidak boleh kosong");}).show();
    }

    void editList(String title,String[] current,String prefKey){
        EditText input=new EditText(this);input.setText(android.text.TextUtils.join("\n",current));input.setGravity(Gravity.TOP);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        input.setMinLines(Math.min(20,current.length));input.setPadding(24,8,24,8);
        new AlertDialog.Builder(this).setTitle(title+" (satu nama per baris)").setView(input).setNegativeButton("Batal",null)
            .setPositiveButton("Simpan",(d,w)->saveNameList(input.getText().toString(),prefKey,current)).show();
    }

    void saveNameList(String raw,String prefKey,String[] oldNames){
        ArrayList<String> a=new ArrayList<>();for(String s:raw.split("\\r?\\n")){s=s.trim();if(!s.isEmpty())a.add(s);}
        if(a.isEmpty()){toast("Daftar nama tidak boleh kosong");return;}
        String[] nn=a.toArray(new String[0]);
        SharedPreferences.Editor e=prefs.edit();
        migrateNames(oldNames, new String[0], prefKey.equals(KEY_MALE)?nn:new String[0], prefKey.equals(KEY_FEMALE)?nn:new String[0], e);
        e.putString(prefKey,android.text.TextUtils.join("\n",nn));e.apply();
        cloudPut(prefKey,android.text.TextUtils.join("\n",nn));
        buildPreservePosition(sv==null?0:sv.getScrollY(),currentDay);toast("Daftar nama tersimpan ✓");
    }

    double groupTotal(String[] names){
        double x=0;
        for(String n:names) x+=total(n);
        return x;
    }

    String formatNumber(double v){
        return String.valueOf(v).replace(".0","");
    }

    float[] pdfColumns(){
        int days=activeDayCount();
        // Boundary count = 3 fixed boundaries (No, Nama, first day) +
        // one boundary for each day + one final boundary for Total.
        // The previous array had only days+3 entries and overwrote the last
        // day's right boundary, causing H30 to collide with Total.
        float[] col=new float[days+4];
        float left=20f, right=822f;
        float noW=30f, nameW=150f, totalW=48f;
        float dayW=(right-left-noW-nameW-totalW)/days;
        col[0]=left;
        col[1]=left+noW;
        col[2]=col[1]+nameW;
        for(int i=0;i<=days;i++) col[i+2]=col[2]+dayW*i;
        col[days+3]=right;
        return col;
    }

    void drawPdfTableHeader(Canvas c, Paint p, float[] col, float y, float rowH){
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(7);
        p.setColor(Color.rgb(240,232,213));
        c.drawRect(col[0],y,col[col.length-1],y+rowH,p);

        p.setColor(Color.DKGRAY);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1);
        for(float xx:col)c.drawLine(xx,y,xx,y+rowH,p);
        c.drawLine(col[0],y,col[col.length-1],y,p);
        c.drawLine(col[0],y+rowH,col[col.length-1],y+rowH,p);

        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.DKGRAY);
        c.drawText("No",col[0]+8,y+13,p);
        c.drawText("Nama",col[1]+4,y+13,p);

        int days=activeDayCount();
        for(int i=0;i<days;i++){
            int day=sessionStartDay+i;
            String h="H"+day;
            float cx=(col[i+2]+col[i+3])/2f;
            float tw=p.measureText(h);
            c.drawText(h,cx-tw/2,y+13,p);
        }

        String totalLabel="Total";
        float cx=(col[col.length-2]+col[col.length-1])/2f;
        float tw=p.measureText(totalLabel);
        c.drawText(totalLabel,cx-tw/2,y+13,p);
        p.setStyle(Paint.Style.FILL);
    }

    void drawPdfFittedName(Canvas c, Paint p, String name, float left, float right, float baseline){
        float oldSize=p.getTextSize();
        float oldScale=p.getTextScaleX();
        p.setTextScaleX(1f);
        float maxWidth=Math.max(20f,right-left-8f);
        float size=7f;
        p.setTextSize(size);
        while(size>5f && p.measureText(name)>maxWidth){
            size-=0.25f;
            p.setTextSize(size);
        }
        if(p.measureText(name)>maxWidth){
            p.setTextScaleX(Math.max(0.55f,maxWidth/p.measureText(name)));
        }
        c.drawText(name,left+4,baseline,p);
        p.setTextScaleX(oldScale);
        p.setTextSize(oldSize);
    }

    void drawPdfAttendanceRow(Canvas c, Paint p, float[] col, float y, float rowH, String n, int no){
        int days=activeDayCount();
        p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);
        c.drawRect(col[0],y,col[col.length-1],y+rowH,p);
        p.setColor(Color.DKGRAY);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(.7f);
        c.drawRect(col[0],y,col[col.length-1],y+rowH,p);
        for(float xx:col)c.drawLine(xx,y,xx,y+rowH,p);
        p.setStyle(Paint.Style.FILL);

        p.setTypeface(Typeface.DEFAULT);p.setTextSize(7);p.setColor(Color.DKGRAY);
        c.drawText(String.valueOf(no),col[0]+5,y+13,p);
        drawPdfFittedName(c,p,n,col[1],col[2],y+13);

        for(int i=0;i<days;i++){
            int d=sessionStartDay+i;
            double val=dayVal(n,d);
            String v=val==0?"-":formatNumber(val);
            int cellColor=val==0?Color.rgb(235,125,125):(val==0.5?Color.rgb(247,213,113):Color.rgb(126,190,135));
            float left=col[i+2],right=col[i+3];
            p.setStyle(Paint.Style.FILL);p.setColor(cellColor);c.drawRect(left,y,right,y+rowH,p);
            p.setStyle(Paint.Style.STROKE);p.setColor(Color.DKGRAY);c.drawRect(left,y,right,y+rowH,p);p.setStyle(Paint.Style.FILL);
            p.setColor(val==0?Color.rgb(170,35,42):(val==0.5?Color.rgb(150,105,15):Color.rgb(35,120,55)));
            float cx=(left+right)/2f,tw=p.measureText(v);
            c.drawText(v,cx-tw/2,y+13,p);
        }

        String tv=formatNumber(total(n));
        float cx=(col[col.length-2]+col[col.length-1])/2f,tw=p.measureText(tv);
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setColor(Color.DKGRAY);
        c.drawText(tv,cx-tw/2,y+13,p);p.setTypeface(Typeface.DEFAULT);
    }

    void makePdf(){
        PdfDocument doc=new PdfDocument();
        final int W=842,H=595;
        final float[] col=pdfColumns();

        int pageNo=1;
        PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,pageNo).create());
        Canvas c=page.getCanvas();
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.DKGRAY);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(16);
        c.drawText(appTitle()+" - REKAP ABSENSI",20,24,p);
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(8);
        c.drawText((periodSession==1?"SESI 1 • TANGGAL 1–15":"SESI 2 • TANGGAL 16–"+sessionEndDay)
                +" • "+monthName(periodMonth)+" "+periodYear,20,38,p);

        int[] noHolder={1}; float y=48;
        String[] groups={"LAKI-LAKI","PEREMPUAN"};
        String[][] lists={maleNames(),femaleNames()};
        int days=activeDayCount();

        for(int g=0;g<2;g++){
            if(y+36>H-20){
                doc.finishPage(page);pageNo++;
                page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,pageNo).create());
                c=page.getCanvas();y=24;
            }
            p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(9);p.setColor(Color.rgb(156,35,53));
            c.drawText(groups[g],20,y+10,p);y+=16;
            drawPdfTableHeader(c,p,col,y,20);y+=20;
            for(String n:lists[g]){
                if(y+20>H-20){
                    doc.finishPage(page);pageNo++;
                    page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,pageNo).create());
                    c=page.getCanvas();y=24;
                    p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(12);p.setColor(Color.DKGRAY);
                    c.drawText(appTitle()+" - REKAP ABSENSI (lanjutan)",20,y,p);y+=18;
                    drawPdfTableHeader(c,p,col,y,20);y+=20;
                }
                drawPdfAttendanceRow(c,p,col,y,20,n,noHolder[0]++);
                y+=20;
            }
            y+=8;
        }

        if(y+95>H-20){
            doc.finishPage(page);pageNo++;
            page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,pageNo).create());
            c=page.getCanvas();y=24;
        }

        double maleWork=groupTotal(maleNames());
        double femaleWork=groupTotal(femaleNames());
        double overallWork=maleWork+femaleWork;

        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(10);p.setColor(Color.DKGRAY);
        c.drawText("REKAP TOTAL HARI KERJA",20,y+12,p);y+=20;
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(9);
        c.drawText("Laki-laki : "+formatNumber(maleWork)+" hari",25,y+12,p);
        c.drawText("Perempuan : "+formatNumber(femaleWork)+" hari",260,y+12,p);
        c.drawText("Total semuanya : "+formatNumber(overallWork)+" hari",510,y+12,p);y+=28;

        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(9);
        c.drawText("REKAP TOTAL HARI KERJA PER TANGGAL",20,y+12,p);y+=18;
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(7);
        StringBuilder dailyLine=new StringBuilder();
        for(int i=0;i<days;i++){
            int d=sessionStartDay+i;
            if(i>0)dailyLine.append("   •   ");
            dailyLine.append(d).append(" = ").append(formatNumber(dailyGrandTotal(d)));
        }
        c.drawText(dailyLine.toString(),25,y+12,p);y+=22;

        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(9);
        c.drawText("KETERANGAN",20,y+12,p);y+=18;
        p.setTypeface(Typeface.DEFAULT);p.setTextSize(8);
        c.drawText("0 = tidak ada sesi hadir",25,y+12,p);
        c.drawText("0,5 = satu sesi hadir",270,y+12,p);
        c.drawText("1 = Pagi + Sore hadir",470,y+12,p);
        doc.finishPage(page);

        File f=new File(getExternalFilesDir(null),"Rekap_Absen_CV_Hikmah_Tani.pdf");
        try(FileOutputStream o=new FileOutputStream(f)){
            doc.writeTo(o);doc.close();share(f,"application/pdf");
        }catch(Exception e){
            try{doc.close();}catch(Exception ignored){}
            Log.e("AbsenPDF","PDF gagal dibuat",e);toast("PDF gagal dibuat");
        }
    }

}
