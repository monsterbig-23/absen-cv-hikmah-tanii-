# Absen CV Hikmah Tani — V8 FIX SYNC3

## Firebase
- Project: `absensi-cv-hikmah-tani`
- Android package: `com.hikmahtani.absen`
- Realtime Database: `https://absensi-cv-hikmah-tani-default-rtdb.firebaseio.com`
- Data path: `cv_hikmah_tani/state`
- Database region: `us-central1`

## Google Sign-In
V8 memakai `google-services.json` yang sudah memuat SHA-1 debug stabil V7 dan Web OAuth client untuk Firebase project yang sama.

## Sinkronisasi
V8 SYNC3 memakai URL database eksplisit, listener real-time, indikator koneksi, completion callback untuk write/delete, dan pemeriksaan ulang database saat koneksi online pertama kali. Jika database benar-benar kosong, perangkat pertama dapat mengunggah data lokal. Jika database sudah berisi data, perangkat mengikuti data cloud.

## Fitur dipertahankan
- Login Google / logout
- 15 hari, Pagi/Sore
- 37 laki-laki dan 26 perempuan
- Firebase Realtime Database
- Backup/Pulihkan JSON
- PDF dan CSV
- Pengaturan nama
- Reset
- Logo HT dan desain elegan
