# Absen CV Hikmah Tani — V7 FINAL

V7 fokus pada penyelesaian Google Sign-In `DEVELOPER_ERROR (10)` melalui signing key debug yang stabil dan diagnostik SHA-1.

## SHA-1 V7
Lihat `signing/HIKMAH_V7_SHA1.txt`.

## WAJIB sebelum build/test login
1. Tambahkan SHA-1 V7 ke Firebase Android app `com.hikmahtani.absen`.
2. Download `google-services.json` terbaru dari Firebase.
3. Ganti `app/google-services.json` dengan file terbaru.
4. Jalankan GitHub Actions.

Workflow akan **menghentikan build** bila `google-services.json` belum memuat SHA-1 V7. Ini sengaja agar APK tidak dibuat dengan konfigurasi Google yang masih salah.

## Diagnostik di aplikasi
Pada halaman login tersedia tombol `Periksa konfigurasi Login Google`. Tombol ini menampilkan package name, SHA-1 APK, SHA-256, dan Web Client ID.

## Signing
`signing/hikmah-v7-debug.keystore` adalah debug/diagnostic key yang stabil untuk build debug V7. Bukan production key. Untuk produksi/Play Store gunakan release keystore privat dan Play App Signing.

## Fitur yang dipertahankan
- Login Google dan logout
- Absensi 15 hari, Pagi/Sore
- 37 laki-laki dan 26 perempuan
- Firebase Realtime Database
- Backup/Pulihkan JSON
- PDF dan CSV
- Pengaturan nama
- Reset
- Logo HT dan desain elegan
