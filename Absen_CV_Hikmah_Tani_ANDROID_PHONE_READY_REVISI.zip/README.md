# Absen CV Hikmah Tani — Android Native
Project Android native (bukan shortcut Chrome).

Fitur:
- Penyimpanan otomatis di perangkat (SharedPreferences).
- Data tetap ada saat aplikasi ditutup dan dibuka kembali.
- 15 hari, Pagi/Sore.
- Pagi + sore = 1 hari; satu sesi = 0,5 hari.
- Rekap total per nama.
- Export CSV dan PDF.
- Backup & Pulihkan JSON.
- CICI dan EKO: laki-laki.
- IPAT: Ibu-ibu/Perempuan.

Build:
1. Buka folder ini di Android Studio terbaru.
2. Tunggu Gradle Sync.
3. Build > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk.

Catatan: chat ini tidak menyediakan Android SDK/build environment untuk menghasilkan APK binary secara langsung, jadi yang dikirim adalah source project siap-build.
