package com.hikmahtani.absen;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import androidx.core.content.FileProvider;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String PREF="absen_data_v1";
    final String[] MALE = {"SLAMET","BIRIN","KURNIA","JOHAN","NENDI","KABUL","PIYAN","UDIN","JUNAEDI","ASEP C","ADE T","ANGGI","ANTO","AGUNG","RIJAL","DIKA","EKO","AANG","AGUNG GT","CICI","GIMIN","ALI","BENI","ASEP M","DEDI","BUYUNG","JALI","ADE CUMARNO","JONI H","ROJAK","USUP","AMANG","AHMAD","P. USTAD","IRMAN","TOMI","D. MARJI"};
    final String[] FEMALE = {"DEDEH","TINI","ENTUN","ONEH","TITI","IIS","NURUL","YUYUN","SUTIAH","EPON","NENG AGUS","AMBU","YANI","NURSIAH","TITIN","TUSIAH","SOLEHAH","GIYEM","SANTI","TETEH","M. IBAH","MARINAH","KHOTIMAH","MBA SUM","IPAT","IKA"};
    SharedPreferences prefs;
    LinearLayout list;
    Spinner daySpinner;
    int currentDay=1;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences(PREF,MODE_PRIVATE);
        build();
    }

    Button btn(String text) {
        Button b=new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setMinHeight(52);
        return b;
    }

    void build() {
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12,8,12,8);

        TextView title=new TextView(this);
        title.setText("ABSEN CV HIKMAH TANI");
        title.setTextSize(22);
        title.setTextColor(Color.WHITE);
        title.setTypeface(null,Typeface.BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(14,0,14,0);
        title.setBackgroundColor(Color.rgb(47,111,62));
        root.addView(title,new LinearLayout.LayoutParams(-1,64));

        LinearLayout top=new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        daySpinner=new Spinner(this);
        String[] days=new String[15];
        for(int i=0;i<15;i++) days[i]="Hari "+(i+1);
        daySpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,days));
        top.addView(daySpinner,new LinearLayout.LayoutParams(-1,58));
        daySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){currentDay=pos+1;render();}
        });
        root.addView(top);

        LinearLayout actions=new LinearLayout(this);
        Button allP=btn("✓ Semua hadir pagi");
        Button allS=btn("✓ Semua hadir sore");
        actions.addView(allP,new LinearLayout.LayoutParams(0,60,1));
        actions.addView(allS,new LinearLayout.LayoutParams(0,60,1));
        root.addView(actions);

        LinearLayout actions2=new LinearLayout(this);
        Button csv=btn("⬇ Rekap CSV");
        Button pdf=btn("📄 PDF");
        Button backup=btn("💾 Backup");
        Button restore=btn("📥 Pulihkan");
        actions2.addView(csv,new LinearLayout.LayoutParams(0,60,1));
        actions2.addView(pdf,new LinearLayout.LayoutParams(0,60,1));
        actions2.addView(backup,new LinearLayout.LayoutParams(0,60,1));
        actions2.addView(restore,new LinearLayout.LayoutParams(0,60,1));
        root.addView(actions2);

        Button reset=btn("↻ Reset semua absensi");
        root.addView(reset,new LinearLayout.LayoutParams(-1,60));

        ScrollView sv=new ScrollView(this);
        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        allP.setOnClickListener(v->markAll("pagi"));
        allS.setOnClickListener(v->markAll("sore"));
        csv.setOnClickListener(v->exportCsv());
        pdf.setOnClickListener(v->makePdf());
        backup.setOnClickListener(v->backup());
        restore.setOnClickListener(v->pickBackup());
        reset.setOnClickListener(v->confirmReset());
        render();
    }

    boolean here(String n,int d,String s) { return prefs.getBoolean(n+"_"+d+"_"+s,false); }

    void setHere(String n,int d,String s,boolean val) {
        prefs.edit().putBoolean(n+"_"+d+"_"+s,val).apply();
        render();
        Toast.makeText(this,"Tersimpan otomatis ✓",Toast.LENGTH_SHORT).show();
    }

    double total(String n) {
        double x=0;
        for(int d=1;d<=15;d++) {
            if(here(n,d,"pagi")) x+=.5;
            if(here(n,d,"sore")) x+=.5;
        }
        return x;
    }

    TextView label(String s,int size) {
        TextView t=new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setPadding(10,8,5,8);
        return t;
    }

    void render() {
        if(list==null)return;
        list.removeAllViews();
        TextView info=label("Hari "+currentDay+"\nPagi + sore = 1 hari | satu sesi = 0,5 hari",16);
        info.setBackgroundColor(Color.rgb(232,241,233));
        list.addView(info);
        section("Laki-laki",MALE);
        section("Ibu-ibu / Perempuan",FEMALE);
    }

    void section(String gender,String[] names) {
        TextView h=label(gender,19);
        h.setTypeface(null,Typeface.BOLD);
        h.setBackgroundColor(Color.rgb(232,241,233));
        list.addView(h);
        for(int i=0;i<names.length;i++) {
            String n=names[i];
            LinearLayout r=new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.addView(label((i+1)+". "+n,16),new LinearLayout.LayoutParams(0,62,1));
            Button p=btn("Pagi"), s=btn("Sore");
            boolean pagi=here(n,currentDay,"pagi");
            boolean sore=here(n,currentDay,"sore");
            p.setTextColor(pagi?Color.WHITE:Color.DKGRAY);
            s.setTextColor(sore?Color.WHITE:Color.DKGRAY);
            if(pagi)p.setBackgroundColor(Color.rgb(47,111,62));
            if(sore)s.setBackgroundColor(Color.rgb(47,111,62));
            TextView t=label(String.valueOf(total(n)).replace(".0",""),14);
            t.setGravity(Gravity.CENTER);
            r.addView(p,new LinearLayout.LayoutParams(72,58));
            r.addView(s,new LinearLayout.LayoutParams(72,58));
            r.addView(t,new LinearLayout.LayoutParams(58,58));
            p.setOnClickListener(v->setHere(n,currentDay,"pagi",!here(n,currentDay,"pagi")));
            s.setOnClickListener(v->setHere(n,currentDay,"sore",!here(n,currentDay,"sore")));
            list.addView(r);
        }
    }

    void markAll(String sess) {
        SharedPreferences.Editor e=prefs.edit();
        for(String n:MALE)e.putBoolean(n+"_"+currentDay+"_"+sess,true);
        for(String n:FEMALE)e.putBoolean(n+"_"+currentDay+"_"+sess,true);
        e.apply();
        render();
        Toast.makeText(this,"Semua "+sess+" tersimpan ✓",Toast.LENGTH_SHORT).show();
    }

    void exportCsv() {
        StringBuilder x=new StringBuilder("\ufeffNo,Nama,Jenis Kelamin");
        for(int d=1;d<=15;d++)x.append(",Hari ").append(d);
        x.append(",TOTAL HARI\n");
        int no=1;
        for(String n:MALE){
            x.append(no++).append(",").append(n).append(",Laki-laki");
            for(int d=1;d<=15;d++)x.append(",").append(dayVal(n,d));
            x.append(",").append(total(n)).append("\n");
        }
        for(String n:FEMALE){
            x.append(no++).append(",").append(n).append(",Ibu-ibu");
            for(int d=1;d<=15;d++)x.append(",").append(dayVal(n,d));
            x.append(",").append(total(n)).append("\n");
        }
        File f=new File(getExternalFilesDir(null),"Rekap_Total_Absen_CV_Hikmah_Tani.csv");
        try(FileOutputStream o=new FileOutputStream(f)){
            o.write(x.toString().getBytes("UTF-8"));
            share(f,"text/csv");
        }catch(Exception e){toast("Gagal membuat CSV");}
    }

    double dayVal(String n,int d){
        boolean a=here(n,d,"pagi"),b=here(n,d,"sore");
        return a&&b?1:((a||b)?0.5:0);
    }

    void share(File f,String type){
        Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
        Intent i=new Intent(Intent.ACTION_SEND);
        i.setType(type);
        i.putExtra(Intent.EXTRA_STREAM,uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i,"Bagikan / Simpan"));
    }

    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void backup() {
        StringBuilder b=new StringBuilder();
        b.append("{\"app\":\"Absen CV Hikmah Tani\",\"data\":{");
        boolean first=true;
        Map<String,?> all=prefs.getAll();
        for(Map.Entry<String,?> e:all.entrySet()) {
            if(e.getValue() instanceof Boolean && Boolean.TRUE.equals(e.getValue())) {
                if(!first)b.append(",");
                first=false;
                b.append("\"").append(e.getKey().replace("\\","\\\\").replace("\"","\\\"")).append("\":true");
            }
        }
        b.append("}}");
        File f=new File(getExternalFilesDir(null),"BACKUP_Absen_CV_Hikmah_Tani.json");
        try(FileOutputStream o=new FileOutputStream(f)){
            o.write(b.toString().getBytes("UTF-8"));
            share(f,"application/json");
        }catch(Exception e){toast("Backup gagal");}
    }

    void pickBackup(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,77);
    }

    void clearAttendance(SharedPreferences.Editor e){
        for(String n:MALE) for(int d=1;d<=15;d++){e.remove(n+"_"+d+"_pagi");e.remove(n+"_"+d+"_sore");}
        for(String n:FEMALE) for(int d=1;d<=15;d++){e.remove(n+"_"+d+"_pagi");e.remove(n+"_"+d+"_sore");}
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r!=77||c!=RESULT_OK||d==null||d.getData()==null)return;
        try{
            InputStream in=getContentResolver().openInputStream(d.getData());
            BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));
            StringBuilder sb=new StringBuilder(); String line;
            while((line=br.readLine())!=null)sb.append(line);
            br.close();
            String s=sb.toString();
            if(!s.contains("\"app\":\"Absen CV Hikmah Tani\""))throw new Exception();
            java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\\"([^\\\"]+)\\\"\\s*:\\s*true").matcher(s);
            ArrayList<String> keys=new ArrayList<>();
            while(m.find()){
                String key=m.group(1);
                if(key.matches(".+_[0-9]+_(pagi|sore)"))keys.add(key);
            }
            if(keys.isEmpty())throw new Exception();
            SharedPreferences.Editor e=prefs.edit();
            clearAttendance(e);
            for(String key:keys)e.putBoolean(key,true);
            e.apply();
            render();
            toast("Backup dipulihkan ✓ ("+keys.size()+" data)");
        }catch(Exception e){toast("Backup tidak valid atau tidak bisa dibaca");}
    }

    void confirmReset(){
        new AlertDialog.Builder(this)
            .setTitle("Reset semua absensi?")
            .setMessage("Semua data Pagi dan Sore selama 15 hari akan dihapus. Pastikan sudah Backup jika data masih diperlukan.")
            .setNegativeButton("Batal",null)
            .setPositiveButton("Reset",(dialog,which)->resetAll())
            .show();
    }

    void resetAll(){
        SharedPreferences.Editor e=prefs.edit();
        clearAttendance(e);
        e.apply();
        render();
        toast("Semua absensi sudah di-reset ✓");
    }

    void makePdf() {
        PdfDocument doc=new PdfDocument();
        PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(595,842,1).create();
        PdfDocument.Page page=doc.startPage(pi);
        Canvas c=page.getCanvas();
        Paint p=new Paint();
        p.setTextSize(18);p.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("ABSEN CV HIKMAH TANI - REKAP TOTAL",30,35,p);
        p.setTextSize(11);p.setTypeface(Typeface.DEFAULT);
        int y=60;
        c.drawText("Pagi+sore = 1 hari; satu sesi = 0,5 hari",30,y,p);y+=24;
        int no=1;
        for(String n:MALE){
            if(y>810){doc.finishPage(page);pi=new PdfDocument.PageInfo.Builder(595,842,doc.getPages().size()+1).create();page=doc.startPage(pi);c=page.getCanvas();y=30;}
            c.drawText(no+++". "+n+"    "+total(n)+" hari",30,y,p);y+=16;
        }
        y+=8;c.drawText("IBU-IBU / PEREMPUAN",30,y,p);y+=18;
        for(String n:FEMALE){
            if(y>810){doc.finishPage(page);pi=new PdfDocument.PageInfo.Builder(595,842,doc.getPages().size()+1).create();page=doc.startPage(pi);c=page.getCanvas();y=30;}
            c.drawText(no+++". "+n+"    "+total(n)+" hari",30,y,p);y+=16;
        }
        doc.finishPage(page);
        File f=new File(getExternalFilesDir(null),"Rekap_Total_Absen_CV_Hikmah_Tani.pdf");
        try(FileOutputStream o=new FileOutputStream(f)){
            doc.writeTo(o);doc.close();share(f,"application/pdf");
        }catch(Exception e){try{doc.close();}catch(Exception ignored){}toast("PDF gagal dibuat");}
    }
}
